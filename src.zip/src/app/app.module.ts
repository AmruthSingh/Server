import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { PddF1Component } from './Forms/DOE/PDD/pdd-f1/pdd-f1.component';
import { PddF2Component } from './Forms/DOE/PDD/pdd-f2/pdd-f2.component';
import { PddF4Component } from './Forms/DOE/PDD/pdd-f4/pdd-f4.component';
import { PddF11Component } from './Forms/DOE/PDD/pdd-f11/pdd-f11.component';
import { PddF12Component } from './Forms/DOE/PDD/pdd-f12/pdd-f12.component';
import { PddF14Component } from './Forms/DOE/PDD/pdd-f14/pdd-f14.component';
import { PddF15Component } from './Forms/DOE/PDD/pdd-f15/pdd-f15.component';
import { PddF16Component } from './Forms/DOE/PDD/pdd-f16/pdd-f16.component';
import { PddF5Component } from './Forms/DOE/PDD/pdd-f5/pdd-f5.component';
import { PddF8Component } from './Forms/DOE/PDD/pdd-f8/pdd-f8.component';
import { PddF9Component } from './Forms/DOE/PDD/pdd-f9/pdd-f9.component';
import { PddF17Component } from './Forms/DOE/PDD/pdd-f17/pdd-f17.component';
import { StfF6Component } from './Forms/DOFS/STF/stf-f6/stf-f6.component';
import { StfF27Component } from './Forms/DOFS/STF/stf-f27/stf-f27.component';
import { PddF18Component } from './Forms/DOE/PDD/pdd-f18/pdd-f18.component';
import { PddF52Component } from './Forms/DOE/PDD/pdd-f52/pdd-f52.component';
import { PddF53Component } from './Forms/DOE/PDD/pdd-f53/pdd-f53.component';
import { PddF21Component } from './Forms/DOE/PDD/pdd-f21/pdd-f21.component';
import { PddF20Component } from './Forms/DOE/PDD/pdd-f20/pdd-f20.component';
import { PddF42Component } from './Forms/DOE/PDD/pdd-f42/pdd-f42.component';
import { PddF48Component } from './Forms/DOE/PDD/pdd-f48/pdd-f48.component';
import { PddF51Component } from './Forms/DOE/PDD/pdd-f51/pdd-f51.component';
import { AmdF1Component } from './Forms/DOE/AMD/amd-f1/amd-f1.component';
import { AmdF2Component } from './Forms/DOE/AMD/amd-f2/amd-f2.component';
import { AmdF3Component } from './Forms/DOE/AMD/amd-f3/amd-f3.component';
import { AmdF4Component } from './Forms/DOE/AMD/amd-f4/amd-f4.component';
import { AmdF5Component } from './Forms/DOE/AMD/amd-f5/amd-f5.component';
import { AmdF6Component } from './Forms/DOE/AMD/amd-f6/amd-f6.component';
import { AmdF7Component } from './Forms/DOE/AMD/amd-f7/amd-f7.component';
import { AmdF8Component } from './Forms/DOE/AMD/amd-f8/amd-f8.component';
import { AmdF9Component } from './Forms/DOE/AMD/amd-f9/amd-f9.component';
import { SedF1Component } from './Forms/DOE/SED/sed-f1/sed-f1.component';
import { SedF2Component } from './Forms/DOE/SED/sed-f2/sed-f2.component';
import { SedF3Component } from './Forms/DOE/SED/sed-f3/sed-f3.component';
import { PddF24Component } from './Forms/DOE/PDD/pdd-f24/pdd-f24.component';
import { PddF25Component } from './Forms/DOE/PDD/pdd-f25/pdd-f25.component';
import { PddF23Component } from './Forms/DOE/PDD/pdd-f23/pdd-f23.component';
import { PddF19Component } from './Forms/DOE/PDD/pdd-f19/pdd-f19.component';
import { SfdF2Component } from './Forms/DOE/SFD/sfd-f2/sfd-f2.component';
import { SfdF3Component } from './Forms/DOE/SFD/sfd-f3/sfd-f3.component';
import { SfdF4Component } from './Forms/DOE/SFD/sfd-f4/sfd-f4.component';
import { SfdF5Component } from './Forms/DOE/SFD/sfd-f5/sfd-f5.component';
import { SfdF1Component } from './Forms/DOE/SFD/sfd-f1/sfd-f1.component';
import { IfdF1Component } from './Forms/DOE/IFD/ifd-f1/ifd-f1.component';
import { IfdF2Component } from './Forms/DOE/IFD/ifd-f2/ifd-f2.component';
import { IfdF5Component } from './Forms/DOE/IFD/ifd-f5/ifd-f5.component';
import { IfdF8Component } from './Forms/DOE/IFD/ifd-f8/ifd-f8.component';
import { IfdF9Component } from './Forms/DOE/IFD/ifd-f9/ifd-f9.component';
import { IfdF4Component } from './Forms/DOE/IFD/ifd-f4/ifd-f4.component';
import { IfdF6Component } from './Forms/DOE/IFD/ifd-f6/ifd-f6.component';
import { IfdF7Component } from './Forms/DOE/IFD/ifd-f7/ifd-f7.component';
import { HrdF1Component } from './Forms/DHRTM/HRD/hrd-f1/hrd-f1.component';
import { HrdF2Component } from './Forms/DHRTM/HRD/hrd-f2/hrd-f2.component';
import { HrdF3Component } from './Forms/DHRTM/HRD/hrd-f3/hrd-f3.component';
import { KcF1Component } from './Forms/DHRTM/KC/kc-f1/kc-f1.component';
import { KcF2Component } from './Forms/DHRTM/KC/kc-f2/kc-f2.component';
import { KcF6Component } from './Forms/DHRTM/KC/kc-f6/kc-f6.component';
import { KcF7Component } from './Forms/DHRTM/KC/kc-f7/kc-f7.component';
import { KcF8Component } from './Forms/DHRTM/KC/kc-f8/kc-f8.component';
import { KcF9Component } from './Forms/DHRTM/KC/kc-f9/kc-f9.component';
import { TmdF1Component } from './Forms/DHRTM/TMD/tmd-f1/tmd-f1.component';
import { TmdF2Component } from './Forms/DHRTM/TMD/tmd-f2/tmd-f2.component';
import { DoiF1Component } from './Forms/DOI/doi-f1/doi-f1.component';
import { DoiF2Component } from './Forms/DOI/doi-f2/doi-f2.component';
import { DoiF3Component } from './Forms/DOI/doi-f3/doi-f3.component';
import { DoiF4Component } from './Forms/DOI/doi-f4/doi-f4.component';
import { DoiF5Component } from './Forms/DOI/doi-f5/doi-f5.component';
import { DoiF6Component } from './Forms/DOI/doi-f6/doi-f6.component';
import { DoiF7Component } from './Forms/DOI/doi-f7/doi-f7.component';
import { DoiF9Component } from './Forms/DOI/doi-f9/doi-f9.component';
import { DoiF12Component } from './Forms/DOI/doi-f12/doi-f12.component';
import { ComnF25Component } from './Forms/DIT/COMN/comn-f25/comn-f25.component';
import { SddF3Component } from './Forms/DIT/SDD/sdd-f3/sdd-f3.component';
import { SddF4Component } from './Forms/DIT/SDD/sdd-f4/sdd-f4.component';
import { SddF5Component } from './Forms/DIT/SDD/sdd-f5/sdd-f5.component';
import { SddF6Component } from './Forms/DIT/SDD/sdd-f6/sdd-f6.component';
import { SddF7Component } from './Forms/DIT/SDD/sdd-f7/sdd-f7.component';
import { CndF16Component } from './Forms/DIT/CND/cnd-f16/cnd-f16.component';
import { CndF17Component } from './Forms/DIT/CND/cnd-f17/cnd-f17.component';
import { CndF19Component } from './Forms/DIT/CND/cnd-f19/cnd-f19.component';
import { CndF22Component } from './Forms/DIT/CND/cnd-f22/cnd-f22.component';
import { CndF23Component } from './Forms/DIT/CND/cnd-f23/cnd-f23.component';
import { CndF24Component } from './Forms/DIT/CND/cnd-f24/cnd-f24.component';
import { CndF20Component } from './Forms/DIT/CND/cnd-f20/cnd-f20.component';
import { CndF18Component } from './Forms/DIT/CND/cnd-f18/cnd-f18.component';
import { IfdF3Component } from './Forms/DOE/IFD/ifd-f3/ifd-f3.component';
import { PddF3Component } from './Forms/DOE/PDD/pdd-f3/pdd-f3.component';
import { PddF29Component } from './Forms/DOE/PDD/pdd-f29/pdd-f29.component';
import { KcF3Component } from './Forms/DHRTM/KC/kc-f3/kc-f3.component';
import { KcF4Component } from './Forms/DHRTM/KC/kc-f4/kc-f4.component';
import { KcF5Component } from './Forms/DHRTM/KC/kc-f5/kc-f5.component';
import { AllF1Component } from './Forms/DOFS/ALL/all-f1/all-f1.component';
import { HtdF1Component } from './Forms/DOFS/HTD/htd-f1/htd-f1.component';
import { DoadF1Component } from './Forms/DOAD/doad-f1/doad-f1.component';
import { DoadF2Component } from './Forms/DOAD/doad-f2/doad-f2.component';
import { DoatF1Component } from './Forms/DOAT/doat-f1/doat-f1.component';
import { DoatF2Component } from './Forms/DOAT/doat-f2/doat-f2.component';
import { DoatF3Component } from './Forms/DOAT/doat-f3/doat-f3.component';
import { DoatF4Component } from './Forms/DOAT/doat-f4/doat-f4.component';
import { DoatF5Component } from './Forms/DOAT/doat-f5/doat-f5.component';
import { DoatF6Component } from './Forms/DOAT/doat-f6/doat-f6.component';
import { DoatF7Component } from './Forms/DOAT/doat-f7/doat-f7.component';
import { DoatF8Component } from './Forms/DOAT/doat-f8/doat-f8.component';
import { HpdF4Component } from './Forms/DOABP/HPD/hpd-f4/hpd-f4.component';
import { HpdF5Component } from './Forms/DOABP/HPD/hpd-f5/hpd-f5.component';
import { RpdF1Component } from './Forms/DOABP/RPD/rpd-f1/rpd-f1.component';
import { RpdF2Component } from './Forms/DOABP/RPD/rpd-f2/rpd-f2.component';
import { RpdF3Component } from './Forms/DOABP/RPD/rpd-f3/rpd-f3.component';
import { RpdF8Component } from './Forms/DOABP/RPD/rpd-f8/rpd-f8.component';
import { RpdF9Component } from './Forms/DOABP/RPD/rpd-f9/rpd-f9.component';
import { DospF2Component } from './Forms/DOSP/dosp-f2/dosp-f2.component';
import { DospF3Component } from './Forms/DOSP/dosp-f3/dosp-f3.component';
import { IvvF1Component } from './Forms/DASQA/IVV/ivv-f1/ivv-f1.component';
import { IvvF3Component } from './Forms/DASQA/IVV/ivv-f3/ivv-f3.component';
import { IvvF4Component } from './Forms/DASQA/IVV/ivv-f4/ivv-f4.component';
import { IvvF5Component } from './Forms/DASQA/IVV/ivv-f5/ivv-f5.component';
import { IvvF6Component } from './Forms/DASQA/IVV/ivv-f6/ivv-f6.component';
import { IvvF8Component } from './Forms/DASQA/IVV/ivv-f8/ivv-f8.component';
import { AllF2Component } from './Forms/DOFS/ALL/all-f2/all-f2.component';
import { AllF3Component } from './Forms/DOFS/ALL/all-f3/all-f3.component';
import { AllF8Component } from './Forms/DOFS/ALL/all-f8/all-f8.component';
import { AllF4Component } from './Forms/DOFS/ALL/all-f4/all-f4.component';
import { CpmF1Component } from './Forms/QMS/CPM/cpm-f1/cpm-f1.component';
import { CpmF2Component } from './Forms/QMS/CPM/cpm-f2/cpm-f2.component';
import { CpmF3Component } from './Forms/QMS/CPM/cpm-f3/cpm-f3.component';
import { CpmF4Component } from './Forms/QMS/CPM/cpm-f4/cpm-f4.component';
import { CpmF5Component } from './Forms/QMS/CPM/cpm-f5/cpm-f5.component';
import { CpmF6Component } from './Forms/QMS/CPM/cpm-f6/cpm-f6.component';
import { CpmF9Component } from './Forms/QMS/CPM/cpm-f9/cpm-f9.component';
import { CpmF10Component } from './Forms/QMS/CPM/cpm-f10/cpm-f10.component';
import { CpmF11Component } from './Forms/QMS/CPM/cpm-f11/cpm-f11.component';
import { CpmF12Component } from './Forms/QMS/CPM/cpm-f12/cpm-f12.component';
import { CpmF15Component } from './Forms/QMS/CPM/cpm-f15/cpm-f15.component';
import { CpmF16Component } from './Forms/QMS/CPM/cpm-f16/cpm-f16.component';
import { CpmF17Component } from './Forms/QMS/CPM/cpm-f17/cpm-f17.component';
import { CpmF18Component } from './Forms/QMS/CPM/cpm-f18/cpm-f18.component';
import { CpmF19Component } from './Forms/QMS/CPM/cpm-f19/cpm-f19.component';
import { CpmF22Component } from './Forms/QMS/CPM/cpm-f22/cpm-f22.component';
import { CpmF21Component } from './Forms/QMS/CPM/cpm-f21/cpm-f21.component';
import { CpmF23Component } from './Forms/QMS/CPM/cpm-f23/cpm-f23.component';
import { CpmF24Component } from './Forms/QMS/CPM/cpm-f24/cpm-f24.component';
import { CpmF25Component } from './Forms/QMS/CPM/cpm-f25/cpm-f25.component';
import { DcpmF2Component } from './Forms/QMS/DCPM/dcpm-f2/dcpm-f2.component';
import { DcpmF3Component } from './Forms/QMS/DCPM/dcpm-f3/dcpm-f3.component';
import { DcpmF4Component } from './Forms/QMS/DCPM/dcpm-f4/dcpm-f4.component';
import { DcpmF5Component } from './Forms/QMS/DCPM/dcpm-f5/dcpm-f5.component';
import { DcpmF6Component } from './Forms/QMS/DCPM/dcpm-f6/dcpm-f6.component';
import { DcpmF7Component } from './Forms/QMS/DCPM/dcpm-f7/dcpm-f7.component';
import { DcpmF8Component } from './Forms/QMS/DCPM/dcpm-f8/dcpm-f8.component';
import { DcpmF9Component } from './Forms/QMS/DCPM/dcpm-f9/dcpm-f9.component';
import { DcpmF10Component } from './Forms/QMS/DCPM/dcpm-f10/dcpm-f10.component';
import { DcpmF11Component } from './Forms/QMS/DCPM/dcpm-f11/dcpm-f11.component';
import { DcpmF12Component } from './Forms/QMS/DCPM/dcpm-f12/dcpm-f12.component';
import { DcpmF13Component } from './Forms/QMS/DCPM/dcpm-f13/dcpm-f13.component';
import { CpmF14Component } from './Forms/QMS/CPM/cpm-f14/cpm-f14.component';
import { CcdF2Component } from './Forms/DOCD/CCD/ccd-f2/ccd-f2.component';
import { CcdF9Component } from './Forms/DOCD/CCD/ccd-f9/ccd-f9.component';
import { CfdF1Component } from './Forms/DOCD/CFD/cfd-f1/cfd-f1.component';
import { CfdF2Component } from './Forms/DOCD/CFD/cfd-f2/cfd-f2.component';
import { CfdF9Component } from './Forms/DOCD/CFD/cfd-f9/cfd-f9.component';
import { StfF5Component } from './Forms/DOFS/STF/stf-f5/stf-f5.component';
import { StfF7Component } from './Forms/DOFS/STF/stf-f7/stf-f7.component';
import { StfF9Component } from './Forms/DOFS/STF/stf-f9/stf-f9.component';
import { StfF10Component } from './Forms/DOFS/STF/stf-f10/stf-f10.component';
import { StfF14Component } from './Forms/DOFS/STF/stf-f14/stf-f14.component';
import { StfF18Component } from './Forms/DOFS/STF/stf-f18/stf-f18.component';
import { StfF19Component } from './Forms/DOFS/STF/stf-f19/stf-f19.component';
import { StfF20Component } from './Forms/DOFS/STF/stf-f20/stf-f20.component';
import { StfF21Component } from './Forms/DOFS/STF/stf-f21/stf-f21.component';
import { StfF22Component } from './Forms/DOFS/STF/stf-f22/stf-f22.component';
import { StfF23Component } from './Forms/DOFS/STF/stf-f23/stf-f23.component';
import { StfF24Component } from './Forms/DOFS/STF/stf-f24/stf-f24.component';
import { StfF25Component } from './Forms/DOFS/STF/stf-f25/stf-f25.component';
import { StfF26Component } from './Forms/DOFS/STF/stf-f26/stf-f26.component';
import { StfF12Component } from './Forms/DOFS/STF/stf-f12/stf-f12.component';
import { StfF13Component } from './Forms/DOFS/STF/stf-f13/stf-f13.component';
import { StfF15Component } from './Forms/DOFS/STF/stf-f15/stf-f15.component';
import { StfF16Component } from './Forms/DOFS/STF/stf-f16/stf-f16.component';
import { StfF17Component } from './Forms/DOFS/STF/stf-f17/stf-f17.component';
import { LpdF1Component } from './Forms/DOLP/LPD/lpd-f1/lpd-f1.component';
import { LpdF2Component } from './Forms/DOLP/LPD/lpd-f2/lpd-f2.component';
import { LpdF3Component } from './Forms/DOLP/LPD/lpd-f3/lpd-f3.component';
import { LpdF4Component } from './Forms/DOLP/LPD/lpd-f4/lpd-f4.component';
import { LpdF5Component } from './Forms/DOLP/LPD/lpd-f5/lpd-f5.component';
import { LpdF6Component } from './Forms/DOLP/LPD/lpd-f6/lpd-f6.component';
import { LpdF7Component } from './Forms/DOLP/LPD/lpd-f7/lpd-f7.component';
import { LpdF8Component } from './Forms/DOLP/LPD/lpd-f8/lpd-f8.component';
import { LpdF9Component } from './Forms/DOLP/LPD/lpd-f9/lpd-f9.component';
import { LpdF10Component } from './Forms/DOLP/LPD/lpd-f10/lpd-f10.component';
import { LpdF11Component } from './Forms/DOLP/LPD/lpd-f11/lpd-f11.component';
import { LpdF12Component } from './Forms/DOLP/LPD/lpd-f12/lpd-f12.component';
import { LpdF13Component } from './Forms/DOLP/LPD/lpd-f13/lpd-f13.component';
import { LpdF14Component } from './Forms/DOLP/LPD/lpd-f14/lpd-f14.component';
import { LpdF15Component } from './Forms/DOLP/LPD/lpd-f15/lpd-f15.component';
import { LpdF16Component } from './Forms/DOLP/LPD/lpd-f16/lpd-f16.component';
import { LpdF17Component } from './Forms/DOLP/LPD/lpd-f17/lpd-f17.component';
import { LpdF18Component } from './Forms/DOLP/LPD/lpd-f18/lpd-f18.component';
import { LpdF19Component } from './Forms/DOLP/LPD/lpd-f19/lpd-f19.component';
import { LpdF20Component } from './Forms/DOLP/LPD/lpd-f20/lpd-f20.component';
import { LpdF21Component } from './Forms/DOLP/LPD/lpd-f21/lpd-f21.component';
import { LpdF22Component } from './Forms/DOLP/LPD/lpd-f22/lpd-f22.component';
import { LpdF23Component } from './Forms/DOLP/LPD/lpd-f23/lpd-f23.component';
import { LpdF24Component } from './Forms/DOLP/LPD/lpd-f24/lpd-f24.component';
import { LpdF25Component } from './Forms/DOLP/LPD/lpd-f25/lpd-f25.component';
import { PpdF1Component } from './Forms/DOLP/PPD/ppd-f1/ppd-f1.component';
import { PpdF2Component } from './Forms/DOLP/PPD/ppd-f2/ppd-f2.component';
import { PpdF3Component } from './Forms/DOLP/PPD/ppd-f3/ppd-f3.component';
import { PpdF4Component } from './Forms/DOLP/PPD/ppd-f4/ppd-f4.component';
import { PpdF5Component } from './Forms/DOLP/PPD/ppd-f5/ppd-f5.component';
import { PpdF6Component } from './Forms/DOLP/PPD/ppd-f6/ppd-f6.component';
import { PpdF7Component } from './Forms/DOLP/PPD/ppd-f7/ppd-f7.component';
import { PpdF8Component } from './Forms/DOLP/PPD/ppd-f8/ppd-f8.component';
import { CcdF1Component } from './Forms/DOCD/CCD/ccd-f1/ccd-f1.component';
import { DwstF13Component } from './Forms/DWST/dwst-f13/dwst-f13.component';
import { DosF1Component } from './Forms/DOS/dos-f1/dos-f1.component';
import { StfF11Component } from './Forms/DOFS/STF/stf-f11/stf-f11.component';
import { StfF8Component } from './Forms/DOFS/STF/stf-f8/stf-f8.component';
import { NdedF1Component } from './Forms/GDTS/NDED/nded-f1/nded-f1.component';
import { NdedF2Component } from './Forms/GDTS/NDED/nded-f2/nded-f2.component';
import { NdedF3Component } from './Forms/GDTS/NDED/nded-f3/nded-f3.component';
import { NdedF4Component } from './Forms/GDTS/NDED/nded-f4/nded-f4.component';
import { NdedF5Component } from './Forms/GDTS/NDED/nded-f5/nded-f5.component';
import { NdedF6Component } from './Forms/GDTS/NDED/nded-f6/nded-f6.component';
import { NdedF7Component } from './Forms/GDTS/NDED/nded-f7/nded-f7.component';
import { NdedF8Component } from './Forms/GDTS/NDED/nded-f8/nded-f8.component';
import { NdedF9Component } from './Forms/GDTS/NDED/nded-f9/nded-f9.component';
import { NdedF10Component } from './Forms/GDTS/NDED/nded-f10/nded-f10.component';
import { NdedF11Component } from './Forms/GDTS/NDED/nded-f11/nded-f11.component';
import { NdedF12Component } from './Forms/GDTS/NDED/nded-f12/nded-f12.component';
import { NdedF13Component } from './Forms/GDTS/NDED/nded-f13/nded-f13.component';
import { NdedF14Component } from './Forms/GDTS/NDED/nded-f14/nded-f14.component';
import { NdedF15Component } from './Forms/GDTS/NDED/nded-f15/nded-f15.component';
import { NdedF16Component } from './Forms/GDTS/NDED/nded-f16/nded-f16.component';
import { NdedF17Component } from './Forms/GDTS/NDED/nded-f17/nded-f17.component';
import { NdedF18Component } from './Forms/GDTS/NDED/nded-f18/nded-f18.component';
import { NdedF19Component } from './Forms/GDTS/NDED/nded-f19/nded-f19.component';
import { NdedF20Component } from './Forms/GDTS/NDED/nded-f20/nded-f20.component';
import { StfF28Component } from './Forms/DOFS/STF/stf-f28/stf-f28.component';
import { DpepF1Component } from './Forms/DPEP/dpep-f1/dpep-f1.component';
import { DpepF2Component } from './Forms/DPEP/dpep-f2/dpep-f2.component';
import { DpepF3Component } from './Forms/DPEP/dpep-f3/dpep-f3.component';
import { DpepF4Component } from './Forms/DPEP/dpep-f4/dpep-f4.component';
import { DpepF5Component } from './Forms/DPEP/dpep-f5/dpep-f5.component';
import { DpepF6Component } from './Forms/DPEP/dpep-f6/dpep-f6.component';
import { DpepF7Component } from './Forms/DPEP/dpep-f7/dpep-f7.component';
import { DrqaF2Component } from './Forms/DRQA/drqa-f2/drqa-f2.component';
import { DrqaF3Component } from './Forms/DRQA/drqa-f3/drqa-f3.component';
import { DrqaF4Component } from './Forms/DRQA/drqa-f4/drqa-f4.component';
import { DrqaF1Component } from './Forms/DRQA/drqa-f1/drqa-f1.component';
import { SfeedF1Component } from './Forms/GDTS/SFEED/sfeed-f1/sfeed-f1.component';
import { SfeedF2Component } from './Forms/GDTS/SFEED/sfeed-f2/sfeed-f2.component';
import { SfeedF3Component } from './Forms/GDTS/SFEED/sfeed-f3/sfeed-f3.component';
import { SfeedF4Component } from './Forms/GDTS/SFEED/sfeed-f4/sfeed-f4.component';
import { SfeedF5Component } from './Forms/GDTS/SFEED/sfeed-f5/sfeed-f5.component';
import { SfeedF6Component } from './Forms/GDTS/SFEED/sfeed-f6/sfeed-f6.component';
import { SfeedF7Component } from './Forms/GDTS/SFEED/sfeed-f7/sfeed-f7.component';
import { SfeedF8Component } from './Forms/GDTS/SFEED/sfeed-f8/sfeed-f8.component';
import { SfeedF9Component } from './Forms/GDTS/SFEED/sfeed-f9/sfeed-f9.component';
import { SfeedF11Component } from './Forms/GDTS/SFEED/sfeed-f11/sfeed-f11.component';
import { SfeedF12Component } from './Forms/GDTS/SFEED/sfeed-f12/sfeed-f12.component';
import { SfeedF13Component } from './Forms/GDTS/SFEED/sfeed-f13/sfeed-f13.component';
import { SfeedF14Component } from './Forms/GDTS/SFEED/sfeed-f14/sfeed-f14.component';
import { SfeedF15Component } from './Forms/GDTS/SFEED/sfeed-f15/sfeed-f15.component';
import { SfeedF16Component } from './Forms/GDTS/SFEED/sfeed-f16/sfeed-f16.component';
import { SfeedF17Component } from './Forms/GDTS/SFEED/sfeed-f17/sfeed-f17.component';
import { SfeedF18Component } from './Forms/GDTS/SFEED/sfeed-f18/sfeed-f18.component';
import { SfeedF19Component } from './Forms/GDTS/SFEED/sfeed-f19/sfeed-f19.component';
import { RadF1Component } from './Forms/DOMS/RAD/rad-f1/rad-f1.component';
import { FireF1Component } from './Forms/DOMS/FIRE/fire-f1/fire-f1.component';
import { FireF2Component } from './Forms/DOMS/FIRE/fire-f2/fire-f2.component';
import { WsF1Component } from './Forms/DOMS/WS/ws-f1/ws-f1.component';
import { WsF2Component } from './Forms/DOMS/WS/ws-f2/ws-f2.component';
import { WsF3Component } from './Forms/DOMS/WS/ws-f3/ws-f3.component';
import { WsF4Component } from './Forms/DOMS/WS/ws-f4/ws-f4.component';
import { AdminF4Component } from './Forms/DOMS/ADMIN/admin-f4/admin-f4.component';
import { AdminF1Component } from './Forms/DOMS/ADMIN/admin-f1/admin-f1.component';
import { AdminF5Component } from './Forms/DOMS/ADMIN/admin-f5/admin-f5.component';
import { DisplayComponent } from './display/display.component';
import { StfF1Component } from './Forms/DOFS/STF/stf-f1/stf-f1.component';
import { StfF2Component } from './Forms/DOFS/STF/stf-f2/stf-f2.component';
import { StfF3Component } from './Forms/DOFS/STF/stf-f3/stf-f3.component';
import { StfF4Component } from './Forms/DOFS/STF/stf-f4/stf-f4.component';
import { DcpmF1Component } from './Forms/QMS/DCPM/dcpm-f1/dcpm-f1.component';
import { RpdF10Component } from './Forms/DOABP/RPD/rpd-f10/rpd-f10.component';
import { HtdF14Component } from './Forms/DOFS/HTD/htd-f14/htd-f14.component';
import { CptdF1Component } from './Forms/DOC/CPTD/cptd-f1/cptd-f1.component';
import { CptdF2Component } from './Forms/DOC/CPTD/cptd-f2/cptd-f2.component';
import { CptdF3Component } from './Forms/DOC/CPTD/cptd-f3/cptd-f3.component';
import { CptdF4Component } from './Forms/DOC/CPTD/cptd-f4/cptd-f4.component';
import { CptdF5Component } from './Forms/DOC/CPTD/cptd-f5/cptd-f5.component';
import { CptdF6Component } from './Forms/DOC/CPTD/cptd-f6/cptd-f6.component';
import { CptdF7Component } from './Forms/DOC/CPTD/cptd-f7/cptd-f7.component';
import { CptdF8Component } from './Forms/DOC/CPTD/cptd-f8/cptd-f8.component';
import { SdadIIIF1Component } from './Forms/DOFS/SDADI-II/sdad-i-ii-f1/sdad-i-ii-f1.component';
import { SdadIIIF31Component } from './Forms/DOFS/SDADI-II/sdad-i-ii-f31/sdad-i-ii-f31.component';
import { SdadIIIF32Component } from './Forms/DOFS/SDADI-II/sdad-i-ii-f32/sdad-i-ii-f32.component';
import { CmdF1Component } from './Forms/DOC/CMD/cmd-f1/cmd-f1.component';
import { CmdF2Component } from './Forms/DOC/CMD/cmd-f2/cmd-f2.component';
import { CmdF3Component } from './Forms/DOC/CMD/cmd-f3/cmd-f3.component';
import { CmpdF1Component } from './Forms/DOC/CMPD/cmpd-f1/cmpd-f1.component';
import { CmpdF2Component } from './Forms/DOC/CMPD/cmpd-f2/cmpd-f2.component';
import { CmpdF3Component } from './Forms/DOC/CMPD/cmpd-f3/cmpd-f3.component';
import { CptdF9Component } from './Forms/DOC/CPTD/cptd-f9/cptd-f9.component';
import { IvvF2Component } from './Forms/DASQA/IVV/ivv-f2/ivv-f2.component';
import { IvvF7Component } from './Forms/DASQA/IVV/ivv-f7/ivv-f7.component';
import { IvvF9Component } from './Forms/DASQA/IVV/ivv-f9/ivv-f9.component';
import { IvvF10Component } from './Forms/DASQA/IVV/ivv-f10/ivv-f10.component';
import { CptdF10Component } from './Forms/DOC/CPTD/cptd-f10/cptd-f10.component';
import { SdadIIiF2Component } from './Forms/DOFS/SDADI-II/sdad-i-ii-f2/sdad-i-ii-f2.component';
import { CpmF8Component } from './Forms/QMS/CPM/cpm-f8/cpm-f8.component';
import { CpmF13Component } from './Forms/QMS/CPM/cpm-f13/cpm-f13.component';
import { HrdF4Component } from './Forms/DHRTM/HRD/hrd-f4/hrd-f4.component';
import { HtdF3Component } from './Forms/DOFS/HTD/htd-f3/htd-f3.component';
import { HtdF6Component } from './Forms/DOFS/HTD/htd-f6/htd-f6.component';
import { HtdF9Component } from './Forms/DOFS/HTD/htd-f9/htd-f9.component';
import { HtdF13Component } from './Forms/DOFS/HTD/htd-f13/htd-f13.component';
import { HtdF12Component } from './Forms/DOFS/HTD/htd-f12/htd-f12.component';
import { HtdF11Component } from './Forms/DOFS/HTD/htd-f11/htd-f11.component';
import { HtdF8Component } from './Forms/DOFS/HTD/htd-f8/htd-f8.component';
import { HtdF10Component } from './Forms/DOFS/HTD/htd-f10/htd-f10.component';
import { HtdF2Component } from './Forms/DOFS/HTD/htd-f2/htd-f2.component';
import { HtdF7Component } from './Forms/DOFS/HTD/htd-f7/htd-f7.component';
import { ModalComponent } from './modal/modal.component';
import { SfeedF10Component } from './Forms/GDTS/SFEED/sfeed-f10/sfeed-f10.component';
import { AlertMessageComponent } from './alert-message/alert-message.component';
import { FormComponent } from './form/form.component';
import { LoginDetailsComponent } from './login-details/login-details.component';
import { DraftComponent } from './draft/draft.component';
import { ForgottenPasswordComponent } from './forgotten-password/forgotten-password.component';
import { DocumentComponent } from './document/document.component';
import { MeetingsComponent } from './meetings/meetings.component';
import { UserAccountsComponent } from './user-accounts/user-accounts.component';
import { SentComponent } from './sent/sent.component';
import { AwardsComponent } from './awards/awards.component';
import { AboutUsComponent } from './about-us/about-us.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    HomeComponent,
    PddF1Component,
    PddF2Component,
    PddF4Component,
    PddF11Component,
    PddF12Component,
    PddF14Component,
    PddF15Component,
    PddF16Component,
    PddF5Component,
    PddF8Component,
    PddF9Component,
    PddF17Component,
    StfF6Component,
    StfF27Component,
    PddF18Component,
    PddF52Component,
    PddF53Component,
    PddF21Component,
    PddF20Component,
    PddF42Component,
    PddF48Component,
    PddF51Component,
    AmdF1Component,
    AmdF2Component,
    AmdF3Component,
    AmdF4Component,
    AmdF5Component,
    AmdF6Component,
    AmdF7Component,
    AmdF8Component,
    AmdF9Component,
    SedF1Component,
    SedF2Component,
    SedF3Component,
    PddF24Component,
    PddF25Component,
    PddF23Component,
    PddF19Component,
    SfdF2Component,
    SfdF3Component,
    SfdF4Component,
    SfdF5Component,
    SfdF1Component,
    IfdF1Component,
    IfdF2Component,
    IfdF5Component,
    IfdF8Component,
    IfdF9Component,
    IfdF4Component,
    IfdF6Component,
    IfdF7Component,
    HrdF1Component,
    HrdF2Component,
    HrdF3Component,
    KcF1Component,
    KcF2Component,
    KcF6Component,
    KcF7Component,
    KcF8Component,
    KcF9Component,
    TmdF1Component,
    TmdF2Component,
    DoiF1Component,
    DoiF2Component,
    DoiF3Component,
    DoiF4Component,
    DoiF5Component,
    DoiF6Component,
    DoiF7Component,
    DoiF9Component,
    DoiF12Component,
    ComnF25Component,
    SddF3Component,
    SddF4Component,
    SddF5Component,
    SddF6Component,
    SddF7Component,
    CndF16Component,
    CndF17Component,
    CndF19Component,
    CndF22Component,
    CndF23Component,
    CndF24Component,
    CndF20Component,
    CndF18Component,
    IfdF3Component,
    PddF3Component,
    PddF29Component,
    KcF3Component,
    KcF4Component,
    KcF5Component,
    AllF1Component,
    HtdF1Component,
    DoadF1Component,
    DoadF2Component,
    DoatF1Component,
    DoatF2Component,
    DoatF3Component,
    DoatF4Component,
    DoatF5Component,
    DoatF6Component,
    DoatF7Component,
    DoatF8Component,
    HpdF4Component,
    HpdF5Component,
    RpdF1Component,
    RpdF2Component,
    RpdF3Component,
    RpdF8Component,
    RpdF9Component,
    DospF2Component,
    DospF3Component,
    IvvF1Component,
    IvvF3Component,
    IvvF4Component,
    IvvF5Component,
    IvvF6Component,
    IvvF8Component,
    AllF2Component,
    AllF3Component,
    AllF8Component,
    AllF4Component,
    CpmF1Component,
    CpmF2Component,
    CpmF3Component,
    CpmF4Component,
    CpmF5Component,
    CpmF6Component,
    CpmF9Component,
    CpmF10Component,
    CpmF11Component,
    CpmF12Component,
    CpmF15Component,
    CpmF16Component,
    CpmF17Component,
    CpmF18Component,
    CpmF19Component,
    CpmF22Component,
    CpmF21Component,
    CpmF23Component,
    CpmF24Component,
    CpmF25Component,
    DcpmF2Component,
    DcpmF3Component,
    DcpmF4Component,
    DcpmF5Component,
    DcpmF6Component,
    DcpmF7Component,
    DcpmF8Component,
    DcpmF9Component,
    DcpmF10Component,
    DcpmF11Component,
    DcpmF12Component,
    DcpmF13Component,
    CpmF14Component,
    CcdF2Component,
    CcdF9Component,
    CfdF1Component,
    CfdF2Component,
    CfdF9Component,
    StfF5Component,
    StfF7Component,
    StfF9Component,
    StfF10Component,
    StfF14Component,
    StfF18Component,
    StfF19Component,
    StfF20Component,
    StfF21Component,
    StfF22Component,
    StfF23Component,
    StfF24Component,
    StfF25Component,
    StfF26Component,
    StfF12Component,
    StfF13Component,
    StfF15Component,
    StfF16Component,
    StfF17Component,
    LpdF1Component,
    LpdF2Component,
    LpdF3Component,
    LpdF4Component,
    LpdF5Component,
    LpdF6Component,
    LpdF7Component,
    LpdF8Component,
    LpdF9Component,
    LpdF10Component,
    LpdF11Component,
    LpdF12Component,
    LpdF13Component,
    LpdF14Component,
    LpdF15Component,
    LpdF16Component,
    LpdF17Component,
    LpdF18Component,
    LpdF19Component,
    LpdF20Component,
    LpdF21Component,
    LpdF22Component,
    LpdF23Component,
    LpdF24Component,
    LpdF25Component,
    PpdF1Component,
    PpdF2Component,
    PpdF3Component,
    PpdF4Component,
    PpdF5Component,
    PpdF6Component,
    PpdF7Component,
    PpdF8Component,
    CcdF1Component,
    DwstF13Component,
    DosF1Component,
    StfF11Component,
    StfF8Component,
    NdedF1Component,
    NdedF2Component,
    NdedF3Component,
    NdedF4Component,
    NdedF5Component,
    NdedF6Component,
    NdedF7Component,
    NdedF8Component,
    NdedF9Component,
    NdedF10Component,
    NdedF11Component,
    NdedF12Component,
    NdedF13Component,
    NdedF14Component,
    NdedF15Component,
    NdedF16Component,
    NdedF17Component,
    NdedF18Component,
    NdedF19Component,
    NdedF20Component,
    StfF28Component,
    DpepF1Component,
    DpepF2Component,
    DpepF3Component,
    DpepF4Component,
    DpepF5Component,
    DpepF6Component,
    DpepF7Component,
    DrqaF2Component,
    DrqaF3Component,
    DrqaF4Component,
    DrqaF1Component,
    SfeedF1Component,
    SfeedF2Component,
    SfeedF3Component,
    SfeedF4Component,
    SfeedF5Component,
    SfeedF6Component,
    SfeedF7Component,
    SfeedF8Component,
    SfeedF9Component,
    SfeedF11Component,
    SfeedF12Component,
    SfeedF13Component,
    SfeedF14Component,
    SfeedF15Component,
    SfeedF16Component,
    SfeedF17Component,
    SfeedF18Component,
    SfeedF19Component,
    RadF1Component,
    FireF1Component,
    FireF2Component,
    WsF1Component,
    WsF2Component,
    WsF3Component,
    WsF4Component,
    AdminF4Component,
    AdminF1Component,
    AdminF5Component,
    DisplayComponent,
    StfF1Component,
    StfF2Component,
    StfF3Component,
    StfF4Component,
    DcpmF1Component,
    RpdF10Component,
    HtdF14Component,
    CptdF1Component,
    CptdF2Component,
    CptdF3Component,
    CptdF4Component,
    CptdF5Component,
    CptdF6Component,
    CptdF7Component,
    CptdF8Component,
    SdadIIIF1Component,
    SdadIIIF31Component,
    SdadIIIF32Component,
    CmdF1Component,
    CmdF2Component,
    CmdF3Component,
    CmpdF1Component,
    CmpdF2Component,
    CmpdF3Component,
    CptdF9Component,
    IvvF2Component,
    IvvF7Component,
    IvvF9Component,
    IvvF10Component,
    CptdF10Component,
    SdadIIiF2Component,
    CpmF8Component,
    CpmF13Component,
    HrdF4Component,
    HtdF3Component,
    HtdF6Component,
    HtdF9Component,
    HtdF13Component,
    HtdF12Component,
    HtdF11Component,
    HtdF8Component,
    HtdF10Component,
    HtdF2Component,
    HtdF7Component,
    ModalComponent,
    SfeedF10Component,
    AlertMessageComponent,
    FormComponent,
    LoginDetailsComponent,
    DraftComponent,
    ForgottenPasswordComponent,
    DocumentComponent,
    MeetingsComponent,
    UserAccountsComponent,
    SentComponent,
    AwardsComponent,
    AboutUsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
