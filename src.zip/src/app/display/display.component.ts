import { Component, Input   } from '@angular/core';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent {
//   mainTypes = [
//     { name: 'AMD Forms', subtypes: ['amd-f1', 'amd-f2', 'amd-f3', 'amd-f4', 'amd-f5', 'amd-f6', 'amd-f7', 'amd-f8', 'amd-f9'], showSubtypes: false },
//   ];

//   toggleSubtypes(mainType: any) {
//     mainType.showSubtypes = !mainType.showSubtypes;
//   this.mainTypes.forEach(type => {
//     if (type !== mainType) {
//       type.showSubtypes = false;
//     }
//   });
// }
activeMenuItem: string = '';

  setActiveMenuItem(item: string) {
    this.activeMenuItem = item;
  }
@Input() data!: any[];
expandedDivisions: { [key: string]: boolean } = {};
expandedSubdivisions: { [key: string]: boolean } = {};

toggleDivision(divisionName: string) {
  this.expandedDivisions[divisionName] = !this.expandedDivisions[divisionName];
}

toggleSubdivision(subdivisionName: string) {
  this.expandedSubdivisions[subdivisionName] = !this.expandedSubdivisions[subdivisionName];
}
}
