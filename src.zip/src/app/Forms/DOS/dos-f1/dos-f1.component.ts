import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dos-f1',
  templateUrl: './dos-f1.component.html',
  styleUrls: ['./dos-f1.component.css'],
})
export class DosF1Component {
  DOSf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOSf1 = this.formBuilder.group({
      division: [''],
      designPlan: [''],
      planPeriod: [''],
      divisionHead: [''],
      technologyDirector: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DOSf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      activity: [''],
      description: [''],
      resp: [''],
      pdc: [''],
      input: [''],
      from: [''],
      output: [''],
      remarks: [''],

    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.DOSf1.value;
    const DOSf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOSf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOSf1.value;
    const DOSf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOSf1Data);

    console.log(payload);
  }
}
