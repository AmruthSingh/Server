import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DosF1Component } from './dos-f1.component';

describe('DosF1Component', () => {
  let component: DosF1Component;
  let fixture: ComponentFixture<DosF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DosF1Component]
    });
    fixture = TestBed.createComponent(DosF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
