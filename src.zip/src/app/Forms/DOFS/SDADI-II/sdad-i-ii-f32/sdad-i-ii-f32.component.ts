import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sdad-i-ii-f32',
  templateUrl: './sdad-i-ii-f32.component.html',
  styleUrls: ['./sdad-i-ii-f32.component.css'],
})
export class SdadIIIF32Component {
  SDADf32: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SDADf32 = this.formBuilder.group({
      review:[''],
      date: [''],
      customer: [''],
      airframe: [''],
      applicationdoc: [''],
      chairman: [''],
      customers:[''],
      interface: [''],
      specialist: [''],
      none:[''],
      systemManager: [''],
      memberSecretary: [''],
      submitDate: [''],
      TechDir:[''],
      designRev: [''],
      dateRec:[''],
      designReview: [''],
      dt: [''],
      custom:[''],
      airframeSubSys: [''],
      sysManager: [''],
      cust: [''],
      techDir: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SDADf32.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      no: [''],
      action: [''],
      resp: [''],
      pdc: [''],
      complDate: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SDADf32.value;
    const SDADf32Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SDADf32Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SDADf32.value;
    const SDADf32Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SDADf32Data);

    console.log(payload);
  }
}
