import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SdadIIIF32Component } from './sdad-i-ii-f32.component';

describe('SdadIIIF32Component', () => {
  let component: SdadIIIF32Component;
  let fixture: ComponentFixture<SdadIIIF32Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SdadIIIF32Component]
    });
    fixture = TestBed.createComponent(SdadIIIF32Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
