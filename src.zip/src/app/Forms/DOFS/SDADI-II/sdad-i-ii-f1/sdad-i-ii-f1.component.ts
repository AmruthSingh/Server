import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sdad-i-ii-f1',
  templateUrl: './sdad-i-ii-f1.component.html',
  styleUrls: ['./sdad-i-ii-f1.component.css'],
})
export class SdadIIIF1Component {
  SDADf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SDADf1 = this.formBuilder.group({
      customer: ['', Validators.required],
      system: [''],
      form: [''],
      to: [''],
      systemManager:[''],
      divisionHead:[''],
      techDirector:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SDADf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      activityDescription: [''],
      designTeam: [''],
      requiredData: [''],
      interfaceGroup: [''],
      output: [''],
      pdc: [''],
      completionDate: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SDADf1.value;
    const SDADf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SDADf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SDADf1.value;
    const SDADf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SDADf1Data);

    console.log(payload);
  }
}
