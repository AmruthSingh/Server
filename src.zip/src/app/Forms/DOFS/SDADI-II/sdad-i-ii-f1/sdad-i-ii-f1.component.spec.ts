import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SdadIIIF1Component } from './sdad-i-ii-f1.component';

describe('SdadIIIF1Component', () => {
  let component: SdadIIIF1Component;
  let fixture: ComponentFixture<SdadIIIF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SdadIIIF1Component]
    });
    fixture = TestBed.createComponent(SdadIIIF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
