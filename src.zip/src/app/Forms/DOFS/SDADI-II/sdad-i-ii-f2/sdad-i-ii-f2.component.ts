import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sdad-i-ii-f2',
  templateUrl: './sdad-i-ii-f2.component.html',
  styleUrls: ['./sdad-i-ii-f2.component.css'],
})
export class SdadIIiF2Component {
  SDADf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SDADf2 = this.formBuilder.group({
      reportNo: ['', Validators.required],
      copyNo: [''],
      dateOfIssue: [''],
      typeReport: [''],
      title: [''],
      preparedBy: [''],
      approvedBy: [''],
      issueAuth: [''],
      divSign: [''],
      managerSign: [''],
      designSign: [''],
      customerSign: [''],
      othersSign: [''],
    });
  }

  SaveToDraft() {
    const formData = this.SDADf2.value;
    const SDADf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SDADf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SDADf2.value;
    const SDADf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SDADf2Data);

    console.log(payload);
  }
}
