import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SdadIIiF2Component } from './sdad-i-ii-f2.component';

describe('SdadIIiF2Component', () => {
  let component: SdadIIiF2Component;
  let fixture: ComponentFixture<SdadIIiF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SdadIIiF2Component]
    });
    fixture = TestBed.createComponent(SdadIIiF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
