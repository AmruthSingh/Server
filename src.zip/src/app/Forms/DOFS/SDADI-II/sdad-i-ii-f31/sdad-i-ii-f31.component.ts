import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sdad-i-ii-f31',
  templateUrl: './sdad-i-ii-f31.component.html',
  styleUrls: ['./sdad-i-ii-f31.component.css']
})
export class SdadIIIF31Component {
  SDADf31: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SDADf31 = this.formBuilder.group({
      refNo:['',Validators.required],
      date:[''],
      customer:[''],
      airframeSubSys:[''],
      appliDoc :[''],
      briefDesc:[''],
      justiChange :[''],
      divisionalHead :[''],
      signOfSysMan :[''],
      signOfDesign :[''],
      signOfCust:[''],
      signOfOthers :[''],
     dateOfInitiator :[''],
     inputsProvided :[''],
     mutuallyAgreedPDC:[''],
     actualDateOfCompl:[''],
     reviewedBySystem :[''],
     sigOfsysManager :[''],
     signOfHeadOfDivision:[''],
     approvalOfTechDirector:[''],
     sigOfTechnologyDirector :[''],
    });
  }

  SaveToDraft() {
    const formData = this.SDADf31.value;
    const SDADf31Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SDADf31Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SDADf31.value;
    const SDADf31Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SDADf31Data);

    console.log(payload);
  }
}
