import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SdadIIIF31Component } from './sdad-i-ii-f31.component';

describe('SdadIIIF31Component', () => {
  let component: SdadIIIF31Component;
  let fixture: ComponentFixture<SdadIIIF31Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SdadIIIF31Component]
    });
    fixture = TestBed.createComponent(SdadIIIF31Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
