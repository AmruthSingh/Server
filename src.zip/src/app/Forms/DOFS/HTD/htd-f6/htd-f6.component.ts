import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f6',
  templateUrl: './htd-f6.component.html',
  styleUrls: ['./htd-f6.component.css']
})
export class HtdF6Component {
  HTDf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf6 = this.formBuilder.group({
      no: ['', Validators.required],
      noDate: [''],
      proj: [''],
      dir: [''],
      require: [''],
      reqFor: [''],
      noOfThermo: [''],
      typeOfThermo: [''],
      userRepSign: [''],
      userRepName:[''],
      userRepDesign:[''],
      projDirSign: [''],
      projDirName:[''],
      projDirDesign:[''],
      remark:[''],
      logBookNo:[''],
      approve:[''],
      dirSign:[''],
      assignTo:[''],
      assignDate:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      sNo: '',
      itemOfCalib: '',
      sensorDetail: '',
      operatingTemp: '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf6.value;
    const HTDf6Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf6.value;
    const HTDf6Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf6Data);

    console.log(payload);
  }
}
