import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF6Component } from './htd-f6.component';

describe('HtdF6Component', () => {
  let component: HtdF6Component;
  let fixture: ComponentFixture<HtdF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF6Component]
    });
    fixture = TestBed.createComponent(HtdF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
