import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f3',
  templateUrl: './htd-f3.component.html',
  styleUrls: ['./htd-f3.component.css']
})
export class HtdF3Component {
  HTDf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf3 = this.formBuilder.group({
      projSystem: ['', Validators.required],
      planFrom: [''],
      planTo: [''],
      sysManager: [''],
      dirFlightStructure: [''],
      dateOfComplection: [''],
      dateOfApproval: [''],
      resultReview: [''],
      resultIssue: [''],
      reviewDate:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf3.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      jobNo: '',
      user: '',
      inputInf: '',
      activity: '',
      response: '',
      output: '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf3.value;
    const HTDf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf3.value;
    const HTDf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf3Data);

    console.log(payload);
  }
}
