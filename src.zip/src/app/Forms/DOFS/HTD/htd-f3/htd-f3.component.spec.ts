import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF3Component } from './htd-f3.component';

describe('HtdF3Component', () => {
  let component: HtdF3Component;
  let fixture: ComponentFixture<HtdF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF3Component]
    });
    fixture = TestBed.createComponent(HtdF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
