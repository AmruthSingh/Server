import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f14',
  templateUrl: './htd-f14.component.html',
  styleUrls: ['./htd-f14.component.css']
})
export class HtdF14Component {
  HTDf14: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf14 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.HTDf14.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      sNo: [''],
      date: [''],
      reqNo: [''],
      project: [''],
      direct: [''],
      offInCharge: [''],
      sign:[''],
      resultsNo: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.HTDf14.value;
    const HTDf14Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf14Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf14.value;
    const HTDf14Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf14Data);

    console.log(payload);
  }
}
