import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF14Component } from './htd-f14.component';

describe('HtdF14Component', () => {
  let component: HtdF14Component;
  let fixture: ComponentFixture<HtdF14Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF14Component]
    });
    fixture = TestBed.createComponent(HtdF14Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
