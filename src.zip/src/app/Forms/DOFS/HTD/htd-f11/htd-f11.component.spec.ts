import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF11Component } from './htd-f11.component';

describe('HtdF11Component', () => {
  let component: HtdF11Component;
  let fixture: ComponentFixture<HtdF11Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF11Component]
    });
    fixture = TestBed.createComponent(HtdF11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
