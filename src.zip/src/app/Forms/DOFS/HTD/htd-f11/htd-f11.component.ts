import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f11',
  templateUrl: './htd-f11.component.html',
  styleUrls: ['./htd-f11.component.css']
})
export class HtdF11Component {
  HTDf11: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf11 = this.formBuilder.group({
      calibration: ['', Validators.required],
      sensorId: [''],
      range: [''],
      calDate: [''],
      validUpTo: [''],
      calibratorDetails: [''],
      refStand:[''],
      serialNo:[''],
      validTill: [''],
      calibratedBy:[''],
      calInCharge:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf11.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      sourceReading: '',
      measuredOutput: '',
      error: '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.HTDf11.value;
    const HTDf11Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf11Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf11.value;
    const HTDf11Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf11Data);

    console.log(payload);
  }
}
