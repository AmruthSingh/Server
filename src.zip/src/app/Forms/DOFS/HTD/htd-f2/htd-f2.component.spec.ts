import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF2Component } from './htd-f2.component';

describe('HtdF2Component', () => {
  let component: HtdF2Component;
  let fixture: ComponentFixture<HtdF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF2Component]
    });
    fixture = TestBed.createComponent(HtdF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
