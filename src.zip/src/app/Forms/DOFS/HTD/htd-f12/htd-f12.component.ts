import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f12',
  templateUrl: './htd-f12.component.html',
  styleUrls: ['./htd-f12.component.css']
})
export class HtdF12Component {
  HTDf12: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf12 = this.formBuilder.group({
      certificateNo: ['', Validators.required],
      sensorId: [''],
      range: [''],
      date: [''],
      validUpTo: [''],
      calibratorDetails: [''],
      refStandard:[''],
      slNo:[''],
      validTill: [''],
      scaleFactor:[''],
      calibratedBy:[''],
      calInCharge:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf12.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      StandardHeat: '',
      unitTest: '',
      error: '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf12.value;
    const HTDf12Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf12Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf12.value;
    const HTDf12Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf12Data);

    console.log(payload);
  }
}
