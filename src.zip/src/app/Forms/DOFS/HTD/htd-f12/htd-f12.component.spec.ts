import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF12Component } from './htd-f12.component';

describe('HtdF12Component', () => {
  let component: HtdF12Component;
  let fixture: ComponentFixture<HtdF12Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF12Component]
    });
    fixture = TestBed.createComponent(HtdF12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
