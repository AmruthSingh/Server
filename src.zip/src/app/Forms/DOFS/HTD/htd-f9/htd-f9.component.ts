import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f9',
  templateUrl: './htd-f9.component.html',
  styleUrls: ['./htd-f9.component.css']
})
export class HtdF9Component {
  HTDf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf9 = this.formBuilder.group({
      no: ['', Validators.required],
      noDate: [''],
      proj: [''],
      dir: [''],
      reqDes: [''],
      userRepSign: [''],
      userRepName:[''],
      userRepDesign:[''],
      projDirSign: [''],
      projDirName:[''],
      projDirDesign:[''],
      remark:[''],
      logBookNo:[''],
      offInChargeDate:[''],
      approve:[''],
      dirSign:[''],
      assignDate:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf9.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      sNo: '',
      itemOfCalib: '',
      sensorDetail: '',
      operatingTemp: '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf9.value;
    const HTDf9Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf9.value;
    const HTDf9Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf9Data);

    console.log(payload);
  }
}
