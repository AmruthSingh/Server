import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF9Component } from './htd-f9.component';

describe('HtdF9Component', () => {
  let component: HtdF9Component;
  let fixture: ComponentFixture<HtdF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF9Component]
    });
    fixture = TestBed.createComponent(HtdF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
