import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF13Component } from './htd-f13.component';

describe('HtdF13Component', () => {
  let component: HtdF13Component;
  let fixture: ComponentFixture<HtdF13Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF13Component]
    });
    fixture = TestBed.createComponent(HtdF13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
