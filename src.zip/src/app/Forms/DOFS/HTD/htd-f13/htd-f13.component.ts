import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f13',
  templateUrl: './htd-f13.component.html',
  styleUrls: ['./htd-f13.component.css']
})
export class HtdF13Component {
  HTDf13: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf13 = this.formBuilder.group({
      no: ['', Validators.required],
      noDate: [''],
      proj: [''],
      dir: [''],
      article: [''],
      objectiveMeasur: [''],
      samplingFreq: [''],
      tempRange: [''],
      durationOfTest: [''],
      material: [''],
      emissivity: [''],
      date: [''],
      timeOfTest: [''],
      locationOfTest: [''],
      requirements: [''],
      userRepSign: [''],
      userRepName:[''],
      userRepDesign:[''],
      projDirSign: [''],
      projDirName:[''],
      projDirDesign:[''],
      remark:[''],
      logBookNo:[''],
      offInChargeDate:[''],
      approve:[''],
      dirSign:[''],
      assignDate:[''],
    });
  }

  SaveToDraft() {
    const formData = this.HTDf13.value;
    const HTDf13Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf13Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf13.value;
    const HTDf13Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf13Data);

    console.log(payload);
  }
}
