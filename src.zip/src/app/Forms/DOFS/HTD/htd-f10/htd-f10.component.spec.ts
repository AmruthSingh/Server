import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF10Component } from './htd-f10.component';

describe('HtdF10Component', () => {
  let component: HtdF10Component;
  let fixture: ComponentFixture<HtdF10Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF10Component]
    });
    fixture = TestBed.createComponent(HtdF10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
