import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f10',
  templateUrl: './htd-f10.component.html',
  styleUrls: ['./htd-f10.component.css']
})
export class HtdF10Component {
  HTDf10: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf10 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf10.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      userReqNo: [''],
      date: [''],
      project: [''],
      offInCharge: [''],
      sign:[''],
      typeOfCalib: [''],
      repNo: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf10.value;
    const HTDf10Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf10Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf10.value;
    const HTDf10Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf10Data);

    console.log(payload);
  }
}
