import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF7Component } from './htd-f7.component';

describe('HtdF7Component', () => {
  let component: HtdF7Component;
  let fixture: ComponentFixture<HtdF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF7Component]
    });
    fixture = TestBed.createComponent(HtdF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
