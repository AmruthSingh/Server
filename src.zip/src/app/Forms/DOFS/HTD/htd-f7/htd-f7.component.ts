import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f7',
  templateUrl: './htd-f7.component.html',
  styleUrls: ['./htd-f7.component.css']
})
export class HtdF7Component {
  HTDf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf7 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.HTDf7.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      userReqNo: [''],
      date: [''],
      project: [''],
      equipment: [''],
      offInCharge: [''],
      sign:[''],
      repNo: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.HTDf7.value;
    const HTDf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf7.value;
    const HTDf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf7Data);

    console.log(payload);
  }
}
