import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF1Component } from './htd-f1.component';

describe('HtdF1Component', () => {
  let component: HtdF1Component;
  let fixture: ComponentFixture<HtdF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF1Component]
    });
    fixture = TestBed.createComponent(HtdF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
