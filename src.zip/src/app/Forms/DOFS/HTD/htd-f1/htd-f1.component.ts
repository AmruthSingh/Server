import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-htd-f1',
  templateUrl: './htd-f1.component.html',
  styleUrls: ['./htd-f1.component.css'],
})
export class HtdF1Component {
  HTDf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.HTDf1 = this.formBuilder.group({
      no: ['', Validators.required],
      date: [''],
      proj: [''],
      direct: [''],
      reqDes: [''],
      geomentry: [''],
      dependantTem: [''],
      noReason: [''],
      conditionsOpe: [''],
      digitalForm: [''],
      systemDetails: [''],
      heatFlux: [''],
      flowData: [''],
      anyOther: [''],
      userRepSign: [''],
      userRepName:[''],
      userRepDesign:[''],
      projDirSign: [''],
      projDirName:[''],
      projDirDesign:[''],
      jobControlNo:[''],
      inputRec:[''],
      pdc:[''],
      dateSystem:[''],
      activityPlan:[''],
      approve:[''],
      dirSign:[''],
      workAssigned:[''],
      assignDate:[''],
    });
  }

  SaveToDraft() {
    const formData = this.HTDf1.value;
    const HTDf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(HTDf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.HTDf1.value;
    const HTDf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(HTDf1Data);

    console.log(payload);
  }
}
