import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtdF8Component } from './htd-f8.component';

describe('HtdF8Component', () => {
  let component: HtdF8Component;
  let fixture: ComponentFixture<HtdF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HtdF8Component]
    });
    fixture = TestBed.createComponent(HtdF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
