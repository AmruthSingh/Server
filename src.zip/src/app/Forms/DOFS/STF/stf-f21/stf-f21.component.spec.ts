import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF21Component } from './stf-f21.component';

describe('StfF21Component', () => {
  let component: StfF21Component;
  let fixture: ComponentFixture<StfF21Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF21Component]
    });
    fixture = TestBed.createComponent(StfF21Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
