import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f21',
  templateUrl: './stf-f21.component.html',
  styleUrls: ['./stf-f21.component.css'],
})
export class StfF21Component {
  STFf21: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf21 = this.formBuilder.group({
      no: [''],
      temparature: [''],
      date: [''],
      humidity: [''],
      type: [''],
      mode: [''],
      make: [''],
      lotNo: [''],
      dateOfCalibration: [''],
      workCenter: [''],
      sensitivity: [''],
      decision: [''],
      calibDue: [''],
      standardUsed: [''],
      nomenclature: [''],
      maKE: [''],
      modelNo: [''],
      uncertainity: [''],
      calibValid: [''],
      calibCert: [''],
      calibBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf21.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      beam: [''],
      readingOne: [''],
      readingTwo: [''],
      readingThree: [''],
      average: [''],
      theoreticalStrain: [''],
      error: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf21.value;
    const STFf21Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf21Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf21.value;
    const STFf21Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf21Data);

    console.log(payload);
  }
}
