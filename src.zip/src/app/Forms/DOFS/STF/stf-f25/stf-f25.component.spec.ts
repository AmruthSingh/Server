import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF25Component } from './stf-f25.component';

describe('StfF25Component', () => {
  let component: StfF25Component;
  let fixture: ComponentFixture<StfF25Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF25Component]
    });
    fixture = TestBed.createComponent(StfF25Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
