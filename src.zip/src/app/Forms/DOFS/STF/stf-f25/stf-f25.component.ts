import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f25',
  templateUrl: './stf-f25.component.html',
  styleUrls: ['./stf-f25.component.css']
})
export class StfF25Component {
  STFf25: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf25= this.formBuilder.group({
      calibOn:[''],
     nextCalibDue:[''],
     certiNo:[''],
     makeNo:[''],
     ModelNo:[''],
     slNo:[''],
     chNo1:[''],
     measuredVolt1:[''],
     pError1:[''],
     measuredFreq1:[''],
     percentError1:[''],
     chNo2:[''],
     measuredVolt2:[''],
     pError2:[''],
     measuredFreq2:[''],
     percentError2:[''],
     chNo3:[''],
     measuredVolt3:[''],
     pError3:[''],
     measuredFreq3:[''],
     percentError3:[''],
     chNo4:[''],
     measuredVolt4:[''],
     pError4:[''],
     measuredFreq4:[''],
     percentError4:[''],
     chNo5:[''],
     measuredVolt5:[''],
     pError5:[''],
     measuredFreq5:[''],
     percentError5:[''],
     fitForUse:[''],
     remarks:[''],
     nomenOfInst:[''],
     make:[''],
     modelNo:[''],
     uncertainty:[''],
     cailbValidity:[''],
     calibCertiNo:[''],
     testEngg:[''],
     headSTF:[''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf25.value;
    const STFf25Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf25Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf25.value;
    const STFf25Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf25Data);

    console.log(payload);
  }
}
