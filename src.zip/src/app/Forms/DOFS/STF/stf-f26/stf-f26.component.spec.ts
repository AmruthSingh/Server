import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF26Component } from './stf-f26.component';

describe('StfF26Component', () => {
  let component: StfF26Component;
  let fixture: ComponentFixture<StfF26Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF26Component]
    });
    fixture = TestBed.createComponent(StfF26Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
