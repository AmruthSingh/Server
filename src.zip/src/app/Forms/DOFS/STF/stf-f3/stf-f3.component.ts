import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f3',
  templateUrl: './stf-f3.component.html',
  styleUrls: ['./stf-f3.component.css']
})
export class StfF3Component {
  STFf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf3 = this.formBuilder.group({
      reportNo: [''],
      dateOfTextCon: [''],
      dateOfReportIssue: [''],
      noOfPages: [''],
      titleOfTest: [''],
      stf: [''],
      headStf: [''],
      technologyDirec: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf3.value;
    const STFf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf3.value;
    const STFf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf3Data);

    console.log(payload);
  }
}
