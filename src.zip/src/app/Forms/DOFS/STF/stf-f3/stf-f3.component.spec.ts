import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF3Component } from './stf-f3.component';

describe('StfF3Component', () => {
  let component: StfF3Component;
  let fixture: ComponentFixture<StfF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF3Component]
    });
    fixture = TestBed.createComponent(StfF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
