import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f16',
  templateUrl: './stf-f16.component.html',
  styleUrls: ['./stf-f16.component.css']
})
export class StfF16Component {
  STFf16: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf16 = this.formBuilder.group({
      name: [''],
      project: [''],
      ensureTest: [''],
      remarksEnsure: [''],
      tarb: [''],
      rrigs: [''],
      torque: [''],
      remarkTorque: [''],
      forces: [''],
      remarkForces: [''],
      safeGround: [''],
      remarkSafeGround: [''],
      mech: [''],
      remarkMech: [''],
      inst: [''],
      remarkInst: [''],
      bond: [''],
      remarkBond: [''],
      model: [''],
      remarkModel: [''],
      range: [''],
      remarkRange: [''],
      panel: [''],
      remarkPanel: [''],
      bare: [''],
      remarkBare: [''],
      shaker: [''],
      remarkShaker: [''],
      level: [''],
      remarkLevel: [''],
      testPlan:[''],
      remarkTestPlan: [''],
      setupName: [''],
      sensorBondingName: [''],
      dataAcquisitionName: [''],
      setupDate: [''],
      sensorBondingDate: [''],
      dataAcquisitionDate: [''],
      inchargeSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf16.value;
    const STFf16Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf16Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf16.value;
    const STFf16Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf16Data);

    console.log(payload);
  }
}
