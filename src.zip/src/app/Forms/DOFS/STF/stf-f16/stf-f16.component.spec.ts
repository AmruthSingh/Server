import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF16Component } from './stf-f16.component';

describe('StfF16Component', () => {
  let component: StfF16Component;
  let fixture: ComponentFixture<StfF16Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF16Component]
    });
    fixture = TestBed.createComponent(StfF16Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
