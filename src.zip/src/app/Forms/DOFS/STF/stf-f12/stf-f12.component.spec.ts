import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF12Component } from './stf-f12.component';

describe('StfF12Component', () => {
  let component: StfF12Component;
  let fixture: ComponentFixture<StfF12Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF12Component]
    });
    fixture = TestBed.createComponent(StfF12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
