import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF22Component } from './stf-f22.component';

describe('StfF22Component', () => {
  let component: StfF22Component;
  let fixture: ComponentFixture<StfF22Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF22Component]
    });
    fixture = TestBed.createComponent(StfF22Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
