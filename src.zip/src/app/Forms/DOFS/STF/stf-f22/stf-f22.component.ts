import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f22',
  templateUrl: './stf-f22.component.html',
  styleUrls: ['./stf-f22.component.css'],
})
export class StfF22Component {
  STFf22: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf22 = this.formBuilder.group({
      no: [''],
      temparature: [''],
      date: [''],
      humidity: [''],
      type: [''],
      mode: [''],
      make: [''],
      lotNo: [''],
      dateOfCalibration: [''],
      workCenter: [''],
      sensitivity: [''],
      decision: [''],
      calibDue: [''],
      standardUsed: [''],
      nomenclature: [''],
      eqUsed:[''],
      makeOne:[''],
      modelNo:[''],
      calibrationValidity:[''],
      certificateNo:[''],
      calibBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf22.get('rows') as FormArray;
  }
  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      inputPressure: [''],
      readingOne: [''],
      readingTwo: [''],
      readingThree: [''],
      average: [''],
      error: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf22.value;
    const STFf22Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf22Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf22.value;
    const STFf22Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf22Data);

    console.log(payload);
  }
}
