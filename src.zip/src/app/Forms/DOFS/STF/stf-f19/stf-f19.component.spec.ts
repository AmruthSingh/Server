import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF19Component } from './stf-f19.component';

describe('StfF19Component', () => {
  let component: StfF19Component;
  let fixture: ComponentFixture<StfF19Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF19Component]
    });
    fixture = TestBed.createComponent(StfF19Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
