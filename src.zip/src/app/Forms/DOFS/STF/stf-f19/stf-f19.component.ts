import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f19',
  templateUrl: './stf-f19.component.html',
  styleUrls: ['./stf-f19.component.css']
})
export class StfF19Component {
  STFf19: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf19 = this.formBuilder.group({
      no:[''],
      temparature:[''],
      date:[''],
      humidity:[''],
      ptNo:[''],
      range:[''],
      make:[''],
      workCenter:[''],
      dateOfCalibration:[''],
      standard:[''],
      sensitivity:[''],
      decision:[''],
      calibDue: [''],
      standardUsed: [''],
      nomenclature: [''],
      maKE: [''],
      modelNo: [''],
      uncertainity: [''],
      calibValid: [''],
      calibCert: [''],
      calibBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf19.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({

      slNo:[''],
      inputPressure:[''],
      readingOne:[''],
      readingTwo:[''],
      readingThree:[''],
      average:[''],
      error:[''],

    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.STFf19.value;
    const STFf19Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf19Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf19.value;
    const STFf19Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf19Data);

    console.log(payload);
  }
}
