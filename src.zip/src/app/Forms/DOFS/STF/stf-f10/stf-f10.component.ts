import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f10',
  templateUrl: './stf-f10.component.html',
  styleUrls: ['./stf-f10.component.css'],
})
export class StfF10Component {
  STFf10: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf10 = this.formBuilder.group({
      testName: [''],
      project: [''],
      ensureTest: [''],
      remarksEnsureTest: [''],
      ensureImple: [''],
      remarksEnsureImple: [''],
      ensureTigh: [''],
      remarksEnsureTigh: [''],
      ensurePneu: [''],
      remarksEnsurePneu: [''],
      selection: [''],
      remarksSelection: [''],
      relief: [''],
      remarksRelief: [''],
      oil: [''],
      remarksOil: [''],
      hoses: [''],
      remarksHoses: [''],
      direction: [''],
      remarksDirection: [''],
      lvdt: [''],
      remarksLvdt: [''],
      sensors: [''],
      remarksSensors: [''],
      transducer: [''],
      remarksTransducer: [''],
      connection: [''],
      remarksConnection: [''],
      devoid: [''],
      remarksDevoid: [''],
      leak: [''],
      remarksLeak: [''],
      pressurisartion: [''],
      remarksPressurisartion: [''],
      bondingName:[''],
      dataAcqName:[''],
      instrSetupName: [''],
      bondingDate: [''],
      dataAcqDate: [''],
      instrSetupDate:[''],
      otherPoints:[''],
      testInCharge:[''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf10.value;
    const STFf10Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf10Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf10.value;
    const STFf10Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf10Data);

    console.log(payload);
  }
}
