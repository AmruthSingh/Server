import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF10Component } from './stf-f10.component';

describe('StfF10Component', () => {
  let component: StfF10Component;
  let fixture: ComponentFixture<StfF10Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF10Component]
    });
    fixture = TestBed.createComponent(StfF10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
