import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f17',
  templateUrl: './stf-f17.component.html',
  styleUrls: ['./stf-f17.component.css']
})
export class StfF17Component {
  STFf17: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf17 = this.formBuilder.group({
      name: [''],
      project: [''],
      ensureTest: [''],
      remarksEnsure: [''],
      tarb: [''],
      rrigs: [''],
      safeGround: [''],
      remarkSafeGround: [''],
      nominal: [''],
      remarkNominal: [''],
      inst: [''],
      remarkInst: [''],
      bond: [''],
      remarkBond: [''],
      signal: [''],
      remarkSignal: [''],
      direction: [''],
      remarkDirection: [''],
      mapping: [''],
      remarkMapping: [''],
      level: [''],
      remarkLevel: [''],
      actual: [''],
      remarkActual: [''],
      data: [''],
      remarkData: [''],
      testPlan:[''],
      remarkTestPlan: [''],
      setupName: [''],
      sensorBondingName: [''],
      dataAcquisitionName: [''],
      setupDate: [''],
      sensorBondingDate: [''],
      dataAcquisitionDate: [''],
      inchargeSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf17.value;
    const STFf17Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf17Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf17.value;
    const STFf17Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf17Data);

    console.log(payload);
  }
}
