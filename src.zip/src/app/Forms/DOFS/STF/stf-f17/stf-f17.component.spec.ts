import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF17Component } from './stf-f17.component';

describe('StfF17Component', () => {
  let component: StfF17Component;
  let fixture: ComponentFixture<StfF17Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF17Component]
    });
    fixture = TestBed.createComponent(StfF17Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
