import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF14Component } from './stf-f14.component';

describe('StfF14Component', () => {
  let component: StfF14Component;
  let fixture: ComponentFixture<StfF14Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF14Component]
    });
    fixture = TestBed.createComponent(StfF14Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
