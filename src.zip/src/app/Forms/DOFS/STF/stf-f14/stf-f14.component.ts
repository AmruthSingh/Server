import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f14',
  templateUrl: './stf-f14.component.html',
  styleUrls: ['./stf-f14.component.css'],
})
export class StfF14Component {
  STFf14: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf14 = this.formBuilder.group({
      projName: [''],
      workCenter:[''],
      docNo: [''],
      date: [''],
      drawing:[''],
      readiness: [''],
      pdcTest: [''],
      criteriaTest:[''],
      name: [''],
      sign: [''],
      contact: [''],
      mobile: [''],
      feasibility: [''],
      readinessTestpf: [''],
      availability: [''],
      reqTest:[''],
      responsibility: [''],
      mutagreedPdc: [''],
      proc: [''],
      offcIncharge: [''],
      accept:[''],
      headSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf14.value;
    const STFf14Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf14Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf14.value;
    const STFf14Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf14Data);

    console.log(payload);
  }
}
