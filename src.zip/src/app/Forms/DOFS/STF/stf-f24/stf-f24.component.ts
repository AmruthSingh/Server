import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f24',
  templateUrl: './stf-f24.component.html',
  styleUrls: ['./stf-f24.component.css'],
})
export class StfF24Component {
  STFf24: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf24 = this.formBuilder.group({
      calibOn: [''],
      nextCalibDue: [''],
      certiNo: [''],
      modelNo: [''],
      slNo: [''],
      unitOfMeasurement: [''],
      stdIpVolt: [''],
      opVolt: [''],
      allAcc: [''],
      obtAcc: [''],
      fitForUse: [''],
      nomenOfInst: [''],
      make: [''],
      modelSlNo: [''],
      uncertainity: [''],
      calibValidity: [''],
      calibCertiNo: [''],
      testEngg: [''],
      headSTF: [''],
      maxError: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf24.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      chNo: [''],
      inputVolt: [''],
      outputVolt: [''],
      pError: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf24.value;
    const STFf24Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf24Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf24.value;
    const STFf24Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf24Data);

    console.log(payload);
  }
}
