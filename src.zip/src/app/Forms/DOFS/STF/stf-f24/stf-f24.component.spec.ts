import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF24Component } from './stf-f24.component';

describe('StfF24Component', () => {
  let component: StfF24Component;
  let fixture: ComponentFixture<StfF24Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF24Component]
    });
    fixture = TestBed.createComponent(StfF24Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
