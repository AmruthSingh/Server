import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f8',
  templateUrl: './stf-f8.component.html',
  styleUrls: ['./stf-f8.component.css']
})
export class StfF8Component {
  STFf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf8 = this.formBuilder.group({
      projName: [''],
      workCenter: [''],
      docNo: [''],
      date: [''],
      drawing: [''],
      cad: [''],
      readinesss: [''],
      pdcTest: [''],
      pdcTestDate: [''],
      pdcTestExpected: [''],
      criteriaTest: [''],
      name: [''],
      sign: [''],
      contact: [''],
      mobile: [''],
      feasibility: [''],
      readiness: [''],
      availability: [''],
      reqTest: [''],
      responsibility: [''],
      pdc: [''],
      for: [''],
      offcIncharge: [''],
      accept: [''],
      notAccept: [''],
      headSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf8.value;
    const STFf8Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf8Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf8.value;
    const STFf8Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf8Data);

    console.log(payload);
  }
}
