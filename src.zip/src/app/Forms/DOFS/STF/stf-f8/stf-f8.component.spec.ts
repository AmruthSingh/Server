import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF8Component } from './stf-f8.component';

describe('StfF8Component', () => {
  let component: StfF8Component;
  let fixture: ComponentFixture<StfF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF8Component]
    });
    fixture = TestBed.createComponent(StfF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
