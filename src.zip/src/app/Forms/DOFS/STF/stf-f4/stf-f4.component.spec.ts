import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF4Component } from './stf-f4.component';

describe('StfF4Component', () => {
  let component: StfF4Component;
  let fixture: ComponentFixture<StfF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF4Component]
    });
    fixture = TestBed.createComponent(StfF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
