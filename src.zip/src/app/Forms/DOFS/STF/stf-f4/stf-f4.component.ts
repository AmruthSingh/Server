import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f4',
  templateUrl: './stf-f4.component.html',
  styleUrls: ['./stf-f4.component.css']
})
export class StfF4Component {
  STFf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf4 = this.formBuilder.group({
      instrumentDescription: [''],
      modelType: [''],
      slNoModel: [''],
      Sensitivity: [''],
      lastDate: [''],
      air: [''],
      rangeReq: [''],
      traceability: [''],
      specReq: [''],
      dateSpecific: [''],
      sign: [''],
      nameSign: [''],
      divName: [''],
      direcLab: [''],
      manPower: [''],
      jobControlNo: [''],
      manOfOfficers: [''],
      staffNames: [''],
      slotCalib: [''],
      recomendedOr: [''],
      stfDiv: [''],
      dateCali: [''],
      receCondition: [''],
      result: [''],
      refNoCal: [''],
      dateOfNext:[''],
      calCerNo:[''],
      dateOf:[''],
      signInCharge:[''],
      calibCert:[''],
      signSensor:[''],
      nameSensor:[''],
      designationSensor:[''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf4.value;
    const STFf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf4.value;
    const STFf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf4Data);

    console.log(payload);
  }
}
