import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF23Component } from './stf-f23.component';

describe('StfF23Component', () => {
  let component: StfF23Component;
  let fixture: ComponentFixture<StfF23Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF23Component]
    });
    fixture = TestBed.createComponent(StfF23Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
