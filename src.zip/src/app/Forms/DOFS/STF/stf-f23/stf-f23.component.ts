import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f23',
  templateUrl: './stf-f23.component.html',
  styleUrls: ['./stf-f23.component.css'],
})
export class StfF23Component {
  STFf23: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf23 = this.formBuilder.group({
      no: [''],
      temparature: [''],
      date: [''],
      dueDate: [''],
      thermocoupleNo: [''],
      rangeOfCalibration: [''],
      type: [''],
      method: [''],
      make: [''],
      steps: [''],
      lotNo: [''],
      spoolId: [''],
      slNo: [''],
      referenceTemparature: [''],
      deviation: [''],
      accept: [''],
      reject: [''],
      standardUsed: [''],
      nomenclature: [''],
      makeOne: [''],
      modelNo: [''],
      calibrationValidity: [''],
      certificateNo : [''],
      calibratedBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.STFf23.get('rows') as FormArray;
  }
  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      referenceTemparature: [''],
      measuredTemparature : [''],
      deviation: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }
  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.STFf23.value;
    const STFf23Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf23Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf23.value;
    const STFf23Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf23Data);

    console.log(payload);
  }
}
