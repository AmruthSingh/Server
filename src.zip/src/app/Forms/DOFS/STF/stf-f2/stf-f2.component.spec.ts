import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF2Component } from './stf-f2.component';

describe('StfF2Component', () => {
  let component: StfF2Component;
  let fixture: ComponentFixture<StfF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF2Component]
    });
    fixture = TestBed.createComponent(StfF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
