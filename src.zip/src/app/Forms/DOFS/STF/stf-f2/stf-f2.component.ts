import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f2',
  templateUrl: './stf-f2.component.html',
  styleUrls: ['./stf-f2.component.css']
})
export class StfF2Component {
  STFf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf2 = this.formBuilder.group({
      controlNo: [''],
      project: [''],
      testCondOn: [''],
      typeOfTest: [''],
      testPlan: [''],
      testPlanDetails: [''],
      textArticalDes: [''],
      testId: [''],
      testSNo: [''],
      parameters: [''],
      observations: [''],
      signatureProject: [''],
      signatureDesigner: [''],
      signatureQaRep: [''],
      signatureTestTeam: [''],
      nameProRep: [''],
      nameDesigner: [''],
      nameQaRep: [''],
      nameTestTeam: [''],
      agencyRep: [''],
      agencyDesi: [''],
      agencyQaRep: [''],
      agencyTest: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf2.value;
    const STFf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf2.value;
    const STFf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf2Data);

    console.log(payload);
  }
}
