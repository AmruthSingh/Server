import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF13Component } from './stf-f13.component';

describe('StfF13Component', () => {
  let component: StfF13Component;
  let fixture: ComponentFixture<StfF13Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF13Component]
    });
    fixture = TestBed.createComponent(StfF13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
