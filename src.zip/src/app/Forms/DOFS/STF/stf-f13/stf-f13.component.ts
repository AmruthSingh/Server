import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f13',
  templateUrl: './stf-f13.component.html',
  styleUrls: ['./stf-f13.component.css']
})
export class StfF13Component {
  STFf13: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf13 = this.formBuilder.group({
      name: [''],
      project: [''],
      incharge: [''],
      ensureTest: [''],
      remarksEnsure: [''],
      tarb: [''],
      rrigs: [''],
      rigs: [''],
      remRigs: [''],
      power: [''],
      remarksPower: [''],
      all: [''],
      remarksAll: [''],
      selection: [''],
      remarksSelection: [''],
      sensors: [''],
      remarksSensors: [''],
      and: [''],
      remarksAnd: [''],
      prepare: [''],
      remarksPrepare: [''],
      channel: [''],
      remarksChannel: [''],
      by: [''],
      remarksBy: [''],
      low: [''],
      remarksLow: [''],
      that: [''],
      remarksThat: [''],
      plan: [''],
      remarksPlan: [''],
      setupName: [''],
      sensorBondingName: [''],
      testCoordinatorName: [''],
      testEquipmentName: [''],
      dataAcquisitionName: [''],
      setupDate: [''],
      sensorBondingDate: [''],
      testCoordinatorDate: [''],
      testEquipmentDate: [''],
      dataAcquisitionDate: [''],
      inchargeSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf13.value;
    const STFf13Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf13Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf13.value;
    const STFf13Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf13Data);

    console.log(payload);
  }
}
