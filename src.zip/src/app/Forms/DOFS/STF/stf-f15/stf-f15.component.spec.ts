import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF15Component } from './stf-f15.component';

describe('StfF15Component', () => {
  let component: StfF15Component;
  let fixture: ComponentFixture<StfF15Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF15Component]
    });
    fixture = TestBed.createComponent(StfF15Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
