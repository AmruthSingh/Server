import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f15',
  templateUrl: './stf-f15.component.html',
  styleUrls: ['./stf-f15.component.css']
})
export class StfF15Component {
  STFf15: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf15 = this.formBuilder.group({
      name: [''],
      project: [''],
      ensureTest: [''],
      remarksEnsure: [''],
      tarb: [''],
      rrigs: [''],
      safeGround: [''],
      remarkSafeGround: [''],
      noimal: [''],
      remarkNoimal: [''],
      mech: [''],
      remarkMech: [''],
      shaker: [''],
      remarkShaker: [''],
      inst: [''],
      remarkInst: [''],
      bond: [''],
      remarkBond: [''],
      model: [''],
      remarkModel: [''],
      mapping: [''],
      remarkMapping: [''],
      forces: [''],
      remarkForces: [''],
      test: [''],
      remarkTest: [''],
      conf: [''],
      remarkConf: [''],
      repeated: [''],
      remarkRepeated: [''],
      testPlan:[''],
      remarkTestPlan: [''],
      setupName: [''],
      sensorBondingName: [''],
      dataAcquisitionName: [''],
      setupDate: [''],
      sensorBondingDate: [''],
      dataAcquisitionDate: [''],
      inchargeSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf15.value;
    const STFf15Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf15Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf15.value;
    const STFf15Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf15Data);

    console.log(payload);
  }
}
