import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF27Component } from './stf-f27.component';

describe('StfF27Component', () => {
  let component: StfF27Component;
  let fixture: ComponentFixture<StfF27Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF27Component]
    });
    fixture = TestBed.createComponent(StfF27Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
