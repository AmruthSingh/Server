import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f27',
  templateUrl: './stf-f27.component.html',
  styleUrls: ['./stf-f27.component.css'],
})
export class StfF27Component {
  STFf27: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf27 = this.formBuilder.group({
      calibrated: [''],
      certificateNo: [''],
      nextcalibration: [''],
      modelNo: [''],
      method: [''],
      reference: [''],
      allowableError: [''],
      inputCharge: [''],
      obtainedSensitivity: [''],
      error: [''],
      fitForUse: [''],
      nomenclature: [''],
      make: [''],
      modelNos: [''],
      uncertainty: [''],
      calibrationValidity: [''],
      calibrationCertificateNo: [''],
      testEnginner: [''],
      head: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf27.value;
    const STFf27Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf27Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf27.value;
    const STFf27Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf27Data);

    console.log(payload);
  }
}
