import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF20Component } from './stf-f20.component';

describe('StfF20Component', () => {
  let component: StfF20Component;
  let fixture: ComponentFixture<StfF20Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF20Component]
    });
    fixture = TestBed.createComponent(StfF20Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
