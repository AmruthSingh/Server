import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f20',
  templateUrl: './stf-f20.component.html',
  styleUrls: ['./stf-f20.component.css'],
})
export class StfF20Component {
  STFf20: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf20 = this.formBuilder.group({
      num: [''],
      date: [''],
      lvdt: [''],
      range: [''],
      sNo: [''],
      mode: [''],
      make: [''],
      workCenter: [''],
      dateCalib: [''],
      standard: [''],
      sensitivity: [''],
      decision: [''],
      calibDue: [''],
      standardUsed: [''],
      nomenclature: [''],
      maKE: [''],
      modelNo: [''],
      uncertainity: [''],
      calibValid: [''],
      calibCert: [''],
      calibBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf20.get('rows') as FormArray;
  }
  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      masterloadIp: [''],
      inputPressure: [''],
      readingOne: [''],
      readingTwo: [''],
      readingThree: [''],
      average: [''],
      error: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf20.value;
    const STFf20Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf20Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf20.value;
    const STFf20Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf20Data);

    console.log(payload);
  }
}
