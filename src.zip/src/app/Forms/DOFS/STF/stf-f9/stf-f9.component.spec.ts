import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF9Component } from './stf-f9.component';

describe('StfF9Component', () => {
  let component: StfF9Component;
  let fixture: ComponentFixture<StfF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF9Component]
    });
    fixture = TestBed.createComponent(StfF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
