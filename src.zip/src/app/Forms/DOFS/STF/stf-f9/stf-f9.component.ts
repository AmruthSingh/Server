import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f9',
  templateUrl: './stf-f9.component.html',
  styleUrls: ['./stf-f9.component.css']
})
export class StfF9Component {
  STFf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf9= this.formBuilder.group({
      nameOfTest:[''],
      project:[''],
      ensureTest:[''],
      remarksEnsureTest:[''],
      ensureImple:[''],
      remarksEnsureImple:[''],
      ensureTigh :[''],
      remarksEnsureTigh:[''],
      selectionSuitable:[''],
      remarksSelectionrelief:[''],
      relief:[''],
      remarksRelief:[''],
      oil:[''],
      remarksOil:[''],
     hoses:[''],
      remarksHosesactuator :[''],
      actuator:[''],
      remarksActuator :[''],
      recording:[''],
      remarksRecording:[''],
      leak:[''],
      remarksLbeltseak:[''],
      belts:[''],
      remarksBelts :[''],
      all:[''],
      remarksAll :[''],
      strain:[''],
      remarksStrain:[''],
      cell:[''],
      remarksCell:[''],
     per:[''],
      remarksPer:[''],
      used:[''],
      remarksUsed:[''],
      remarksSensors:[''],
      sensors:[''],
      software:[''],
      remarksSoftware:[''],
      calcul:[''],
      remarksCalcul:[''],
      plane:[''],
      remarksPlane:[''],
     pack:[''],
      remarksPack:[''],
      given:[''],
      remarksGiven:[''],
      otherPoints:[''],
      bondingName:[''],
      dataAcqName:[''],
      instrSetupName:[''],
      bondingDate:[''],
      dataAcqDate:[''],
      instrSetupDate:[''],

    });
  }
  SaveToDraft() {
    const formData = this.STFf9.value;
    const STFf9Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf9.value;
    const STFf9Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf9Data);

    console.log(payload);
  }
}
