import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF28Component } from './stf-f28.component';

describe('StfF28Component', () => {
  let component: StfF28Component;
  let fixture: ComponentFixture<StfF28Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF28Component]
    });
    fixture = TestBed.createComponent(StfF28Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
