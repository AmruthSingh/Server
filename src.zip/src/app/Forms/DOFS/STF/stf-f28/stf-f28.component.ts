import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f28',
  templateUrl: './stf-f28.component.html',
  styleUrls: ['./stf-f28.component.css'],
})
export class StfF28Component {
  STFf28: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf28 = this.formBuilder.group({
      certificateNo: [''],
      calibOn: [''],
      calibDueOn: [''],
      accelerModel: [''],
      sNo: [''],
      standardNo: [''],
      methodOfCalib: [''],
      refSensitivity: [''],
      allowError: [''],
      gLevel: [''],
      freqRange: [''],
      obtSensitivity: [''],
      pError: [''],
      fitForUse: [''],
      nomenclature: [''],
      make: [''],
      modelNo: [''],
      uncertainity: [''],
      calibrationValidity: [''],
      calibrationCertificateNo: [''],
      testEngineer: [''],
      head: [''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf28.value;
    const STFf28Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf28Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf28.value;
    const STFf28Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf28Data);

    console.log(payload);
  }
}
