import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f1',
  templateUrl: './stf-f1.component.html',
  styleUrls: ['./stf-f1.component.css']
})
export class StfF1Component {
STFf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf1 = this.formBuilder.group({
      project: [''],
      projectDate: [''],
      direc: [''],
      div: [''],
      hangingOver: [''],
      hardwareDes: [''],
      typeOfPro: [''],
      centre: [''],
      testNo: [''],
      testNoDate: [''],
      waiver: [''],
      waiverDate: [''],
      tarb: [''],
      tarbAction: [''],
      agencyName: [''],
      agencyContact: [''],
      comName: [''],
      nameOfManu: [''],
      qtyTo: [''],
      qcCle: [''],
      id: [''],
      idSlNo: [''],
      strainNos: [''],
      pressureNos: [''],
      tempuratureNos: [''],
      displaNos: [''],
      forceNos:[''],
      acoEmi:[''],
      heatFlux:[''],
      acouSens:[''],
      acceleration:[''],
      signDeman:[''],
      signDesigner:[''],
      signProDire:[''],
      nameDeman:[''],
      nameDesigner:[''],
      nameProDire:[''],
      desigDeman:[''],
      desigDesigner:[''],
      desigProDire:[''],
      contactDeman:[''],
      contactDesigner:[''],
      contactProDire:[''],
      controlNo:[''],
      nameOfTeam:[''],
      noOfOffiNames:[''],
      probableTestingSlot:[''],
      recomendedOrNot:[''],
      approvNotApprov:[''],
      headStf:[''],
      techDireDofs:[''],
    });
  }
  SaveToDraft() {
    const formData = this.STFf1.value;
    const STFf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf1.value;
    const STFf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf1Data);

    console.log(payload);
  }
}
