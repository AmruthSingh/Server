import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF1Component } from './stf-f1.component';

describe('StfF1Component', () => {
  let component: StfF1Component;
  let fixture: ComponentFixture<StfF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF1Component]
    });
    fixture = TestBed.createComponent(StfF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
