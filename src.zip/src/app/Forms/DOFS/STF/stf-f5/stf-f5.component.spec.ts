import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF5Component } from './stf-f5.component';

describe('StfF5Component', () => {
  let component: StfF5Component;
  let fixture: ComponentFixture<StfF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF5Component]
    });
    fixture = TestBed.createComponent(StfF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
