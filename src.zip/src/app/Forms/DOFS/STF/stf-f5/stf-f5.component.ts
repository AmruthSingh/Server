import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f5',
  templateUrl: './stf-f5.component.html',
  styleUrls: ['./stf-f5.component.css']
})
export class StfF5Component {

  STFf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf5 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.STFf5.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    instrument:[''],
    idNo:[''],
    unitMeasurement:[''],
    range:[''],
    agency:[''],
    calibOn:[''],
    reacallOn:[''],
    dueOn:[''],
    status:[''],
    certNo:[''],
    update:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf5.value;
    const STFf5Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf5.value;
    const STFf5Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf5Data);

    console.log(payload);
  }
}
