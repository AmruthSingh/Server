import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF7Component } from './stf-f7.component';

describe('StfF7Component', () => {
  let component: StfF7Component;
  let fixture: ComponentFixture<StfF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF7Component]
    });
    fixture = TestBed.createComponent(StfF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
