import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f7',
  templateUrl: './stf-f7.component.html',
  styleUrls: ['./stf-f7.component.css']
})
export class StfF7Component {
  STFf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf7= this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()])
    });
  }
  get rows(): FormArray {
    return this.STFf7.get('rows') as FormArray;
  }
  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    instrument:[''],
    idNo:[''],
    refenSitivity:[''],
    agency:[''],
    frequency:[''],
    calibOn:[''],
    reacallDate:[''],
    dueOn:[''],
    status:[''],
    calibcertNo:[''],
    update:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf7.value;
    const STFf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf7.value;
    const STFf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf7Data);

    console.log(payload);
  }
}
