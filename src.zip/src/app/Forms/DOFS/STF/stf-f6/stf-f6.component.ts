import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f6',
  templateUrl: './stf-f6.component.html',
  styleUrls: ['./stf-f6.component.css']
})
export class StfF6Component  {
  STFf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf6 = this.formBuilder.group({
      year:['',Validators.required],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.STFf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
      idNo: '',
      instrumentSensor: '',
      frequency: '',
      jan: '',
      feb: '',
      mar:'',
      apr:'',
      may:'',
      jun:'',
      jul:'',
      aug:'',
      sep:'',
      oct:'',
      nov:'',
      dec:'',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf6.value;
    const STFf6Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf6.value;
    const STFf6Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf6Data);

    console.log(payload);
  }
}
