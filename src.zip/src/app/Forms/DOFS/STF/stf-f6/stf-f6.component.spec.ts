import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF6Component } from './stf-f6.component';

describe('StfF6Component', () => {
  let component: StfF6Component;
  let fixture: ComponentFixture<StfF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF6Component]
    });
    fixture = TestBed.createComponent(StfF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
