import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF11Component } from './stf-f11.component';

describe('StfF11Component', () => {
  let component: StfF11Component;
  let fixture: ComponentFixture<StfF11Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF11Component]
    });
    fixture = TestBed.createComponent(StfF11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
