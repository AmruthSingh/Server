import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stf-f11',
  templateUrl: './stf-f11.component.html',
  styleUrls: ['./stf-f11.component.css'],
})
export class StfF11Component {
  STFf11: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf11 = this.formBuilder.group({
      projName: [''],
      workCenter: [''],
      docNo: [''],
      designDocNo:[''],
      designDate:[''],
      date: [''],
      drawing: [''],
      cad: [''],
      readinesss: [''],
      pdcTest: [''],
      pdcTestDate: [''],
      pdcTestExpected: [''],
      criteriaTest: [''],
      name: [''],
      sign: [''],
      contact: [''],
      mobile: [''],
      feasibility: [''],
      readiness: [''],
      availability: [''],
      reqTest: [''],
      responsibility: [''],
      pdc: [''],
      for: [''],
      offcIncharge: [''],
      accept: [''],
      notAccept: [''],
      headSign: [''],

    });
  }
  SaveToDraft() {
    const formData = this.STFf11.value;
    const STFf11Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf11Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf11.value;
    const STFf11Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf11Data);

    console.log(payload);
  }
}
