import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StfF18Component } from './stf-f18.component';

describe('StfF18Component', () => {
  let component: StfF18Component;
  let fixture: ComponentFixture<StfF18Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StfF18Component]
    });
    fixture = TestBed.createComponent(StfF18Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
