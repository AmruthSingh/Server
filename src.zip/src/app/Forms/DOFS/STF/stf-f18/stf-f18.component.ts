import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-stf-f18',
  templateUrl: './stf-f18.component.html',
  styleUrls: ['./stf-f18.component.css'],
})
export class StfF18Component {
  STFf18: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.STFf18 = this.formBuilder.group({
      num: [''],
      date: [''],
      name: [''],
      range: [''],
      sNo: [''],
      mode: [''],
      make: [''],
      workCenter: [''],
      dateCalib: [''],
      standard: [''],
      sensitivity: [''],
      decision: [''],
      calibDue: [''],
      standardUsed: [''],
      nomenclature: [''],
      maKE: [''],
      modelNo: [''],
      uncertainity: [''],
      calibValid: [''],
      calibCert: [''],
      calibBy: [''],
      checkedBy: [''],
      approvedBy: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.STFf18.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      masterloadIp: [''],
      loadRead: [''],
      loadReader: [''],
      loadReading: [''],
      avg: [''],
      perror: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.STFf18.value;
    const STFf18Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(STFf18Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.STFf18.value;
    const STFf18Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(STFf18Data);

    console.log(payload);
  }
}
