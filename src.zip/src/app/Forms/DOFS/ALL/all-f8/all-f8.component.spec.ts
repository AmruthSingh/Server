import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllF8Component } from './all-f8.component';

describe('AllF8Component', () => {
  let component: AllF8Component;
  let fixture: ComponentFixture<AllF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllF8Component]
    });
    fixture = TestBed.createComponent(AllF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
