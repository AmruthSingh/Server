import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-all-f8',
  templateUrl: './all-f8.component.html',
  styleUrls: ['./all-f8.component.css']
})
export class AllF8Component {
  ALLf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.ALLf8 = this.formBuilder.group({
      year:['',Validators.required],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.ALLf8.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    process:[''],
    keyActivity:[''],
    potentialRisk:[''],
    rootCause:[''],
    existingControls:[''],
    likelihoodOccur:[''],
    psQuality:[''],
    delivSchedule:[''],
    porsQuality:[''],
    delivSch:[''],
    addSchedules:[''],
    actionPlanS:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.ALLf8.value;
    const ALLf8Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(ALLf8Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.ALLf8.value;
    const ALLf8Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(ALLf8Data);

    console.log(payload);
  }
}
