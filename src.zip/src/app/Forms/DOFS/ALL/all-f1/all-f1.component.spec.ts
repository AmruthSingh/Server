import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllF1Component } from './all-f1.component';

describe('AllF1Component', () => {
  let component: AllF1Component;
  let fixture: ComponentFixture<AllF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllF1Component]
    });
    fixture = TestBed.createComponent(AllF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
