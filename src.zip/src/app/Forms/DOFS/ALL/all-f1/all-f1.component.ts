import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-all-f1',
  templateUrl: './all-f1.component.html',
  styleUrls: ['./all-f1.component.css']
})
export class AllF1Component {
  ALLf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.ALLf1 = this.formBuilder.group({
      ion:['',Validators.required],
      recFrom:[''],
      recDate:[''],
     to:[''],
     newReq :[''],
     amendment:[''],
     change :[''],
     dateOfApproval :[''],
     ameChangeRef :[''],
     dateOfApp :[''],
     desOfChange:[''],
     signOfInitiator :[''],
     dateOfInitiator :[''],
     inputsProvided :[''],
     mutuallyAgreedPDC:[''],
     actualDateOfCompl:[''],
     reviewedBySystem :[''],
     sigOfsysManager :[''],
     date:[''],
     signOfHeadOfDivision:[''],
     approvalOfTechDirector:[''],
     sigOfTechnologyDirector :[''],
    rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.ALLf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    sNo: '',
    desOfInpProvided: '',
    softCopy : '',
    hardCopy : '',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.ALLf1.value;
    const ALLf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(ALLf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.ALLf1.value;
    const ALLf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(ALLf1Data);

    console.log(payload);
  }
}
