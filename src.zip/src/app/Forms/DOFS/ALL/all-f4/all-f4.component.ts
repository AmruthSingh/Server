import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-all-f4',
  templateUrl: './all-f4.component.html',
  styleUrls: ['./all-f4.component.css']
})
export class AllF4Component {
  ALLf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.ALLf4 = this.formBuilder.group({
      year:['',Validators.required],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.ALLf4.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    refNum:[''],
    titleOfSP:[''],
    reviewAndApprove:[''],
    equipment:[''],
    compOfPersonnel:[''],
    method:[''],
    procedures:[''],
    responsibiltiy:[''],
    docInf:[''],
    remark:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.ALLf4.value;
    const ALLf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(ALLf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.ALLf4.value;
    const ALLf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(ALLf4Data);

    console.log(payload);
  }
}
