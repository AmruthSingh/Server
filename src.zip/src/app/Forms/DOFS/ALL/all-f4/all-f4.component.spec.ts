import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllF4Component } from './all-f4.component';

describe('AllF4Component', () => {
  let component: AllF4Component;
  let fixture: ComponentFixture<AllF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllF4Component]
    });
    fixture = TestBed.createComponent(AllF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
