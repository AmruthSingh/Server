import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-all-f3',
  templateUrl: './all-f3.component.html',
  styleUrls: ['./all-f3.component.css'],
})
export class AllF3Component {
  ALLf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.ALLf3 = this.formBuilder.group({
      project: [''],
      directorate: [''],
      division: [''],
      workCenter: [''],
      applProcess: [''],
      typeOfCalib: [''],
      typeOfMain: [''],
      workorderRef: [''],
      workOrder: [''],
      dateIni: [''],
      dateInit: [''],
      descworkTask: [''],
      descrpworkTAsk: [''],
      instrumenuNo: [''],
      instrumentNum: [''],
      validMastEqu:[''],
      itemCalib: [''],
      reasonBreakdown: [''],
      dateCalib: [''],
      dateMaintenanace: [''],
      duedateCalib: [''],
      duedateMaintenance: [''],
      reacallDate: [''],
      recallDAte: [''],
      calibByagencyOfcalib:[''],
      calibByagencyOfMain:[''],
      nameOfAgencyOfCalib: [''],
      nameOfAgencyOfMain: [''],
      certCalib: [''],
      reportNo: [''],
      updateInDnet:[''],
      Equipment:[''],
      reasonRej: [''],
      calibLabelUpdate:[''],
      mainLabelUpdate:[''],
      dateHod: [''],
      signHod: [''],
      dateHOD: [''],
      signHOD: [''],
      dateTd: [''],
      signTd: [''],
      dateTecdir: [''],
      signTecdir: [''],
    });
  }
  SaveToDraft() {
    const formData = this.ALLf3.value;
    const ALLf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(ALLf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.ALLf3.value;
    const ALLf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(ALLf3Data);

    console.log(payload);
  }
}
