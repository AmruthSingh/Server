import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllF3Component } from './all-f3.component';

describe('AllF3Component', () => {
  let component: AllF3Component;
  let fixture: ComponentFixture<AllF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllF3Component]
    });
    fixture = TestBed.createComponent(AllF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
