import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllF2Component } from './all-f2.component';

describe('AllF2Component', () => {
  let component: AllF2Component;
  let fixture: ComponentFixture<AllF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AllF2Component]
    });
    fixture = TestBed.createComponent(AllF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
