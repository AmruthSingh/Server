import { Component } from '@angular/core';
import { FormGroup , FormBuilder , Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-all-f2',
  templateUrl: './all-f2.component.html',
  styleUrls: ['./all-f2.component.css']
})
export class AllF2Component {
  ALLf2:FormGroup;
  constructor(private formBuilder:FormBuilder,private http:HttpClient){
    this.ALLf2=this.formBuilder.group({
      project:[''],
      directorate:[''],
      division:[''],
      workCenter:[''],
      applProcess:[''],
      workRef:[''],
      refNumber:[''],
      baseLine:[''],
      newReq:[''],
      change:[''],
      amendment:[''],
      baseLineConf:[''],
      newRefConf:[''],
      changeConf:[''],
      amendmentConf:[''],
      dateIni:[''],
      dateInit:[''],
      dateBoard:[''],
      changeLogreg:[''],
      chairmanWaiver:[''],
      chairmanSec:[''],
      descNonconf:[''],
      configList:[''],
      refNum:[''],
      referenceNum:[''],
      refWb:[''],
      configMangAudits:[''],
      effCorrective:[''],
      effImplementation:[''],
      closurePort:[''],
      closPort:[''],
      dateHod:[''],
      signHod:[''],
      dateHOD:[''],
      signHOD:[''],
      dateTd:[''],
      signTd:[''],
      dateTecdir:[''],
      signTecdir:[''],

    });
  }
  SaveToDraft() {
    const formData = this.ALLf2.value;
    const ALLf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(ALLf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.ALLf2.value;
    const ALLf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(ALLf2Data);

    console.log(payload);
  }
}
