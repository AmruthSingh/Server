import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl,} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doad-f1',
  templateUrl: './doad-f1.component.html',
  styleUrls: ['./doad-f1.component.css']
})
export class DoadF1Component {
  DOADf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOADf1 = this.formBuilder.group({
      project: ['', Validators.required],
      period: ['', Validators.required],
      sysMgr: [''],
      divHead: [''],
      techDir: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.DOADf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: '',
      activity: '',
      resp: '',
      pdc: '',
      ipInfo: '',
      from: '',
      output:'',
      begnquarter:'',
      endquarter:'',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft(){
    const formData = this.DOADf1.value;
    const DOADf1Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOADf1Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.DOADf1.value;
    const DOADf1Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOADf1Data);
    console.log(payload);
  }
}
