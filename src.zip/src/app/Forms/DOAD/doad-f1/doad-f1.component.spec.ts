import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoadF1Component } from './doad-f1.component';

describe('DoadF1Component', () => {
  let component: DoadF1Component;
  let fixture: ComponentFixture<DoadF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoadF1Component]
    });
    fixture = TestBed.createComponent(DoadF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
