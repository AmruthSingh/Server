import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doad-f2',
  templateUrl: './doad-f2.component.html',
  styleUrls: ['./doad-f2.component.css'],
})
export class DoadF2Component {
  DOADf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOADf2 = this.formBuilder.group({
      documentNo: [''],
      copyNo: [''],
      noOfPages: [''],
      title: [''],
      preparedBy: [''],
      reviewedBy: [''],
      approvedBy: [''],
      authorisedBy: [''],
      date: [''],
    });
  }
  SaveToDraft(){
    const formData = this.DOADf2.value;
    const DOADf2Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOADf2Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.DOADf2.value;
    const DOADf2Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOADf2Data);
    console.log(payload);
  }
}
