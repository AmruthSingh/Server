import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoadF2Component } from './doad-f2.component';

describe('DoadF2Component', () => {
  let component: DoadF2Component;
  let fixture: ComponentFixture<DoadF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoadF2Component]
    });
    fixture = TestBed.createComponent(DoadF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
