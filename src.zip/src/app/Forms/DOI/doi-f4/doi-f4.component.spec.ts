import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF4Component } from './doi-f4.component';

describe('DoiF4Component', () => {
  let component: DoiF4Component;
  let fixture: ComponentFixture<DoiF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF4Component]
    });
    fixture = TestBed.createComponent(DoiF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
