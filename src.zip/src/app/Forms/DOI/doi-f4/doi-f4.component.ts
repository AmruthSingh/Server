import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f4',
  templateUrl: './doi-f4.component.html',
  styleUrls: ['./doi-f4.component.css']
})
export class DoiF4Component {
  DOIf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf4 = this.formBuilder.group({
      mPlanNo: [''],
      reqSlNo: [''],
      reqDate: [''],
      project: [''],
      testBed: [''],
      testName: [''],
      proposedTestDate: [''],
      testCondition: [''],
      noOfDasUsed: [''],
      requirement: [''],
      provided: [''],
      dasiCH: [''],
      dasiSR: [''],
      dasiiCH: [''],
      dasiiSR: [''],
      dasiiiCH: [''],
      dasiiiSR: [''],



    });
  }
  SaveToDraft() {
    const formData = this.DOIf4.value;
    const DOIf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf4.value;
    const DOIf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf4Data);

    console.log(payload);
  }
}
