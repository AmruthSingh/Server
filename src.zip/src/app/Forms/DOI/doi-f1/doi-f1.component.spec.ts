import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF1Component } from './doi-f1.component';

describe('DoiF1Component', () => {
  let component: DoiF1Component;
  let fixture: ComponentFixture<DoiF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF1Component]
    });
    fixture = TestBed.createComponent(DoiF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
