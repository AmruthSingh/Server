import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f1',
  templateUrl: './doi-f1.component.html',
  styleUrls: ['./doi-f1.component.css']
})
export class DoiF1Component {
  DOIf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf1 = this.formBuilder.group({
      slNo: [''],
      typeOfStd: [''],
      typeOfEqu: [''],
      location: [''],
      identificationNo: [''],
      serialNo: [""],
      model: [''],
      range: [''],
      accuracy: [''],
      calibration: [''],
      verificationMethod: [''],
      calibAgency: [''],
      freqCalib: [''],
      dateOfCalib: [''],
      dueDateOfCalib: [''],
      acceptanceCriteria: [''],
      recallDate: [''],
      calCftNo: [''],
      calibStatus: [''],
      date: [''],
      signOfIncharge: [''],
      signOfTechDir: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DOIf1.value;
    const DOIf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf1.value;
    const DOIf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf1Data);

    console.log(payload);
  }
}
