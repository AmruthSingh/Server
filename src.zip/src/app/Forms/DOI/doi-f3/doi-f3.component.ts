import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f3',
  templateUrl: './doi-f3.component.html',
  styleUrls: ['./doi-f3.component.css']
})
export class DoiF3Component {
  DOIf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf3 = this.formBuilder.group({
      slNo: [''],
      reqNo: [''],
      reqDate: [''],
      project: [''],
      testName: [''],
      testNo: [''],
      testDate: [''],
      testBedName: [''],
      motorName: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DOIf3.value;
    const DOIf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf3.value;
    const DOIf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf3Data);

    console.log(payload);
  }
}
