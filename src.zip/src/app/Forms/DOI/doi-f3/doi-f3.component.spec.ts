import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF3Component } from './doi-f3.component';

describe('DoiF3Component', () => {
  let component: DoiF3Component;
  let fixture: ComponentFixture<DoiF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF3Component]
    });
    fixture = TestBed.createComponent(DoiF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
