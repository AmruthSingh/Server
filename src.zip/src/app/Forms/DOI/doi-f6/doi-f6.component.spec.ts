import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF6Component } from './doi-f6.component';

describe('DoiF6Component', () => {
  let component: DoiF6Component;
  let fixture: ComponentFixture<DoiF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF6Component]
    });
    fixture = TestBed.createComponent(DoiF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
