import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f6',
  templateUrl: './doi-f6.component.html',
  styleUrls: ['./doi-f6.component.css']
})
export class DoiF6Component {
  DOIf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf6 = this.formBuilder.group({
      testBed:[''],
      slNo:[''],
      reqNo:[''],
      date:[''],
      testNo:[''],
      testDate:[''],
      signature:[''],
      name:[''],
      signOfTeamLeader:[''],
      signOfTechDir:[''],


    });
  }
  SaveToDraft() {
    const formData = this.DOIf6.value;
    const DOIf6Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf6.value;
    const DOIf6Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf6Data);

    console.log(payload);
  }
}
