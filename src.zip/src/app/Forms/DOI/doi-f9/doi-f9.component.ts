import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f9',
  templateUrl: './doi-f9.component.html',
  styleUrls: ['./doi-f9.component.css']
})
export class DoiF9Component {
  DOIf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf9 = this.formBuilder.group({
      project:[''],
      year:[''],
      duration:[''],
      date:[''],
      dataRadio:[''],
      timeRadio:[''],
      plotsRadio:[''],
      digitalRadio:[''],
      analysisRadio:[''],
      softCopyRadio:[''],
      comments:[''],
      signature:[''],
      name:[''],
      designation:[''],
      division:[''],
      phNo:[''],
      doiRepSign:[''],
      doiRepName:[''],
    });
  }
  SaveToDraft() {
    const formData = this.DOIf9.value;
    const DOIf9Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf9.value;
    const DOIf9Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf9Data);

    console.log(payload);
  }
}
