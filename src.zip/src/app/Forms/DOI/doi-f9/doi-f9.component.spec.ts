import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF9Component } from './doi-f9.component';

describe('DoiF9Component', () => {
  let component: DoiF9Component;
  let fixture: ComponentFixture<DoiF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF9Component]
    });
    fixture = TestBed.createComponent(DoiF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
