import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF7Component } from './doi-f7.component';

describe('DoiF7Component', () => {
  let component: DoiF7Component;
  let fixture: ComponentFixture<DoiF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF7Component]
    });
    fixture = TestBed.createComponent(DoiF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
