import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f7',
  templateUrl: './doi-f7.component.html',
  styleUrls: ['./doi-f7.component.css']
})
export class DoiF7Component {
  DOIf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf7 = this.formBuilder.group({
      projectName:[''],
      trialName:[''],
      date:[''],
      PIS1:[''],
      rPIS1:[''],
      PIS2:[''],
      rPIS2:[''],
      PIS3:[''],
      rPIS3:[''],
      PIS4:[''],
      rPIS4:[''],
      PCS1:[''],
      rPCS1:[''],
      PCS2:[''],
      rPCS2:[''],
      PCS3:[''],
      rPCS3:[''],
      PCS4:[''],
      rPCS4:[''],
      PCS5:[''],
      rPCS5:[''],
      PDAS1:[''],
      rPDAS1:[''],
      PDAS2:[''],
      rPDAS2:[''],
      PDAS3:[''],
      rPDAS3:[''],
      PDAS4:[''],
      rPDAS4:[''],
      PDAS5:[''],
      rPDAS5:[''],
      PDAS6:[''],
      rPDAS6:[''],
      PDAS7:[''],
      rPDAS7:[''],
      PDAS8:[''],
      rPDAS8:[''],
      PVS1:[''],
      rPVS1:[''],
      PVS2:[''],
      rPVS2:[''],
      PVS3:[''],
      rPVS3:[''],
      PVS4:[''],
      rPVS4:[''],
      PVS5:[''],
      rPVS5:[''],
      PVS6:[''],
      rPVS6:[''],
      PVS7:[''],
      rPVS7:[''],
      PVS8:[''],
      rPVS8:[''],
      PVS9:[''],
      rPVS9:[''],
      PVS10:[''],
      rPVS10:[''],
      PVS11:[''],
      rPVS11:[''],
      PVS12:[''],
      rPVS12:[''],
      PVS13:[''],
      rPVS13:[''],
      PVS14:[''],
      rPVS14:[''],
      PVS15:[''],
      rPVS15:[''],
      PVS16:[''],
      rPVS16:[''],

    });
  }
  SaveToDraft() {
    const formData = this.DOIf7.value;
    const DOIf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf7.value;
    const DOIf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf7Data);

    console.log(payload);
  }
}
