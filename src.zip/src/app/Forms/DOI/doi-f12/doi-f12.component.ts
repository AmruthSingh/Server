import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f12',
  templateUrl: './doi-f12.component.html',
  styleUrls: ['./doi-f12.component.css']
})
export class DoiF12Component {
  DOIf12: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf12 = this.formBuilder.group({
      requisitionno: [''],
      date: [''],
      project: [''],
      nomenclature: [''],
      objective: [''],
      proposedDate: [''],
      testBed: [''],
      testCondition: [''],
      noOfTestsPlanned: [''],
      TARBRadio: [''],
      tarbNo: [''],
      tarbvenue: [''],
      dateOfTarb: [''],
      tarbdoc: [''],
      TFRBRadio: [''],
      tfrbNo: [''],
      tfrbvenue: [''],
      dateOfTfrb: [''],
      tfrbdoc: [''],
      pressures: [''],
      thrust: [''],
      startSignal: [''],
      current: [''],
      temperature: [''],
      flow: [''],
      events: [''],
      others: [''],
      noOfChannels: [''],
      parameters: [''],
      portReq: [''],
      peak: [''],
      average: [''],
      signal: [''],
      riseTime: [''],
      recordingduration: [''],
      burnTime: [''],
      artProvide: [''],
      predProvide: [''],
      typeOfMotors: [''],
      noOfMotors: [''],
      throatDiameter: [''],
      typeOfPropellant: [''],
      weightOfPropellant: [''],
      throatDiaPropell: [''],
      cameratype: [''],
      location: [''],
      frameRate: [''],
      duration: [''],
      photoReqRadio: [''],
      digitalDisplay: [''],
      acquisitReqRadio: [''],
      analogFrom: [''],
      analogTo: [''],
      analogTimeInterval: [''],
      digitalFrom: [''],
      digitalTo: [''],
      digitalTimeInterval: [''],
      analysisReq: [''],
      copyReq: [''],
      name: [''],
      designation: [''],
      division: [''],
      role: [''],
      phoneNo: [''],
      mobileNo: [''],
      nameDoi: [''],
      controllingOfficer: [''],
      phNo: [''],
      telNo: [''],
      mobileNoDoi: [''],

    });
  }
  SaveToDraft() {
    const formData = this.DOIf12.value;
    const DOIf12Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf12Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf12.value;
    const DOIf12Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf12Data);

    console.log(payload);
  }
}
