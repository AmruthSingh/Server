import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF12Component } from './doi-f12.component';

describe('DoiF12Component', () => {
  let component: DoiF12Component;
  let fixture: ComponentFixture<DoiF12Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF12Component]
    });
    fixture = TestBed.createComponent(DoiF12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
