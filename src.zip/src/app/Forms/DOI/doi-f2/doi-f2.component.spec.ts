import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF2Component } from './doi-f2.component';

describe('DoiF2Component', () => {
  let component: DoiF2Component;
  let fixture: ComponentFixture<DoiF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF2Component]
    });
    fixture = TestBed.createComponent(DoiF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
