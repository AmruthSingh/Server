import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f2',
  templateUrl: './doi-f2.component.html',
  styleUrls: ['./doi-f2.component.css']
})
export class DoiF2Component {
  DOIf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf2 = this.formBuilder.group({
      calibRef: [''],
      date: [''],
      reqRef: [''],
      time: [''],
      reqBy: [''],
      purpose: [""],
      sensorType: [''],
      sensorRange: [''],
      sensorUnit: [''],
      sensorMake: [''],
      sensorModel: [''],
      sensorSerailNo: [''],
      sensorBridge: [''],
      sensorFSO: [''],
      sensorExcitation: [''],
      calibType: [''],
      excitType: [''],
      measureType: [''],
      calibMake: [''],
      excitMake: [''],
      measureMake: [''],
      calibSerial: [''],
      excitSerail: [''],
      measureSerail: [''],
      calibAccuracy: [''],
      excitAccuracy: [''],
      measureAccuracy: [''],
      calibAgency: [''],
      excitAgency: [''],
      measureAgency: [''],
      calibCalibOn: [''],
      excitCalibOn: [''],
      measureCalibOn: [''],
      calibDueOn: [''],
      excitDueOn: [''],
      measureDueOn: [''],
      temp: [''],
      humidity: [''],
      gravity: [''],
      calibDate: [''],
      load: [''],
      inc: [''],
      dec: [''],
      offset: [''],
      sensitivity: [''],
      linearity: [''],
      repeatability: [''],
      hysteresis: [''],
      overallAccuracy: [''],
      Fit: [''],
      Unfit: [''],
      sixMonths: [''],
      oneYear: [''],
      remark: [''],
      claibBy: [''],
      checkBy: [''],

    });
  }
  SaveToDraft() {
    const formData = this.DOIf2.value;
    const DOIf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf2.value;
    const DOIf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf2Data);

    console.log(payload);
  }
}
