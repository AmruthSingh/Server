import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoiF5Component } from './doi-f5.component';

describe('DoiF5Component', () => {
  let component: DoiF5Component;
  let fixture: ComponentFixture<DoiF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoiF5Component]
    });
    fixture = TestBed.createComponent(DoiF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
