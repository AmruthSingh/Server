import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doi-f5',
  templateUrl: './doi-f5.component.html',
  styleUrls: ['./doi-f5.component.css']
})
export class DoiF5Component {
  DOIf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOIf5 = this.formBuilder.group({
      slNo: [''],
      parameter: [''],
      exValue: [''],
      enggUnit: [''],
      range: [''],
      sNo: [''],
      labSens: [''],
      exc: [''],
      scModule: [''],
      chNo: [''],
      gain: [''],
      filter: [''],
      dasName: [''],
      daqModule: [''],
      chNO: [''],
      enggConv: [''],
      samplingRate: [''],
      recordingTime: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DOIf5.value;
    const DOIf5Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOIf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOIf5.value;
    const DOIf5Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOIf5Data);

    console.log(payload);
  }
}
