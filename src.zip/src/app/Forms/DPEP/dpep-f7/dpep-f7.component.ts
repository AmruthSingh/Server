import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f7',
  templateUrl: './dpep-f7.component.html',
  styleUrls: ['./dpep-f7.component.css'],
})
export class DpepF7Component {
  DPEPf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf7 = this.formBuilder.group({
      from: [''],
      to: [''],
      rating1: [''],
      remark1: [''],
      rating2: [''],
      remark2: [''],
      rating3: [''],
      remark3: [''],
      rating4: [''],
      remark4: [''],
      rating5: [''],
      remark5: [''],
      rating6: [''],
      remark6: [''],
      rating7: [''],
      remark7: [''],
      rating8: [''],
      remark8: [''],
      rating9: [''],
      remark9: [''],
      rating10: [''],
      remark10: [''],
      rating11: [''],
      remark11: [''],
      rating12: [''],
      remark12: [''],
      feedback: [''],
      suggestions: [''],
      sign: [''],
      name: [''],
      designation: [''],
      nameProject: [''],
      overallRating: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DPEPf7.value;
    const DPEPf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf7.value;
    const DPEPf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf7Data);

    console.log(payload);
  }
}
