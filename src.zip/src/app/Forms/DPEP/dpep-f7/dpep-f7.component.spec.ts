import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF7Component } from './dpep-f7.component';

describe('DpepF7Component', () => {
  let component: DpepF7Component;
  let fixture: ComponentFixture<DpepF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF7Component]
    });
    fixture = TestBed.createComponent(DpepF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
