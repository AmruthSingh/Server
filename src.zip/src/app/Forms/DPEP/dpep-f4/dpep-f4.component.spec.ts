import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF4Component } from './dpep-f4.component';

describe('DpepF4Component', () => {
  let component: DpepF4Component;
  let fixture: ComponentFixture<DpepF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF4Component]
    });
    fixture = TestBed.createComponent(DpepF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
