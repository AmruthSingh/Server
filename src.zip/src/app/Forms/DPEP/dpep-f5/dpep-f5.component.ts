import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f5',
  templateUrl: './dpep-f5.component.html',
  styleUrls: ['./dpep-f5.component.css']
})
export class DpepF5Component {
  DPEPf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf5 = this.formBuilder.group({
      project:[''],
      date:[''],
      authority:[''],
      subSystem:[''],
      remarks:[''],
      signUser:[''],
      signCc:[''],
      nameUser:[''],
      nameCc:[''],
      desigUser:[''],
      DesigCC:[''],
      phnoUser:[''],
      phnoCc:[''],
      comments:[''],
      sign:[''],
      name:[''],
      designation:[''],
      dAte:[''],
      workNo:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.DPEPf5.get('rows') as FormArray;
  }
  createRow(): FormGroup {
    return this.formBuilder.group({
      sloNo:[''],
      nomenclature:[''],
      modifications:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DPEPf5.value;
    const DPEPf5Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf5.value;
    const DPEPf5Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf5Data);

    console.log(payload);
  }
}
