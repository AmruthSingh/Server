import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF3Component } from './dpep-f3.component';

describe('DpepF3Component', () => {
  let component: DpepF3Component;
  let fixture: ComponentFixture<DpepF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF3Component]
    });
    fixture = TestBed.createComponent(DpepF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
