import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f3',
  templateUrl: './dpep-f3.component.html',
  styleUrls: ['./dpep-f3.component.css'],
})
export class DpepF3Component {
  DPEPf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf3 = this.formBuilder.group({
      workNo: [''],
      workSummary: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DPEPf3.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      date: [''],
      workProgress: [''],
      signScientist: [''],
      signDivhead: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DPEPf3.value;
    const DPEPf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf3.value;
    const DPEPf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf3Data);

    console.log(payload);
  }
}
