import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f2',
  templateUrl: './dpep-f2.component.html',
  styleUrls: ['./dpep-f2.component.css'],
})
export class DpepF2Component {
  DPEPf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf2 = this.formBuilder.group({
      workNo: [''],
      nomenclature: [''],
      project: [''],
      sysManager: [''],
      membersInvolved: [''],
      workBreakup: [''],
      pdcWork: [''],
      remarks: [''],
      divisionHead: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DPEPf2.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      activityNo: [''],
      activity: [''],
      responsibility: [''],
      inputsReq: [''],
      output: [''],
      timeReq: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DPEPf2.value;
    const DPEPf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf2.value;
    const DPEPf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf2Data);

    console.log(payload);
  }
}
