import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF2Component } from './dpep-f2.component';

describe('DpepF2Component', () => {
  let component: DpepF2Component;
  let fixture: ComponentFixture<DpepF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF2Component]
    });
    fixture = TestBed.createComponent(DpepF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
