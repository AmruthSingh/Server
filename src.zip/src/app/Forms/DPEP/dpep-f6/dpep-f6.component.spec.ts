import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF6Component } from './dpep-f6.component';

describe('DpepF6Component', () => {
  let component: DpepF6Component;
  let fixture: ComponentFixture<DpepF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF6Component]
    });
    fixture = TestBed.createComponent(DpepF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
