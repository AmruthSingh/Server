import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f6',
  templateUrl: './dpep-f6.component.html',
  styleUrls: ['./dpep-f6.component.css'],
})
export class DpepF6Component {
  DPEPf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf6 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DPEPf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      workNo: [''],
      workApproveddate: [''],
      project: [''],
      nomenclature: [''],
      process: [''],
      tastTeam: [''],
      descOutput: [''],
      pdcorRevpdc: [''],
      workClosingdate: [''],
      status: [''],
      remarks: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DPEPf6.value;
    const DPEPf6Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf6.value;
    const DPEPf6Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf6Data);

    console.log(payload);
  }
}
