import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpepF1Component } from './dpep-f1.component';

describe('DpepF1Component', () => {
  let component: DpepF1Component;
  let fixture: ComponentFixture<DpepF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DpepF1Component]
    });
    fixture = TestBed.createComponent(DpepF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
