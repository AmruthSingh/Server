import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dpep-f1',
  templateUrl: './dpep-f1.component.html',
  styleUrls: ['./dpep-f1.component.css'],
})
export class DpepF1Component {
  DPEPf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DPEPf1 = this.formBuilder.group({
      project: [''],
      directorate:[''],
      date: [''],
      nomenclature: [''],
      reqSystem: [''],
      quantity: [''],
      input: [''],
      output: [''],
      remarks: [''],
      signUser: [''],
      signHead: [''],
      nameUser: [''],
      nameHead: [''],
      desigUser: [''],
      DesigHead: [''],
      phnoUser: [''],
      phnoHead: [''],
      cs01: [''],
      cs02: [''],
      cs03: [''],
      cs04: [''],
      cs05: [''],
      cs06: [''],
      cs07: [''],
      cs08: [''],
      cs09: [''],
      cs10: [''],
      cs11: [''],
      carriedOut: [''],
      notAdequate: [''],
      recommendation: [''],
      sign: [''],
      name: [''],
      designation: [''],
      dATe: [''],
      approve: [''],
      techDir: [''],
      workNo: [''],
      dAte: [''],
      agreedPdc: [''],
      extPdc: [''],
      to: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DPEPf1.value;
    const DPEPf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DPEPf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DPEPf1.value;
    const DPEPf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DPEPf1Data);

    console.log(payload);
  }
}
