import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f2',
  templateUrl: './ivv-f2.component.html',
  styleUrls: ['./ivv-f2.component.css']
})
export class IvvF2Component {
  IVVf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf2 = this.formBuilder.group({
      projectName:[''],
      subSysName:[''],
      whereApplicable:[''],
      anyOther:[''],
      anyreview:[''],
      putMark:[''],
      enclosed:[''],
      devName:[''],
      presentVer:[''],
      preViousentVer:[''],
      softMedia:[''],
      softDetails:[''],
      codeSize:[''],
      langUsed:[''],
      compilereUsed:[''],
      makeFile:[''],
      devEnvi:[''],
      guiEnvi:[''],
      openSource:[''],
      MutuallyPdc:[''],
      accNotacc:[''],
      remIfany:[''],
      signatureLast:[''],
      name:[''],
      desig:[''],
      date:[''],
      signatureSecond:[''],
      nameSecond:[''],
      designationSecond:[''],
      divDire:[''],
      projectLab:[''],
      dateSecond:[''],
      projectNameSecoond:[''],
      subSysNameSecond:[''],
      reqFor:[''],
      anyOthe:[''],
      refA:[''],
      markPut:[''],
      devNames:[''],
      presentVersion:[''],
      preViousentVersion:[''],
      MutuallyPdcs:[''],
      accNotac:[''],
      remIfAny:[''],
      signatureLas:[''],
      nameSec:[''],
      DesigSec:[''],
      dateSec:[''],
      signatureSecon:[''],
      nameSecon:[''],
      designationSecon:[''],
      divDirec:[''],
      projectL:[''],
      dateSecs:[''],


      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.IVVf2.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      documentName:[''],
      docMed:[''],
      noOfPages:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf2.value;
    const IVVf2Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf2.value;
    const IVVf2Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf2Data);

    console.log(payload);
  }
}
