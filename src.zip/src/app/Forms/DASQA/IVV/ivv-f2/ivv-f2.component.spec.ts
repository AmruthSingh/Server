import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF2Component } from './ivv-f2.component';

describe('IvvF2Component', () => {
  let component: IvvF2Component;
  let fixture: ComponentFixture<IvvF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF2Component]
    });
    fixture = TestBed.createComponent(IvvF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
