import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF7Component } from './ivv-f7.component';

describe('IvvF7Component', () => {
  let component: IvvF7Component;
  let fixture: ComponentFixture<IvvF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF7Component]
    });
    fixture = TestBed.createComponent(IvvF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
