import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f7',
  templateUrl: './ivv-f7.component.html',
  styleUrls: ['./ivv-f7.component.css']
})
export class IvvF7Component {
  IVVf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf7 = this.formBuilder.group({
      nameOfTest:[''],
      projectName:[''],
      system:[''],
      taskNo:[''],
      validatedBy:[''],
      versionCheck:[''],
      obserDate:[''],
      revBy:[''],
      changeIni:[''],
      resDate:[''],
      appBy:[''],
      testingSite:[''],
      veriDate:[''],
      devTeam:[''],
      baselineRefNo:[''],
      genObs:[''],
      userObs:[''],
      signOfDevAutho:[''],
      name:[''],
      des:[''],
      desDate:[''],
      signOfAuth:[''],
      nameSec:[''],
      desSec:[''],
      desDateSec:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.IVVf7.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      sysSubSystemModu:[''],
      changeId:[''],
      caseNo:[''],
      testSenario:[''],
      testProcedure:[''],
      preCondi:[''],
      expectedResult:[''],
      observedResult:[''],
      testCaseStatus:[''],
      observationType:[''],
      obserClosure:[''],
      devTeamRem:[''],
      ObservationN:[''],
      teamRem:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf7.value;
    const IVVf7Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf7.value;
    const IVVf7Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf7Data);

    console.log(payload);
  }
}
