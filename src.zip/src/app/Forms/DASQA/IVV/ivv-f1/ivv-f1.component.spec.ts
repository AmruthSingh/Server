import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF1Component } from './ivv-f1.component';

describe('IvvF1Component', () => {
  let component: IvvF1Component;
  let fixture: ComponentFixture<IvvF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF1Component]
    });
    fixture = TestBed.createComponent(IvvF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
