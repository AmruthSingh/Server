import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f1',
  templateUrl: './ivv-f1.component.html',
  styleUrls: ['./ivv-f1.component.css'],
})
export class IvvF1Component {
  IVVf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf1 = this.formBuilder.group({
      project: [''],
      date: [''],
      system: [''],
      name: [''],
      designation: [''],
      techDirector: [''],
    });
  }
  SaveToDraft() {
    const formData = this.IVVf1.value;
    const IVVf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(IVVf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf1.value;
    const IVVf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(IVVf1Data);

    console.log(payload);
  }
  // submitForm() {
  //   const formData = this.IVVf1.value;
  //   this.http.post('http://localhost:3000/api/IVVf1table', formData).subscribe(
  //     (response) => {
  //       console.log('Data saved successfully', response);
  //     },
  //     (error) => {
  //       console.error('Error saving data:', error);
  //     }
  //   );
  // }
}
