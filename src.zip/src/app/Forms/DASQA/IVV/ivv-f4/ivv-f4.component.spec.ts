import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF4Component } from './ivv-f4.component';

describe('IvvF4Component', () => {
  let component: IvvF4Component;
  let fixture: ComponentFixture<IvvF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF4Component]
    });
    fixture = TestBed.createComponent(IvvF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
