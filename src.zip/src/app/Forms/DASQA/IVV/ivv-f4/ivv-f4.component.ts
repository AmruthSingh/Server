import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f4',
  templateUrl: './ivv-f4.component.html',
  styleUrls: ['./ivv-f4.component.css']
})
export class IvvF4Component {
  IVVf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf4 = this.formBuilder.group({
      projectName:[''],
      system:[''],
      mission:[''],
      taskNo:[''],
      taskStatus:[''],
      timelyCompletion:[''],
      startDate:[''],
      estimatedPdc:[''],
      projectrepresentative:[''],
      endDate:[''],
      actualPdc:[''],
      referenceNo:[''],
      signSysMgr:[''],
      nameSysMgr:[''],
      designationSysMgr:[''],
      dateSysMgr:[''],
      signHead:[''],
      nameHead:[''],
      designationHead:[''],
      dateHead:[''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.IVVf4.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    majorActivity:[''],
    subActivity:[''],
    activityIdentified:[''],
    precondition:[''],
    estimatedStart:[''],
    estimatedEnd:[''],
    actualStart:[''],
    actualEnd:[''],
    teamMembers:[''],
    numObservations:[''],
    remarks:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf4.value;
    const IVVf4Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf4.value;
    const IVVf4Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf4Data);

    console.log(payload);
  }
}
