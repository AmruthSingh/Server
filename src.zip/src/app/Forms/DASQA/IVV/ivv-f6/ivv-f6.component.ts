import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f6',
  templateUrl: './ivv-f6.component.html',
  styleUrls: ['./ivv-f6.component.css']
})
export class IvvF6Component {
  IVVf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf6 = this.formBuilder.group({
      projectName:[''],
      system:[''],
      taskNo: [''],
      validatedBy:[''],
      obsDate: [''],
      reviewedBy: [''],
      respDate: [''],
      approvedBy: [''],
      verDate: [''],
      refNo:[''],
      genObs: [''],
      genObsOne: [''],
      userObs: [''],
      userObsOne: [''],
      signatureOfProjAuth: [''],
      signatureOfIvvAuth: [''],
      nameProjAuth: [''],
      nameIvvAuth: [''],
      designationProjAuth: [''],
      designationIvvAuth: [''],
      dateProjAuth: [''],
      dateIvvAuth: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.IVVf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      bugId: [''],
      file:[''],
      function:[''],
      obsDetails: [''],
      obsType: [''],
      obsStatus: [''],
      devptRemarks: [''],
      obsClosureStatus: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf6.value;
    const IVVf6Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf6.value;
    const IVVf6Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf6Data);

    console.log(payload);
  }
}
