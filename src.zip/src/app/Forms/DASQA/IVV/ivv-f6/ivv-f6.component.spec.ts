import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF6Component } from './ivv-f6.component';

describe('IvvF6Component', () => {
  let component: IvvF6Component;
  let fixture: ComponentFixture<IvvF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF6Component]
    });
    fixture = TestBed.createComponent(IvvF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
