import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f8',
  templateUrl: './ivv-f8.component.html',
  styleUrls: ['./ivv-f8.component.css']
})
export class IvvF8Component {
  IVVf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf8 = this.formBuilder.group({
      refNo:[''],
      date:[''],
      nameOfSoftware: [''],
      nameOfProj:[''],
      systemName: [''],
      issuingAuth: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.IVVf8.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      subSystem: [''],
      version:[''],
      checkSum:[''],
      sizeInBytes: [''],
      Date: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf8.value;
    const IVVf8Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf8Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf8.value;
    const IVVf8Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf8Data);

    console.log(payload);
  }
}
