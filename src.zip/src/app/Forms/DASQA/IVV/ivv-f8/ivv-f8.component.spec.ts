import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF8Component } from './ivv-f8.component';

describe('IvvF8Component', () => {
  let component: IvvF8Component;
  let fixture: ComponentFixture<IvvF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF8Component]
    });
    fixture = TestBed.createComponent(IvvF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
