import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF3Component } from './ivv-f3.component';

describe('IvvF3Component', () => {
  let component: IvvF3Component;
  let fixture: ComponentFixture<IvvF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF3Component]
    });
    fixture = TestBed.createComponent(IvvF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
