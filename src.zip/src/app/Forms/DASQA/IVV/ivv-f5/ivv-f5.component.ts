import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f5',
  templateUrl: './ivv-f5.component.html',
  styleUrls: ['./ivv-f5.component.css'],
})
export class IvvF5Component {
  IVVf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf5 = this.formBuilder.group({
      nameOfDoc:[''],
      verOfDoc:[''],
      projectName:[''],
      system:[''],
      taskNo: [''],
      reviewedBy: [''],
      obsDate: [''],
      approvedBy: [''],
      respDate: [''],
      verDate: [''],
      genObs: [''],
      genObsOne: [''],
      userObs: [''],
      userObsOne: [''],
      signatureOfProjAuth: [''],
      signatureOfIvvAuth: [''],
      nameProjAuth: [''],
      nameIvvAuth: [''],
      designationProjAuth: [''],
      designationIvvAuth: [''],
      dateProjAuth: [''],
      dateIvvAuth: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.IVVf5.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      reqId: [''],
      observation: [''],
      obsDetails: [''],
      obsType: [''],
      obsStatus: [''],
      devptRemarks: [''],
      obsClosureStatus: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf5.value;
    const IVVf5Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf5.value;
    const IVVf5Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf5Data);

    console.log(payload);
  }
}
