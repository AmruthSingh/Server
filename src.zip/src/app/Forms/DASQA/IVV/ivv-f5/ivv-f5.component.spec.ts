import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF5Component } from './ivv-f5.component';

describe('IvvF5Component', () => {
  let component: IvvF5Component;
  let fixture: ComponentFixture<IvvF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF5Component]
    });
    fixture = TestBed.createComponent(IvvF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
