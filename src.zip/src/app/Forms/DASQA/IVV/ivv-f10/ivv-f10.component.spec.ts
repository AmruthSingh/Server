import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF10Component } from './ivv-f10.component';

describe('IvvF10Component', () => {
  let component: IvvF10Component;
  let fixture: ComponentFixture<IvvF10Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF10Component]
    });
    fixture = TestBed.createComponent(IvvF10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
