import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f10',
  templateUrl: './ivv-f10.component.html',
  styleUrls: ['./ivv-f10.component.css']
})
export class IvvF10Component {
  IVVf10: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf10 = this.formBuilder.group({
      programProject:[''],
      systemSubSystem:[''],
      timeCompletion:[''],
      obserSuggestion:[''],
      carriedOut:[''],
      domainUnderStan:[''],
      priorityToTask:[''],
      betweenDev:[''],
      averageScore:[''],
      yesOrNo:[''],
      anyOtherSugg:[''],
      sigOfRep:[''],
      name:[''],
      des:[''],
      date:[''],
    });
  }
  SaveToDraft(){
    const formData = this.IVVf10.value;
    const IVVf10Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf10Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf10.value;
    const IVVf10Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf10Data);

    console.log(payload);
  }
}
