import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IvvF9Component } from './ivv-f9.component';

describe('IvvF9Component', () => {
  let component: IvvF9Component;
  let fixture: ComponentFixture<IvvF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IvvF9Component]
    });
    fixture = TestBed.createComponent(IvvF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
