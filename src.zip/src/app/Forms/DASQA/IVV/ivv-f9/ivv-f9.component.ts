import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ivv-f9',
  templateUrl: './ivv-f9.component.html',
  styleUrls: ['./ivv-f9.component.css']
})
export class IvvF9Component {
  IVVf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.IVVf9 = this.formBuilder.group({
      projectName:[''],
      system:[''],
      projectMaintain:[''],
      testingSite:[''],
      refNo:[''],
      relVerNo:[''],
      obserDate:[''],
      revBy:[''],
      signOfDevAutho:[''],
      name:[''],
      des:[''],
      desDate:[''],
      signOfAuth:[''],
      nameSec:[''],
      desSec:[''],
      desDateSec:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.IVVf9.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      changeReqNo:[''],
      perNoId:[''],
      iniDate:[''],
      ref:[''],
      chaIniBy:[''],
      desChange:[''],
      changeType:[''],
      impOfChange:[''],
      modWithVerNo:[''],
      impBy:[''],
      filesAffe:[''],
      funcName:[''],
      qa:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.IVVf9.value;
    const IVVf9Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(IVVf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.IVVf9.value;
    const IVVf9Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(IVVf9Data);

    console.log(payload);
  }
}
