import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF9Component } from './nded-f9.component';

describe('NdedF9Component', () => {
  let component: NdedF9Component;
  let fixture: ComponentFixture<NdedF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF9Component]
    });
    fixture = TestBed.createComponent(NdedF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
