import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f9',
  templateUrl: './nded-f9.component.html',
  styleUrls: ['./nded-f9.component.css'],
})
export class NdedF9Component {
  NDEDf9:FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf9 = this.formBuilder.group({
      irNo: [''],
      nomen: [''],
      drawNo: [''],
      project: [''],
      jobNo: [''],
      itemNo: [''],
      lotNo: [''],
      rgNo: [''],
      qty: [''],
      opNo: [''],
      compNo: [''],
      inspBy: [''],
      date: [''],
      xray: [''],
      refStd: [''],
      mat: [''],
      thickness: [''],
      kV: [''],
      mA: [''],
      focusSize: [''],
      sfd: [''],
      filmType: [''],
      filmSize: [''],
      noOfFilms: [''],
      iqi: [''],
      filmDens: [''],
      qt: [''],
      acce: [''],
      forRewo: [''],
      Rejec: [''],
      signOfInsp: [''],
      signOfHead: [''],
      dateOfInsp: [''],
      dateOfHead: [''],
      irNoUT: [''],
      qtEval: [''],
      accept: [''],
      forRework: [''],
      Reject: [''],
      signOfInspect: [''],
      signOfHeadNDED: [''],
      dateOfInspect: [''],
      dateOfHeadNDED: [''],
      time: [''],
      compNoo: [''],
      zoneNo: [''],
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf9.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      compNo:[''],
      zoneNo:[''],
      obs:[''],
      remarks:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rowss(): FormArray {
    return this.NDEDf9.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      slNoObs:[''],
      compNoObs:[''],
      zoneNoObs:[''],
      obsObs:[''],
      remarksObs:[''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf9.value;
    const NDEDf9Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf9.value;
    const NDEDf9Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf9Data);

    console.log(payload);
  }
}


