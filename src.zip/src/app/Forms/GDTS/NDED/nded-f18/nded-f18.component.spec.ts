import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF18Component } from './nded-f18.component';

describe('NdedF18Component', () => {
  let component: NdedF18Component;
  let fixture: ComponentFixture<NdedF18Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF18Component]
    });
    fixture = TestBed.createComponent(NdedF18Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
