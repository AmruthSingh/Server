import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF16Component } from './nded-f16.component';

describe('NdedF16Component', () => {
  let component: NdedF16Component;
  let fixture: ComponentFixture<NdedF16Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF16Component]
    });
    fixture = TestBed.createComponent(NdedF16Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
