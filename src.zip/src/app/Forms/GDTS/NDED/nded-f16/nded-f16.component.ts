import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f16',
  templateUrl: './nded-f16.component.html',
  styleUrls: ['./nded-f16.component.css'],
})
export class NdedF16Component {
  NDEDf16: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf16 = this.formBuilder.group({
      irNo:[''],
     nomen:[''],
     drawNo:[''],
     project:[''],
     jobNo:[''],
     itemNo:[''],
     lotNo:[''],
     rgNo:[''],
     qty:[''],
     opNo:[''],
     compNo:[''],
     inspBy:[''],
     date:[''],
     xray:[''],
     refStd:[''],
     mat:[''],
     thickness:[''],
     dose:[''],
     sfd:[''],
     filterUsed:[''],
     filmType:[''],
     filmSize:[''],
     noOfFilms:[''],
     screens:[''],
     iqi:[''],
     filmDens:[''],
     shootingSketch:[''],
     qt:[''],
     acce:[''],
     forRewo:[''],
     Rejec:[''],
     signOfInsp:[''],
     signOfHead:[''],
     dateOfInsp:[''],
     dateOfHead:[''],
     irNoLRT:[''],
     qtEval:[''],
     accept:[''],
     forRework:[''],
     Reject:[''],
     signOfInspect:[''],
     signOfHeadNDED:[''],
     dateOfInspect:[''],
     dateOfHeadNDED:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.NDEDf16.get('rows') as FormArray;
  }
  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      compoNo: [''],
      zoneNo: [''],
      obs: [''],
      remarks: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }
  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf16.value;
    const NDEDf16Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf16Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf16.value;
    const NDEDf16Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf16Data);

    console.log(payload);
  }
}
