import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF4Component } from './nded-f4.component';

describe('NdedF4Component', () => {
  let component: NdedF4Component;
  let fixture: ComponentFixture<NdedF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF4Component]
    });
    fixture = TestBed.createComponent(NdedF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
