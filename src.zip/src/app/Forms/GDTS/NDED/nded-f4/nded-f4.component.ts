import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f4',
  templateUrl: './nded-f4.component.html',
  styleUrls: ['./nded-f4.component.css']
})
export class NdedF4Component {

  NDEDf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf4 = this.formBuilder.group({
      project:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      jobDate:[''],
      workOrderNo:[''],
      workOrderDate:[''],
      nomenclature:[''],
      drawNo:[''],
      material:[''],
      quantity:[''],
      procPlanners:[''],
      inspector:[''],
      irNo:[''],
      irDate:[''],
      dateOfClosing:[''],

    flowChartNo:[''],
    prepBy:[''],
    releaseDate:[''],
    signature:[''],
    dateOIC:[''],
    sectionNo:[''],
    ndtMethods:[''],
    remarks:[''],
    signOfOIC:[''],
    signOfHead:[''],
    dateOfOIC:[''],
    dateOfHead:[''],
    });
  }
  SaveToDraft() {
    const formData = this.NDEDf4.value;
    const NDEDf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf4.value;
    const NDEDf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf4Data);

    console.log(payload);
  }
}
