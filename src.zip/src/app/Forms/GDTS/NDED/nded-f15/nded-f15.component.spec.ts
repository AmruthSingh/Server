import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF15Component } from './nded-f15.component';

describe('NdedF15Component', () => {
  let component: NdedF15Component;
  let fixture: ComponentFixture<NdedF15Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF15Component]
    });
    fixture = TestBed.createComponent(NdedF15Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
