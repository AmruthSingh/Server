import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f15',
  templateUrl: './nded-f15.component.html',
  styleUrls: ['./nded-f15.component.css']
})
export class NdedF15Component {
  NDEDf15: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf15= this.formBuilder.group({
      irNo:[''],
      nomen:[''],
      drawNo:[''],
      project:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      inspBy:[''],
      qty:[''],
      opNo:[''],
      compNo:[''],
      date:[''],
      mat:[''],
      surfCond:[''],
      areaOfExam:[''],
      purposeOfExam:[''],
      equipUsed:[''],
      emmi:[''],
      tempRange:[''],
      equipCalib:[''],
      sens:[''],
      scanDetails:[''],
      accRejCri:[''],
      refStd:[''],
      observations:[''],
      inspSketch:[''],
      qt:[''],
     acce:[''],
     forRewo:[''],
     Rejec:[''],
      signOfInsp:[''],
      signOfHead:[''],
      dateOfInsp:[''],
      dateOfHead:[''],
      irNoIRT:[''],
      qtEval:[''],
      accept:[''],
      forRework:[''],
      Reject:[''],
      signOfInspect:[''],
      signOfHeadNDED:[''],
      dateOfInspect:[''],
      dateOfHeadNDED:[''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.NDEDf15.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
    compoNo:[''],
    zoneNo:[''],
    obs:[''],
    remarks:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf15.value;
    const NDEDf15Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf15Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf15.value;
    const NDEDf15Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf15Data);

    console.log(payload);
  }
}
