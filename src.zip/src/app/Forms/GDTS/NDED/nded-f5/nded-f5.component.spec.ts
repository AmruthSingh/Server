import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF5Component } from './nded-f5.component';

describe('NdedF5Component', () => {
  let component: NdedF5Component;
  let fixture: ComponentFixture<NdedF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF5Component]
    });
    fixture = TestBed.createComponent(NdedF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
