import { Component } from '@angular/core';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f5',
  templateUrl: './nded-f5.component.html',
  styleUrls: ['./nded-f5.component.css']
})
export class NdedF5Component {
  NDEDf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf5 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf5.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      nomen:[''],
      quantity:[''],
      project:[''],
      jobReceivedDate:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rowss(): FormArray {
    return this.NDEDf5.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      jobComplDate:[''],
      ndeMethods:[''],
      workCenter:[''],
      remarks:[''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf5.value;
    const NDEDf5Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf5.value;
    const NDEDf5Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf5Data);

    console.log(payload);
  }
}
