import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f10',
  templateUrl: './nded-f10.component.html',
  styleUrls: ['./nded-f10.component.css']
})
export class NdedF10Component {
  NDEDf10: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf10 = this.formBuilder.group({
      irNo:[''],
      nomen:[''],
      drawNo:[''],
      project:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      inspBy:[''],
      qty:[''],
      opNo:[''],
      compNo:[''],
      date:[''],
      mat:[''],
      surfCond:[''],
      cleaner:[''],
      type:[''],
      emulsi:[''],
      developer:[''],
      media:[''],
      method:[''],
      sensitity:[''],
      observations:[''],
      inspSketch:[''],
      qt: [''],
      acce: [''],
      forRewo: [''],
      Rejec: [''],
      signOfInsp: [''],
      signOfHead: [''],
      dateOfInsp: [''],
      dateOfHead: [''],
    });
  }
  SaveToDraft() {
    const formData = this.NDEDf10.value;
    const NDEDf10Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf10Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf10.value;
    const NDEDf10Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf10Data);

    console.log(payload);
  }
}
