import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF10Component } from './nded-f10.component';

describe('NdedF10Component', () => {
  let component: NdedF10Component;
  let fixture: ComponentFixture<NdedF10Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF10Component]
    });
    fixture = TestBed.createComponent(NdedF10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
