import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF19Component } from './nded-f19.component';

describe('NdedF19Component', () => {
  let component: NdedF19Component;
  let fixture: ComponentFixture<NdedF19Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF19Component]
    });
    fixture = TestBed.createComponent(NdedF19Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
