import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF17Component } from './nded-f17.component';

describe('NdedF17Component', () => {
  let component: NdedF17Component;
  let fixture: ComponentFixture<NdedF17Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF17Component]
    });
    fixture = TestBed.createComponent(NdedF17Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
