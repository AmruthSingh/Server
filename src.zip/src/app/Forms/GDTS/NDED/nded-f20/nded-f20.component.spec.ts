import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF20Component } from './nded-f20.component';

describe('NdedF20Component', () => {
  let component: NdedF20Component;
  let fixture: ComponentFixture<NdedF20Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF20Component]
    });
    fixture = TestBed.createComponent(NdedF20Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
