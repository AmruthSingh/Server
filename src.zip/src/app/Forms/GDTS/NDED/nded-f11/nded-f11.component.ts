import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f11',
  templateUrl: './nded-f11.component.html',
  styleUrls: ['./nded-f11.component.css'],
})
export class NdedF11Component {
  NDEDf11: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf11 = this.formBuilder.group({
      irNo: [''],
      nomen: [''],
      drawNo: [''],
      project: [''],
      jobNo: [''],
      itemNo: [''],
      lotNo: [''],
      inspBy: [''],
      qty: [''],
      opNo: [''],
      compNo: [''],
      date: [''],
      mat: [''],
      surfCond: [''],
      areaOfExam: [''],
      purposeOfExam: [''],
      equipUseed: [''],
      probe: [''],
      couplantUsed: [''],
      euipCalib: [''],
      sens: [''],
      scanDetails: [''],
      accRejCri: [''],
      refStd: [''],
      observations: [''],
      inspSketch: [''],
      qt: [''],
      acce: [''],
      forRewo: [''],
      Rejec: [''],
      signOfInsp: [''],
      signOfHead: [''],
      dateOfInsp: [''],
      dateOfHead: [''],
      irNoUT: [''],
      qtEval: [''],
      accept: [''],
      forRework: [''],
      Reject: [''],
      signOfInspect: [''],
      signOfHeadNDED: [''],
      dateOfInspect: [''],
      dateOfHeadNDED: [''],

      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf11.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      compoNo: [''],
      zoneNo: [''],
      obs: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.NDEDf11.value;
    const NDEDf11Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf11Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf11.value;
    const NDEDf11Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf11Data);

    console.log(payload);
  }
}
