import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF11Component } from './nded-f11.component';

describe('NdedF11Component', () => {
  let component: NdedF11Component;
  let fixture: ComponentFixture<NdedF11Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF11Component]
    });
    fixture = TestBed.createComponent(NdedF11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
