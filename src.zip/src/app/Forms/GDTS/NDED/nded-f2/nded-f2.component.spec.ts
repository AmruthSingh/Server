import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF2Component } from './nded-f2.component';

describe('NdedF2Component', () => {
  let component: NdedF2Component;
  let fixture: ComponentFixture<NdedF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF2Component]
    });
    fixture = TestBed.createComponent(NdedF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
