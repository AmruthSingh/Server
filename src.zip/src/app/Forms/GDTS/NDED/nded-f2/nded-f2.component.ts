import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f2',
  templateUrl: './nded-f2.component.html',
  styleUrls: ['./nded-f2.component.css'],
})
export class NdedF2Component {
  NDEDf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf2 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf2.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      jobNo: [''],
      itemNo: [''],
      lotNo: [''],
      opNo: [''],
      project: [''],
      jobNomen: [''],
      compNo: [''],
      eval: [''],
      acc: [''],
      rew: [''],
      rej: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rowss(): FormArray {
    return this.NDEDf2.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      ndeMethod: [''],
      irNo: [''],
      irDate: [''],
      receivedDate: [''],
      delivDate: [''],
      noOfWorkDays: [''],
      toShop: [''],
      inspBy: [''],
      remarks: [''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf2.value;
    const NDEDf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf2.value;
    const NDEDf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf2Data);

    console.log(payload);
  }
}
