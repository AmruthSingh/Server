import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f6',
  templateUrl: './nded-f6.component.html',
  styleUrls: ['./nded-f6.component.css']
})
export class NdedF6Component {
  NDEDf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf6 = this.formBuilder.group({
      flowChartNo:[''],
      date:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      project:[''],
      division:[''],
      nomen:[''],
      qty:[''],
      drawNo:[''],
      dateOfReceipt:[''],
      quanEval:[''],
      accepted :[''],
      rework:[''],
      rejected:[''],
      obs:[''],
      irNo:[''],
      irDate:[''],
      signOfInsp:[''],
      dateOfInsp:[''],
      receiverSign:[''],
      name:[''],
      desig:[''],
      divDirec:[''],
      dateOfReceiver:[''],
      telNo:[''],
      signOfHead:[''],
      dateOfHead:[''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.NDEDf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    opNo:[''],
    ndeMethods:[''],
    section:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.NDEDf6.value;
    const NDEDf6Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf6.value;
    const NDEDf6Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf6Data);

    console.log(payload);
  }
}


