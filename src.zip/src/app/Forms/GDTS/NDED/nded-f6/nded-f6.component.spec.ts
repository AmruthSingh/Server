import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF6Component } from './nded-f6.component';

describe('NdedF6Component', () => {
  let component: NdedF6Component;
  let fixture: ComponentFixture<NdedF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF6Component]
    });
    fixture = TestBed.createComponent(NdedF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
