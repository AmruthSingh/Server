import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f8',
  templateUrl: './nded-f8.component.html',
  styleUrls: ['./nded-f8.component.css']
})
export class NdedF8Component {

  NDEDf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf8 = this.formBuilder.group({
     activity:[''],
     project:[''],
     workOrderNo:[''],
     date:[''],
     direc:[''],
     div:[''],
     reqForSys:[''],
     modeOfUsage:[''],
     sourceOfMaterial:[''],
     matSupplyDate:[''],
     ndeMethods:[''],
     accCri:[''],
     indenterSign:[''],
     divHeadSign:[''],
     nameDesigOfInd:[''],
     nameDesigDivHead:[''],
     telNoOfInd:[''],
     invNoOfInd:[''],
     telNoOfHead:[''],
     workOrderFeasRecomm:[''],
     sign:[''],
     name:[''],
     jobAsTo:[''],
     approve:[''],
     techDir:[''],
     jobNo:[''],
     datetech:[''],
     rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.NDEDf8.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slNo:[''],
     drawNo:[''],
     nomen:[''],
     qty:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf8.value;
    const NDEDf8Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf8Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf8.value;
    const NDEDf8Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf8Data);

    console.log(payload);
  }
}


