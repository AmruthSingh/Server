import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF8Component } from './nded-f8.component';

describe('NdedF8Component', () => {
  let component: NdedF8Component;
  let fixture: ComponentFixture<NdedF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF8Component]
    });
    fixture = TestBed.createComponent(NdedF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
