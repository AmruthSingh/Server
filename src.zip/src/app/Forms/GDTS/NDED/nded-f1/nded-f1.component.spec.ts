import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF1Component } from './nded-f1.component';

describe('NdedF1Component', () => {
  let component: NdedF1Component;
  let fixture: ComponentFixture<NdedF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF1Component]
    });
    fixture = TestBed.createComponent(NdedF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
