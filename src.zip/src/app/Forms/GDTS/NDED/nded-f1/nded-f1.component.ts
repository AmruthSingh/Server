import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f1',
  templateUrl: './nded-f1.component.html',
  styleUrls: ['./nded-f1.component.css'],
})
export class NdedF1Component {
  NDEDf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf1 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      jobNo: [''],
      project: [''],
      jobNomen: [''],
      itemNo: [''],
      lotNo: [''],
      compNo: [''],
      opNo: [''],
      eval: [''],
      acc: [''],
      rew: [''],
      rej: [''],
      refStd: [''],
      kV: [''],
      mA: [''],
      time: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rowss(): FormArray {
    return this.NDEDf1.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      sfd: [''],
      type: [''],
      size: [''],
      noOfFilms: [''],
      jobReceivedDate: [''],
      jobDelivDate: [''],
      noOfWorkDays: [''],
      irNo: [''],
      irDate: [''],
      inspBy: [''],
      toShop: [''],
      remarks: [''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf1.value;
    const NDEDf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf1.value;
    const NDEDf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf1Data);

    console.log(payload);
  }
}
