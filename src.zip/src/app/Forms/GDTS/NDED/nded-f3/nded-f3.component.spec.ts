import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF3Component } from './nded-f3.component';

describe('NdedF3Component', () => {
  let component: NdedF3Component;
  let fixture: ComponentFixture<NdedF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF3Component]
    });
    fixture = TestBed.createComponent(NdedF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
