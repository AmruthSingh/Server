import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f3',
  templateUrl: './nded-f3.component.html',
  styleUrls: ['./nded-f3.component.css']
})
export class NdedF3Component {
  NDEDf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf3 = this.formBuilder.group({
      irNo:[''],
      nomen:[''],
      drawNo:[''],
      project:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      inspected:[''],
      quantity:[''],
      opNo:[''],
      compNo:[''],
      date:[''],
      material:[''],
      areaOfExam:[''],
      purposeOfExam:[''],
      equipUsed:[''],
      freq:[''],
      probeType:[''],
      equipCalib:[''],
      sensitivity:[''],
      scanDetails:[''],
      accRejCri:[''],
      refStd:[''],
      obs:[''],
      quanEval:[''],
      accepted:[''],
      rework:[''],
      rejected:[''],
      signOfInsp:[''],
      signOfHead:[''],
      dateOfInsp:[''],
      dateOfHead:[''],
    });
  }
  SaveToDraft() {
    const formData = this.NDEDf3.value;
    const NDEDf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf3.value;
    const NDEDf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf3Data);

    console.log(payload);
  }
}
