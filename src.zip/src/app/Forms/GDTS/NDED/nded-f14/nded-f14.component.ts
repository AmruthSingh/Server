import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f14',
  templateUrl: './nded-f14.component.html',
  styleUrls: ['./nded-f14.component.css'],
})
export class NdedF14Component {
  NDEDf14: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf14 = this.formBuilder.group({
      irNo: [''],
      nomen: [''],
      drawNo: [''],
      project: [''],
      jobNo: [''],
      itemNo: [''],
      lotNo: [''],
      inspBy: [''],
      qty: [''],
      opNo: [''],
      compNo: [''],
      date: [''],
      ctRecNo: [''],
      equip: [''],
      refStd: [''],
      mat: [''],
      diameter: [''],
      length: [''],
      kV: [''],
      mA: [''],
      intTime: [''],
      sdd: [''],
      filtersUsed: [''],
      focusSize: [''],
      noOfSlices: [''],
      sliceThickness: [''],
      imgSize: [''],
      resolution: [''],
      observations: [''],
      inspSketch: [''],
      qt: [''],
      acce: [''],
      forRewo: [''],
      Rejec: [''],
      signOfInsp: [''],
      signOfHead: [''],
      dateOfInsp: [''],
      dateOfHead: [''],
      irNoCT: [''],
      qtEval: [''],
      accept: [''],
      forRework: [''],
      Reject: [''],
      signOfInspect: [''],
      signOfHeadNDED: [''],
      dateOfInspect: [''],
      dateOfHeadNDED: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf14.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      compoNo: [''],
      zoneNo: [''],
      obs: [''],
      remarks: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf14.value;
    const NDEDf14Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf14Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf14.value;
    const NDEDf14Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf14Data);

    console.log(payload);
  }
}
