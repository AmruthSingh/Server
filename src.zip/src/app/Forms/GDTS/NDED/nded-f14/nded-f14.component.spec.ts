import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF14Component } from './nded-f14.component';

describe('NdedF14Component', () => {
  let component: NdedF14Component;
  let fixture: ComponentFixture<NdedF14Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF14Component]
    });
    fixture = TestBed.createComponent(NdedF14Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
