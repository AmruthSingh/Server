import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF12Component } from './nded-f12.component';

describe('NdedF12Component', () => {
  let component: NdedF12Component;
  let fixture: ComponentFixture<NdedF12Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF12Component]
    });
    fixture = TestBed.createComponent(NdedF12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
