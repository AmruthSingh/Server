import { Component } from '@angular/core';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-nded-f7',
  templateUrl: './nded-f7.component.html',
  styleUrls: ['./nded-f7.component.css']
})
export class NdedF7Component {
  NDEDf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf7 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.NDEDf7.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      ctRecordNo:[''],
      jobNo:[''],
      itemNo:[''],
      lotNo:[''],
      opNo:[''],
      project:[''],
      jobNomen:[''],
      complNo:[''],
      receivedDate:[''],
      deliveredDate:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rowss(): FormArray {
    return this.NDEDf7.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      evalQuan:[''],
    accQuan:[''],
    rewQuan:[''],
    rejQuan:[''],
    refStd:[''],
    irNo:[''],
    irDate:[''],
    cuurent:[''],
    energy:[''],
    time:[''],
    inspBy:[''],
    toShop:[''],
    remarks:[''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf7.value;
    const NDEDf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf7.value;
    const NDEDf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf7Data);

    console.log(payload);
  }
}
