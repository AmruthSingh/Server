import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF7Component } from './nded-f7.component';

describe('NdedF7Component', () => {
  let component: NdedF7Component;
  let fixture: ComponentFixture<NdedF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF7Component]
    });
    fixture = TestBed.createComponent(NdedF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
