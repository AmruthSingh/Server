import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NdedF13Component } from './nded-f13.component';

describe('NdedF13Component', () => {
  let component: NdedF13Component;
  let fixture: ComponentFixture<NdedF13Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NdedF13Component]
    });
    fixture = TestBed.createComponent(NdedF13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
