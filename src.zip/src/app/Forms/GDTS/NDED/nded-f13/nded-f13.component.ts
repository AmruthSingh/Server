import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-nded-f13',
  templateUrl: './nded-f13.component.html',
  styleUrls: ['./nded-f13.component.css']
})
export class NdedF13Component {


  NDEDf13: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.NDEDf13 = this.formBuilder.group({
    irNo:[''],
     nomen:[''],
     drawNo:[''],
     project:[''],
     jobNo:[''],
     itemNo:[''],
     lotNo:[''],
     inspBy:[''],
     qty:[''],
     opNo:[''],
     compNo:[''],
     date:[''],
     mat:[''],
     surfCond:[''],
     equip:[''],
     Probe :[''],
     angleOfView :[''],
     areaOfExam:[''],
     purposeOfExam:[''],
     equipUseed:[''],
     probe:[''],
     couplantUsed:[''],
     euipCalib:[''],
     sens:[''],
     scanDetails:[''],
     accRejCri:[''],
     refStd:[''],
     observations:[''],
     inspSketch:[''],
     qt: [''],
      acce: [''],
      forRewo: [''],
      Rejec: [''],
      signOfInsp: [''],
      signOfHead: [''],
      dateOfInsp: [''],
      dateOfHead: [''],
      irNoVT: [''],
      qtEval: [''],
      accept: [''],
      forRework: [''],
      Reject: [''],
      signOfInspect: [''],
      signOfHeadNDED: [''],
      dateOfInspect: [''],
      dateOfHeadNDED: [''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.NDEDf13.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
     slNo:[''],
     compoNo:[''],
     zoneNo:[''],
     obs:[''],
     remarks:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.NDEDf13.value;
    const NDEDf13Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(NDEDf13Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.NDEDf13.value;
    const NDEDf13Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(NDEDf13Data);

    console.log(payload);
  }
}
