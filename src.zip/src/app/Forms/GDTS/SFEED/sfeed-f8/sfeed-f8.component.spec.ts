import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF8Component } from './sfeed-f8.component';

describe('SfeedF8Component', () => {
  let component: SfeedF8Component;
  let fixture: ComponentFixture<SfeedF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF8Component]
    });
    fixture = TestBed.createComponent(SfeedF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
