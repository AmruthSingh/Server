import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF6Component } from './sfeed-f6.component';

describe('SfeedF6Component', () => {
  let component: SfeedF6Component;
  let fixture: ComponentFixture<SfeedF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF6Component]
    });
    fixture = TestBed.createComponent(SfeedF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
