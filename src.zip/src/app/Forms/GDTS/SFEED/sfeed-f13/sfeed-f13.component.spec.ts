import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF13Component } from './sfeed-f13.component';

describe('SfeedF13Component', () => {
  let component: SfeedF13Component;
  let fixture: ComponentFixture<SfeedF13Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF13Component]
    });
    fixture = TestBed.createComponent(SfeedF13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
