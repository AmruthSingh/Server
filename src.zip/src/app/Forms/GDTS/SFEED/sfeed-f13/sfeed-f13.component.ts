import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f13',
  templateUrl: './sfeed-f13.component.html',
  styleUrls: ['./sfeed-f13.component.css'],
})
export class SfeedF13Component {
  SFEEDf13: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf13 = this.formBuilder.group({
      divSymbol:[''],
      limitBoard:[''],
      outsideMaga:[''],
      insideMaga:[''],
      remarksAny: [''],
      doneOn: [''],
      dueOn: [''],
      discharger:[''],
      physicalStatusacduct: [''],
      magazineNo: [''],
      magazineCapacity: [''],
      mainDoor:[''],
      timeOpening: [''],
      tempinMagazine: [''],
      rhMagazine: [''],
      instructionDisplay:[''],
      instructionVisible: [''],
      medicalAid: [''],
      remarks: [''],
      openPerReq: [''],
      capBin: [''],
      a14: [''],
      b14: [''],
      c14: [''],
      d14: [''],
      total1: [''],
      total2: [''],
      ai15: [''],
      bi15: [''],
      ci15: [''],
      di15: [''],
      aii15: [''],
      bii15: [''],
      cii15: [''],
      dii15: [''],
      a16: [''],
      b16: [''],
      c16: [''],
      d16: [''],
      remarks16: [''],
      dunnage: [''],
      typePropellant: [''],
      explToRemoved: [''],
      qtyPropellant: [''],
      explRemoved: [''],
      endUse: [''],
      endUsePropellant: [''],
      statuspackMag: [''],
      comGroup: [''],
      timeClosing: [''],
      reMARKS: [''],
      signSFeed: [''],
      signIncharge: [''],
      nameSFeed: [''],
      nameOfIncharge: [''],
      desigSFeed: [''],
      desigOfIncharge: [''],
      dateSFeed: [''],
      dateOfIncharge: [''],
      rows: this.formBuilder.array([this.createRow()]),
      rows1: this.formBuilder.array([this.createRow1()]),
      rows2: this.formBuilder.array([this.createRow2()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf13.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      epsSlNo: [''],
      epsearthpitno: [''],
      epslastDate: [''],
      epsResistance: [''],
      espRemarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  get rows1(): FormArray {
    return this.SFEEDf13.get('rows1') as FormArray;
  }

  createRow1(): FormGroup {
    return this.formBuilder.group({
      lpsSlNo: [''],
      lpspsearthpitno: [''],
      lpspslastDate: [''],
      lpspsResistance: [''],
      lpsremarks: [''],
    });
  }

  addRow1(): void {
    this.rows1.push(this.createRow1());
  }

  deleteRow1(index: number): void {
    this.rows1.removeAt(index);
  }

  get rows2(): FormArray {
    return this.SFEEDf13.get('rows2') as FormArray;
  }

  createRow2(): FormGroup {
    return this.formBuilder.group({
      sLNo18: [''],
      name18: [''],
      designatION: [''],
      persNo: [''],
      reMARks: [''],
    });
  }

  addRow2(): void {
    this.rows2.push(this.createRow2());
  }

  deleteRow2(index: number): void {
    this.rows2.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SFEEDf13.value;
    const SFEEDf13Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf13Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf13.value;
    const SFEEDf13Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf13Data);

    console.log(payload);
  }
}
