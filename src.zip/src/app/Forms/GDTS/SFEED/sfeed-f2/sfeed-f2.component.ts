import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f2',
  templateUrl: './sfeed-f2.component.html',
  styleUrls: ['./sfeed-f2.component.css'],
})
export class SfeedF2Component {
  SFEEDf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf2 = this.formBuilder.group({
      letterRefNo: [''],
      testBed: [''],
      group: [''],
      div:[''],
      sec:[''],
      descWork: [''],
      clearance:[''],
      nameIc: [''],
      schedule:[''],
      remarks: [''],
      testBeds:[''],
      eps:[''],
      lps:[''],
      bushes:[''],
      areaClean:[''],
      test:[''],
      fireEXting:[''],
      calibFire:[''],
      fireFight:[''],
      accessibility:[''],
      responsible: [''],
      availability:[''],
      fireTender:[''],
      ambulance:[''],
      guards:[''],
      noPersonsavailable: [''],
      discharge:[''],
      dataSheets:[''],
      oxidizer:[''],
      protectiveEqu:[''],
      protective:[''],
      safetyBoard:[''],
      testProcedure:[''],
      nameTc: [''],
      desigTc: [''],
      signTc: [''],
      place: [''],
      date: [''],
      observation: [''],
      nameR: [''],
      desigR: [''],
      signR: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf2.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      nAMe: [''],
      designation: [''],
      dte: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SFEEDf2.value;
    const SFEEDf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf2.value;
    const SFEEDf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf2Data);

    console.log(payload);
  }
}
