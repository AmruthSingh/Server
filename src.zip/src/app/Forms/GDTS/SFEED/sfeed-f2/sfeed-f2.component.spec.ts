import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF2Component } from './sfeed-f2.component';

describe('SfeedF2Component', () => {
  let component: SfeedF2Component;
  let fixture: ComponentFixture<SfeedF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF2Component]
    });
    fixture = TestBed.createComponent(SfeedF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
