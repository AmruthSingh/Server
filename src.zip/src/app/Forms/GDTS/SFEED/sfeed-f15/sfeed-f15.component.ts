import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f15',
  templateUrl: './sfeed-f15.component.html',
  styleUrls: ['./sfeed-f15.component.css'],
})
export class SfeedF15Component {
  SFEEDf15: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf15 = this.formBuilder.group({
      date: [''],
      time: [''],
      typeOfPotentialEmer: [''],
      fireAlarm: [''],
      fireExting: [''],
      assemblyPoint: [''],
      emergencyExit: [''],
      chiefEmer: [''],
      dyChiefEmer:[''],
      onsiteCo: [''],
      sheCo: [''],
      fireCo: [''],
      securityCo: [''],
      internalAffectedDiv: [''],
      internalAffectedSec: [''],
      divHead: [''],
      projDir: [''],
      externalAffectedDiv: [''],
      externalAffectedSec: [''],
      informedFireDiv: [''],
      miRoom: [''],
      sfeedHead: [''],
      secOfficer: [''],
      personnelPoint: [''],
      scientOff: [''],
      staffs: [''],
      casuals: [''],
      visitors: [''],
      signOfOfficer: [''],
      signOfIncharge: [''],
      nameOfOfficer: [''],
      nameOfIncharge: [''],
      desigOfOfficer: [''],
      desigOfIncharge: [''],
      dateOfOfficer: [''],
      dateOfIncharge: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf15.value;
    const SFEEDf15Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf15Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf15.value;
    const SFEEDf15Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf15Data);

    console.log(payload);
  }
}
