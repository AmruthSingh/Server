import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF15Component } from './sfeed-f15.component';

describe('SfeedF15Component', () => {
  let component: SfeedF15Component;
  let fixture: ComponentFixture<SfeedF15Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF15Component]
    });
    fixture = TestBed.createComponent(SfeedF15Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
