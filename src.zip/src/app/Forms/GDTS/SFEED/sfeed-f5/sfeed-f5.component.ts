import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f5',
  templateUrl: './sfeed-f5.component.html',
  styleUrls: ['./sfeed-f5.component.css']
})
export class SfeedF5Component {
  SFEEDf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf5 = this.formBuilder.group({
      letterRefNo:[''],
 date:[''],
 buildingNo:[''],
 dateTimeFrom:[''],
 dateTimeTo:[''],
 cleanliness:[''],
 limitBoard:[''],
 firetender:[''],
 medicalfirst:[''],
 firstaid:[''],
 orientation:[''],
 area:[''],
 flame:[''],
 remarks:[''],
 activities:[''],
 activitiesChart:[''],
 resistance:[''],
 permissible:[''],
 sparking:[''],
 grounding:[''],
 personanelStatic:[''],
 antiStatic:[''],
 ambulance:[''],
 personnelWorking:[''],
 remark:[''],
 forklift:[''],
 connectivity:[''],
 nameOfDriver:[''],
 desigDriver:[''],
 forkliftOper:[''],
 generalObs:[''],
 signOfRep:[''],
 signOfIncharge:[''],
 nameOfRep:[''],
 nameOfIncharge:[''],
 desigOfRep:[''],
 desigOfIncharge:[''],
 dateOfRep:[''],
 dateOfIncharge:[''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf5.value;
    const SFEEDf5Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf5.value;
    const SFEEDf5Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf5Data);

    console.log(payload);
  }
}
