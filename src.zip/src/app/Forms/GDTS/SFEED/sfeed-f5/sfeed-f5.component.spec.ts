import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF5Component } from './sfeed-f5.component';

describe('SfeedF5Component', () => {
  let component: SfeedF5Component;
  let fixture: ComponentFixture<SfeedF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF5Component]
    });
    fixture = TestBed.createComponent(SfeedF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
