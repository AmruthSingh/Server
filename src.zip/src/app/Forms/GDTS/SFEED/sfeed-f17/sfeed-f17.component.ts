import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f17',
  templateUrl: './sfeed-f17.component.html',
  styleUrls: ['./sfeed-f17.component.css'],
})
export class SfeedF17Component {
  SFEEDf17: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf17 = this.formBuilder.group({
      natureA: [''],
      firecrewreachedA: [''],
      classificationA: [''],
      fireTenderA: [''],
      crewNameA: [''],
      designationA: [''],
      returnTimeA: [''],
      remarksA: [''],
      natureB: [''],
      firecrewreachedB: [''],
      classificationB: [''],
      fireTenderB: [''],
      crewNameB: [''],
      designationB: [''],
      returnTimeB: [''],
      remarksB: [''],
      natureC: [''],
      firecrewreachedC: [''],
      classificationC: [''],
      fireTenderC: [''],
      crewNameC: [''],
      designationC: [''],
      returnTimeC: [''],
      remarksC: [''],
      natureD: [''],
      firecrewreachedD: [''],
      classificationD: [''],
      fireTenderD: [''],
      crewNameD: [''],
      designationD: [''],
      returnTimeD: [''],
      remarksD: [''],
      natureE: [''],
      firecrewreachedE: [''],
      classificationE: [''],
      fireTenderE: [''],
      crewNameE: [''],
      designationE: [''],
      returnTimeE: [''],
      remarksE: [''],
      shiftSign: [''],
      headSign: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf17.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      date: [''],
      requisitionLetterNo: [''],
      requisitiondate: [''],
      nameOfDivision: [''],
      telNo: [''],
      nameOfDemandingOfficer: [''],
      fileTender: [''],
      location: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SFEEDf17.value;
    const SFEEDf17Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf17Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf17.value;
    const SFEEDf17Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf17Data);

    console.log(payload);
  }
}
