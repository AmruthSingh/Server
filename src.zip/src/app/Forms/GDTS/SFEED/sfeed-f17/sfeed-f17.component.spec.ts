import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF17Component } from './sfeed-f17.component';

describe('SfeedF17Component', () => {
  let component: SfeedF17Component;
  let fixture: ComponentFixture<SfeedF17Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF17Component]
    });
    fixture = TestBed.createComponent(SfeedF17Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
