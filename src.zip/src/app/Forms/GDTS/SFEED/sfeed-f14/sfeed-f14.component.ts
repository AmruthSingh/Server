import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f14',
  templateUrl: './sfeed-f14.component.html',
  styleUrls: ['./sfeed-f14.component.css']
})
export class SfeedF14Component {
  SFEEDf14: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf14= this.formBuilder.group({
      directorate:[''],
      division:[''],
      section:[''],
      nameAddrOfInjured:[''],
      sex:[''],
      age:[''],
      occupation:[''],
      wages:[''],
      dateTimeOfAcci:[''],
      timeStart:[''],
      cause:[''],
      ifCauseByMachinery:[''],
      nameOfMachine:[''],
      mechanicalPower:[''],
      injuredWasDoing:[''],
      natureOfInjury:[''],
      injureWasDisabled:[''],
      nameOfMedicalOff:[''],
      signOfSupOff:[''],
      nameOfInjured:[''],
      desigOfInjured:[''],
      desigNo:[''],
      desigIdNo:[''],
      dateOfAcc:[''],
      timeOfAcc:[''],
      partOfBodyInjured:[''],
      div:[''],
      sec:[''],
      locOfAcci:[''],
      persPropInjury:[''],
      ltaDangerous:[''],
      acciDetails:[''],
      unsafeAct:[''],
      unsafeCondition:[''],
      causeOfAcci:[''],
      actionsToPrevent:[''],
      nameOfWitness:[''],
      desigOfWitness:[''],
      date:[''],
      signOfWitness:[''],
      nameOfInvestOne:[''],
      desigOfInvestOne:[''],
      signOfInvestOne:[''],
      nameOfInvestTwo:[''],
      desigOfInvestTwo:[''],
      signOfInvestTwo:[''],
      superiorSign:[''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf14.value;
    const SFEEDf14Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf14Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf14.value;
    const SFEEDf14Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf14Data);

    console.log(payload);
  }
}
