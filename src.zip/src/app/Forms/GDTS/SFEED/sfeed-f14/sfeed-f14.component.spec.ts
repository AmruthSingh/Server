import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF14Component } from './sfeed-f14.component';

describe('SfeedF14Component', () => {
  let component: SfeedF14Component;
  let fixture: ComponentFixture<SfeedF14Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF14Component]
    });
    fixture = TestBed.createComponent(SfeedF14Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
