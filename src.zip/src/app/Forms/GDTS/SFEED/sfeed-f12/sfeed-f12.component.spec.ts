import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF12Component } from './sfeed-f12.component';

describe('SfeedF12Component', () => {
  let component: SfeedF12Component;
  let fixture: ComponentFixture<SfeedF12Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF12Component]
    });
    fixture = TestBed.createComponent(SfeedF12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
