import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f12',
  templateUrl: './sfeed-f12.component.html',
  styleUrls: ['./sfeed-f12.component.css']
})
export class SfeedF12Component {
  SFEEDf12: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf12 = this.formBuilder.group({
      div: [''],
      inspectingOfficer: [''],
      workCenter: [''],
      dateOne: [''],
      policy: [''],
      manual: [''],
      safeOper: [''],
      fencing: [''],
      valve: [''],
      pressureGauge: [''],
      stopValve: [''],
      vessels: [''],
      grindingWheel: [''],
      drilling: [''],
      oxyAcetylene: [''],
      casting: [''],
      furnaces: [''],
      isStandard: [''],
      buckets: [''],
      dateInsp: [''],
      dateref: [''],
      floorLevel: [''],
      fireFight: [''],
      protection: [''],
      precaution: [''],
      aidKit : [''],
      aiderIdentified : [''],
      shock: [''],
      cylinders: [''],
      heatSources: [''],
      coding: [''],
      maintained : [''],
      certAvailable: [''],
      plugs : [''],
      earth: [''],
      holdCards: [''],
      leads : [''],
      transformers: [''],
      tested: [''],
      easily: [''],
      fullyCharged: [''],
      extinguishers: [''],
      electrical: [''],
      properly: [''],
      insulated: [''],
      junction: [''],
      extension: [''],
      wiring: [''],
      escape: [''],
      employees: [''],
      egress: [''],
      exitsMark: [''],
      adequateSafe: [''],
      vdScreen: [''],
      emergencyLighting : [''],
      orderly: [''],
      holes: [''],
      obstructions: [''],
      passageWays: [''],
      pits: [''],
      railingOpen: [''],
      temporary: [''],
      surveysCond: [''],
      hearing : [''],
      sanitaryClean: [''],
      repair: [''],
      toxic: [''],
      reqEquip: [''],
      meetReq: [''],
      personalPro: [''],
      aislesDoors: [''],
      stable: [''],
      hazards: [''],
      forklifts: [''],
      designated: [''],
      chemical: [''],
      compat: [''],
      secondaryCon: [''],
      trapped: [''],
      ignitionSour: [''],
      freezer: [''],
      ppeAvail: [''],
      safetyCans: [''],
      gal: [''],
      amounts: [''],
      unusable: [''],
      inventoryDate: [''],
      container: [''],
      segregated: [''],
      materialSafety: [''],
      eyeWash: [''],
      unObs: [''],
      stocked: [''],
      informationPosted: [''],
      wasteStore: [''],
      wasteCon: [''],
      comp: [''],
      chemiclWaste: [''],
      addingWaste: [''],
      wasteContainer: [''],
      recycled: [''],
      accident: [''],
      trained: [''],
      signatureOfSafetyOfficer: [''],
      nameOne: [''],
      designationOne: [''],
      dateTwo: [''],
      signatureOfSafCoordinator: [''],
      nameTwo: [''],
      designationTwo: [''],
      dateThree:[''],
    });
  }
  // submitForm() {
  //   const formData = this.SFEEDf12.value;
  //   this.http
  //     .post('http://localhost:3000/api/SFEEDf12table', formData)
  //     .subscribe(
  //       (response) => {
  //         console.log('Data saved successfully', response);
  //       },
  //       (error) => {
  //         console.error('Error saving data:', error);
  //       }
  //     );
  // }
  SaveToDraft() {
    const formData = this.SFEEDf12.value;
    const SFEEDf12Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf12Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf12.value;
    const SFEEDf12Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf12Data);

    console.log(payload);
  }
}
