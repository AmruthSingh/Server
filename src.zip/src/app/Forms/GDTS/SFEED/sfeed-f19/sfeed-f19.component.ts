import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f19',
  templateUrl: './sfeed-f19.component.html',
  styleUrls: ['./sfeed-f19.component.css'],
})
export class SfeedF19Component {
  SFEEDf19: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf19 = this.formBuilder.group({
      letterNo: [''],
      date: [''],
      staticTest: [''],
      directorate: [''],
      division: [''],
      nomen: [''],
      testBedDetails: [''],
      preTest:[''],
      postTest:[''],
      testControlName: [''],
      dateTimeOfTest: [''],
      actChart: [''],
      anyOtherDetails: [''],
      signature: [''],
      nameDesig: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf19.value;
    const SFEEDf19Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf19Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf19.value;
    const SFEEDf19Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf19Data);

    console.log(payload);
  }
}
