import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF19Component } from './sfeed-f19.component';

describe('SfeedF19Component', () => {
  let component: SfeedF19Component;
  let fixture: ComponentFixture<SfeedF19Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF19Component]
    });
    fixture = TestBed.createComponent(SfeedF19Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
