import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';

@Component({
  selector: 'app-sfeed-f11',
  templateUrl: './sfeed-f11.component.html',
  styleUrls: ['./sfeed-f11.component.css'],
})
export class SfeedF11Component {
  SFEEDf11: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf11 = this.formBuilder.group({
      safetyComMeetInfo: [''],
      letterNo: [''],
      date: [''],
      locationOfMeeting: [''],
      groupDiv: [''],
      lastSafetyComRefNo: [''],
      lastDate:[''],
      meetingDate: [''],
      meetingStartTime: [''],
      meetingEndTime: [''],
      nextMeetDate: [''],
      signOfHead: [''],
      signOfChairman: [''],
      nameOfHead: [''],
      nameOfChairman: [''],
      desigOfHead: [''],
      desigOfChairman: [''],
      dateOfHead: [''],
      dateOfChairman: [''],
      signOfHeads: [''],
      signOfChairmans: [''],
      nameOfHeads: [''],
      nameOfChairmans: [''],
      desigOfHeads: [''],
      desigOfChairmans: [''],
      dateOfHeads: [''],
      dateOfChairmans: [''],
      dirName: [''],
      safetyComMeetOn: [''],
      directName: [''],
      letterNos: [''],
      dates: [''],
      meetHeldOn: [''],
      name1: [''],
      desig1: [''],
      name2: [''],
      desig2: [''],
      name3: [''],
      desig3: [''],
      name4: [''],
      desig4: [''],
      signOfCha: [''],
      nameOfCha: [''],
      desigOfCha:[''],
      dateOfCha:[''],
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf11.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      name: [''],
      desig: [''],
      sign: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  get rowss(): FormArray {
    return this.SFEEDf11.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      sNo: [''],
      pointsOfDiscussion: [''],
      action: [''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  // submitForm() {
  //   const formData = this.SFEEDf11.value;
  //   const tableRows = formData.rows;
  //   delete formData.rows;
  //   const tableRowss = formData.rowss;
  //   delete formData.rowss;

  //   const SFEEDf11Data = {
  //     otherFields: formData,
  //     tableRows,
  //     tableRowss,
  //   };
  //   const payload = JSON.stringify(SFEEDf11Data);

  // console.log(payload);
  // const headers = new HttpHeaders({
  //   'Content-Type': 'application/json'
  // });

  // // Post the payload to localhost:3000
  // this.http.post('http://localhost:3000/api/f12', payload, { headers })
  //   .subscribe(
  //     (response) => {
  //       console.log('Post successful:', response);
  //       // Handle the response if needed
  //     },
  //     (error) => {
  //       console.error('Post failed:', error);
  //       // Handle the error if needed
  //     }
  //   );
  // }
  SaveToDraft() {
    const formData = this.SFEEDf11.value;
    const SFEEDf11Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf11Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf11.value;
    const SFEEDf11Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf11Data);

    console.log(payload);
  }
}
