import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF11Component } from './sfeed-f11.component';

describe('SfeedF11Component', () => {
  let component: SfeedF11Component;
  let fixture: ComponentFixture<SfeedF11Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF11Component]
    });
    fixture = TestBed.createComponent(SfeedF11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
