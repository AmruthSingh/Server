import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f18',
  templateUrl: './sfeed-f18.component.html',
  styleUrls: ['./sfeed-f18.component.css'],
})
export class SfeedF18Component {
  SFEEDf18: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf18 = this.formBuilder.group({
      shiftSign: [''],
      headSign: [''],
      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf18.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      date: [''],
      timeOffire: [''],
      firecallby: [''],
      designation: [''],
      division: [''],
      phNo: [''],
      locationOfFire: [''],
      nameOfFire: [''],
      design: [''],
      fireCrew: [''],
      crewReached: [''],
      classification: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  get rowss(): FormArray {
    return this.SFEEDf18.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      actionOfFire: [''],
      assistantRenderedBy: [''],
      assistantRequisitionedBy: [''],
      Design: [''],
      arrivalTime: [''],
      fireCrewdetails: [''],
      firecrewDesign: [''],
      timeOfReturn: [''],
      causeOfFire: [''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.SFEEDf18.value;
    const SFEEDf18Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf18Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf18.value;
    const SFEEDf18Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf18Data);

    console.log(payload);
  }
}
