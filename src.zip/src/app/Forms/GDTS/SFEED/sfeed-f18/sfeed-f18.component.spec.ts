import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF18Component } from './sfeed-f18.component';

describe('SfeedF18Component', () => {
  let component: SfeedF18Component;
  let fixture: ComponentFixture<SfeedF18Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF18Component]
    });
    fixture = TestBed.createComponent(SfeedF18Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
