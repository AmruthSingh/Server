import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF16Component } from './sfeed-f16.component';

describe('SfeedF16Component', () => {
  let component: SfeedF16Component;
  let fixture: ComponentFixture<SfeedF16Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF16Component]
    });
    fixture = TestBed.createComponent(SfeedF16Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
