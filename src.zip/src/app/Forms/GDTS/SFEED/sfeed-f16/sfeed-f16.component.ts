import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f16',
  templateUrl: './sfeed-f16.component.html',
  styleUrls: ['./sfeed-f16.component.css']
})
export class SfeedF16Component {
  SFEEDf16: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf16 = this.formBuilder.group({
      letterNo:[''],
      date:[''],
      trainingType:[''],
      duration:[''],
      locOfTraining:[''],
      groupDiv:[''],
      lstSftyTrainRefLetNo:[''],
      lstSftyDate:[''],
      trainDate:[''],
      trainStartTime:[''],
      trainEndTime:[''],
      nextTrainDate:[''],
      signOfHead:[''],
      signOfChairman:[''],
      nameOfHead:[''],
      nameOfChairman:[''],
      desigOfHead:[''],
      desigOfChairman:[''],
      dateOfHead:[''],
      dateOfChairman:[''],
      directoratename:[''],
      trainingOn:[''],
      headsign:[''],
      chairmansign:[''],
      headName:[''],
      chairmanname:[''],
      headDesignation:[''],
      chairmandesignation:[''],
      headDate:[''],
      chairmanDate:[''],
      directorate:[''],
      letterNo1:[''],
      date1:[''],
      typeOfSftyTran:[''],
      duration1:[''],
      location:[''],
      signhead:[''],
      signchairman:[''],
      Namehead:[''],
      namechairman:[''],
      Designationhead:[''],
      designationchairman:[''],
      Datehead:[''],
      Datechairman:[''],

      rows: this.formBuilder.array([this.createRow()]),
      rowss: this.formBuilder.array([this.createRows()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf16.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      serialNo:[''],
      attendantname:[''],
      attendantdesignation:[''],
      attendantsignature:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  get rowss(): FormArray {
    return this.SFEEDf16.get('rowss') as FormArray;
  }

  createRows(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      name:[''],
      designation:[''],
      internalPhNo:[''],
      effectiveness:[''],
      remarks:[''],
    });
  }

  addRows(): void {
    this.rowss.push(this.createRows());
  }

  deleteRows(index: number): void {
    this.rowss.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.SFEEDf16.value;
    const SFEEDf16Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf16Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf16.value;
    const SFEEDf16Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf16Data);

    console.log(payload);
  }
}
