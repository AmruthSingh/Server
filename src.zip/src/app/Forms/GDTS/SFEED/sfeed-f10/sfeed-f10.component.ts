import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';

@Component({
  selector: 'app-sfeed-f10',
  templateUrl: './sfeed-f10.component.html',
  styleUrls: ['./sfeed-f10.component.css']
})
export class SfeedF10Component {
  SFEEDf10: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf10 = this.formBuilder.group({
      letterRefNo: [''],
      date: [''],
      buildingNo: [''],
      dateTime: [''],
      time: [''],
      dateTime2: [''],
      time2: [''],
      workCenter: [''],
      fire: [''],
      medicine: [''],
      exitinguishers: [''],
      tender: [''],
      barricading: [''],
      flame: [''],
      chart: [''],
      performed: [''],
      remarks: [''],
      eps: [''],
      lpS: [''],
      sparking: [''],
      articles: [''],
      discharge: [''],
      ambulance: [''],
      using: [''],
      remarks2: [''],
      must : [''],
      article : [''],
      generalObs: [''],
      sign: [''],
      nameSign: [''],
      desig: [''],
      dateDes : [''],
      sign2: [''],
      nameSign2 : [''],
      desig2: [''],
      dateDes2: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf10.value;
    const SFEEDf10Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf10Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf10.value;
    const SFEEDf10Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf10Data);

    console.log(payload);
  }
}
