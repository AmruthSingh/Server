import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF10Component } from './sfeed-f10.component';

describe('SfeedF10Component', () => {
  let component: SfeedF10Component;
  let fixture: ComponentFixture<SfeedF10Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF10Component]
    });
    fixture = TestBed.createComponent(SfeedF10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
