import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF4Component } from './sfeed-f4.component';

describe('SfeedF4Component', () => {
  let component: SfeedF4Component;
  let fixture: ComponentFixture<SfeedF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF4Component]
    });
    fixture = TestBed.createComponent(SfeedF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
