import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f4',
  templateUrl: './sfeed-f4.component.html',
  styleUrls: ['./sfeed-f4.component.css'],
})
export class SfeedF4Component {
  SFEEDf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf4 = this.formBuilder.group({
      descWork: [''],
      letterRefNo: [''],
      group: [''],
      buildingNo: [''],
      clearance:[''],
      dateInspection:[''],
      oicOfOperation: [''],
      activity: [''],
      mediumToTest: [''],
      pressurization: [''],
      ratePressurization: [''],
      pressure: [''],
      avgTestPressure: [''],
      cleanliness: [''],
      ventilation: [''],
      illumination: [''],
      exit: [''],
      flooring: [''],
      fireFight: [''],
      firstAid: [''],
      usageOfPPE: [''],
      tools: [''],
      noExplosives: [''],
      positioning: [''],
      cordoning: [''],
      eps:[''],
      lps:[''],
      discharge:[''],
      gauges:[''],
      lastDateCalib: [''],
      validationCalibCert: [''],
      hoses:[''],
      lastDateTest: [''],
      validationCert: [''],
      orientation: [''],
      rocket: [''],
      workTable: [''],
      conductiveMat: [''],
      testingArticles:[''],
      place: [''],
      date: [''],
      observation: [''],
      signRep: [''],
      nameRep: [''],
      desigRep: [''],
      signOffcIncharge: [''],
      nameOffcIncharge: [''],
      desigOffcIncharge: [''],
      reason: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf4.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      nameOfficer: [''],
      designatION: [''],
      division: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SFEEDf4.value;
    const SFEEDf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf4.value;
    const SFEEDf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf4Data);

    console.log(payload);
  }
}
