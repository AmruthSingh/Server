import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f7',
  templateUrl: './sfeed-f7.component.html',
  styleUrls: ['./sfeed-f7.component.css']
})
export class SfeedF7Component {
  SFEEDf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf7 = this.formBuilder.group({
      letterRefNo: [''],
      instructionForm:[''],
      buildingNo: [''],
      group: [''],
      div:[''],
      sec:[''],
      interior:[''],
      skyLights: [''],
      skyGlazed: [''],
      lightSource: [''],
      angleElevat: [''],
      lightShade:[''],
      permissible:[''],
      place: [''],
      date: [''],
      signatureOfHead: [''],
      signOfSafCo: [''],
      nameOne: [''],
      nameTwo: [''],
      designationOne: [''],
      designationTwo: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.SFEEDf7.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      sampleNo: [''],
      location: [''],
      observedValue: [''],
      recommendedValue: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.SFEEDf7.value;
    const SFEEDf7Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf7.value;
    const SFEEDf7Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf7Data);

    console.log(payload);
  }
}
