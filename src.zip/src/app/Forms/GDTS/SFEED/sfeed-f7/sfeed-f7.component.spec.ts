import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF7Component } from './sfeed-f7.component';

describe('SfeedF7Component', () => {
  let component: SfeedF7Component;
  let fixture: ComponentFixture<SfeedF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF7Component]
    });
    fixture = TestBed.createComponent(SfeedF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
