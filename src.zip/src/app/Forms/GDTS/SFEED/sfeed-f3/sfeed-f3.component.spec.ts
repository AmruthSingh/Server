import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF3Component } from './sfeed-f3.component';

describe('SfeedF3Component', () => {
  let component: SfeedF3Component;
  let fixture: ComponentFixture<SfeedF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF3Component]
    });
    fixture = TestBed.createComponent(SfeedF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
