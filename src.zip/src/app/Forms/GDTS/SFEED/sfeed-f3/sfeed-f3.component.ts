import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f3',
  templateUrl: './sfeed-f3.component.html',
  styleUrls: ['./sfeed-f3.component.css'],
})
export class SfeedF3Component {
  SFEEDf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf3 = this.formBuilder.group({
      letterNo: [''],
      buildingNo: [''],
      groupDivision: [''],
      description: [''],
      name: [''],
      designation: [''],
      a: [''],
      b: [''],
      c: [''],
      d: [''],
      vehicleNo: [''],
      hazard: [''],
      driverName: [''],
      guardName: [''],
      prior: [''],
      authorized: [''],
      action: [''],
      ammunition: [''],
      extinguisher: [''],
      overCome: [''],
      escort: [''],
      noPetrol: [''],
      running: [''],
      battery: [''],
      noFuel: [''],
      noExplosives: [''],
      noDust: [''],
      speed: [''],
      front: [''],
      redFlags: [''],
      fuelTank: [''],
      articles: [''],
      oneDriver: [''],
      appendixD: [''],
      noSmoking: [''],
      noNaked: [''],
      noVehicle: [''],
      noIntoxicated: [''],
      journey: [''],
      loaded: [''],
      packages: [''],
      place: [''],
      date: [''],
      observation: [''],
      nameOfRep: [''],
      signOfRep: [''],
      nameOfIncharge: [''],
      signatureOfIncharge: [''],
      numberVehicle: [''],
      divisionName: [''],
      fireDivision: [''],
      natureOfRisk: [''],
      fireAction: [''],
      signature: [''],
      Place: [''],
      Name: [''],
      Date: [''],
      desig: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf3.value;
    const SFEEDf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf3.value;
    const SFEEDf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf3Data);

    console.log(payload);
  }
}
