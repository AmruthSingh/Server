import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF1Component } from './sfeed-f1.component';

describe('SfeedF1Component', () => {
  let component: SfeedF1Component;
  let fixture: ComponentFixture<SfeedF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF1Component]
    });
    fixture = TestBed.createComponent(SfeedF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
