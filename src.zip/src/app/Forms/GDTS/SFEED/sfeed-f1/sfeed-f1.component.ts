import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f1',
  templateUrl: './sfeed-f1.component.html',
  styleUrls: ['./sfeed-f1.component.css'],
})
export class SfeedF1Component {
  SFEEDf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf1 = this.formBuilder.group({
      letterRefNo: [''],
      dateInspection: [''],
      activity: [''],
      cleanliness: [''],
      antiFlooring: [''],
      noRocket: [''],
      nonTool: [''],
      fireEqu: [''],
      aidBox: [''],
      exitDoor: [''],
      antiStatic: [''],
      ventilation: [''],
      eps: [''],
      lps: [''],
      manpower: [''],
      inspection: [''],
      place: [''],
      date: [''],
      observation: [''],
      nAme: [''],
      sigNAture: [''],
      supName: [''],
      supSign: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf1.value;
    const SFEEDf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf1.value;
    const SFEEDf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf1Data);

    console.log(payload);
  }
}
