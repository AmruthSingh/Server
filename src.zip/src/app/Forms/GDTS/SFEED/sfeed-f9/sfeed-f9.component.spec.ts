import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfeedF9Component } from './sfeed-f9.component';

describe('SfeedF9Component', () => {
  let component: SfeedF9Component;
  let fixture: ComponentFixture<SfeedF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SfeedF9Component]
    });
    fixture = TestBed.createComponent(SfeedF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
