import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sfeed-f9',
  templateUrl: './sfeed-f9.component.html',
  styleUrls: ['./sfeed-f9.component.css']
})
export class SfeedF9Component {
  SFEEDf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.SFEEDf9 = this.formBuilder.group({
      letterNo: [''],
      buildingNo: [''],
      groupDivision: [''],
      description: [''],
      handling: [''],
      grain: [''],
      temporary: [''],
      placed: [''],
      exposed: [''],
      tools: [''],
      earthed: [''],
      involved: [''],
      allowed: [''],
      safetyNorms: [''],
      propellant: [''],
      place: [''],
      date: [''],
      observation: [''],
      nameOfRep: [''],
      signOfRep: [''],
      nameOfIncharge: [''],
      signatureOfIncharge: [''],
      numberVehicle: [''],
      divisionName: [''],
      fireDivision: [''],
      natureOfRisk: [''],
      fireAction: [''],
      signature: [''],
      Place: [''],
      Name: [''],
      Date: [''],
      desig: [''],
    });
  }
  SaveToDraft() {
    const formData = this.SFEEDf9.value;
    const SFEEDf9Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(SFEEDf9Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.SFEEDf9.value;
    const SFEEDf9Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(SFEEDf9Data);

    console.log(payload);
  }
}
