import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF5Component } from './kc-f5.component';

describe('KcF5Component', () => {
  let component: KcF5Component;
  let fixture: ComponentFixture<KcF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF5Component]
    });
    fixture = TestBed.createComponent(KcF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
