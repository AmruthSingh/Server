import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f5',
  templateUrl: './kc-f5.component.html',
  styleUrls: ['./kc-f5.component.css'],
})
export class KcF5Component {
  KCf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf5 = this.formBuilder.group({
      rupees: [''],
      rupeesInWords: [''],
      nameOfVendor: [''],
      addressOfVendor:[''],
      totalRs: [''],
      totalRupeesInWords: [''],
      number: [''],
      dated: [''],
      sanctioned:[''],
      cfaSign: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.KCf5.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      titleOfInvoice: [''],
      dateOfInvoice: [''],
      nameOfSupplier: [''],
      contingentBillNo: [''],
      amount: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.KCf5.value;
    const KCf5Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(KCf5Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf5.value;
    const KCf5Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(KCf5Data);
    console.log(payload);
  }
}
