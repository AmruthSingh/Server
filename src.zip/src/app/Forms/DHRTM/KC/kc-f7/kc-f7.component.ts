import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f7',
  templateUrl: './kc-f7.component.html',
  styleUrls: ['./kc-f7.component.css']
})
export class KcF7Component {
  KCf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf7 = this.formBuilder.group({
      name:[''],
      rank:[''],
      datePostlab:[''],
      nameDivision:[''],
      dateRetirement:[''],
      serviceIc:[''],
      officeAddress:[''],
      phNo:[''],
      telex:[''],
      fax:[''],
      email:[''],
      loacalAddress:[''],
      permanentAddress:[''],
      appDate:[''],
      signApplicant:[''],
      divDate:[''],
      divSign:[''],
      divName:[''],
      fileNo:[''],
      signDate:[''],
      admofDate:[''],
      admoffName:[''],
      seal:[''],
      nameofPerson:[''],
      code:[''],
      signHeadkc:[''],

    });
  }
  // submitForm() {
  //   const formData = this.KCf7.value;
  //   this.http.post('http://localhost:3000/api/KCf7table', formData).subscribe(
  //     response => {
  //       console.log('Data saved successfully', response);
  //     },
  //     error => {
  //       console.error('Error saving data:', error);
  //     }
  //   );
  // }
  SaveToDraft(){
    const formData = this.KCf7.value;
    const KCf7Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(KCf7Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf7.value;
    const KCf7Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(KCf7Data);
    console.log(payload);
  }
}
