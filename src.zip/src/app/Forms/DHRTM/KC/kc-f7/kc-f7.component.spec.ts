import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF7Component } from './kc-f7.component';

describe('KcF7Component', () => {
  let component: KcF7Component;
  let fixture: ComponentFixture<KcF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF7Component]
    });
    fixture = TestBed.createComponent(KcF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
