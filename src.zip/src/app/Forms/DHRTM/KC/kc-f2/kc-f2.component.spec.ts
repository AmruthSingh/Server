import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF2Component } from './kc-f2.component';

describe('KcF2Component', () => {
  let component: KcF2Component;
  let fixture: ComponentFixture<KcF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF2Component]
    });
    fixture = TestBed.createComponent(KcF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
