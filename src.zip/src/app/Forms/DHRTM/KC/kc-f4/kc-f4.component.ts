import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f4',
  templateUrl: './kc-f4.component.html',
  styleUrls: ['./kc-f4.component.css'],
})
export class KcF4Component {
  KCf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf4 = this.formBuilder.group({
      voucherNo: [''],
      contingentBill: [''],
      year: [''],
      invoiceNo: [''],
      invoiceDate: [''],
      invoiceRs: [''],
      crvNo: [''],
      crvDate: [''],
      crvRs: [''],
      soNo: [''],
      soDate: [''],
      soRs: [''],
      nameOfComp: [''],
      totalRounded: [''],
      totalRs: [''],
      netAmount: [''],
      rupees: [''],
      signDate: [''],
      headKCSign: [''],
      payBills: [''],
      irla: [''],
      favourOF: [''],
      month: [''],
      dvNo: [''],
      for: [''],
      nextCharge: [''],
      passedFor: [''],
      rupeesPayment: [''],
      voucherNum: [''],
      auditor: [''],
      suptd: [''],
      ao: [''],
      months: [''],
      cda: [''],
      sec: [''],
      classVr: [''],
      vrNo: [''],
      rows: this.formBuilder.array([this.createRow()]),
      rows1: this.formBuilder.array([this.createRow1()]),
      rows2: this.formBuilder.array([this.createRow2()]),
    });
  }
  get rows(): FormArray {
    return this.KCf4.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      date: [''],
      detailsOfExp: [''],
      noOfQuantity: [''],
      rateRs: [''],
      ratePs: [''],
      for: [''],
      amountRs: [''],
      amountPs: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  get rows1(): FormArray {
    return this.KCf4.get('rows1') as FormArray;
  }

  createRow1(): FormGroup {
    return this.formBuilder.group({
      agCode: [''],
      treasury: [''],
      payee: [''],
      rsAcc: [''],
      psAcc: [''],
      dateofCheque: [''],
      supD: [''],
      initials: [''],
    });
  }
  addRow1(): void {
    this.rows1.push(this.createRow1());
  }

  deleteRow1(index: number): void {
    this.rows1.removeAt(index);
  }

  get rows2(): FormArray {
    return this.KCf4.get('rows2') as FormArray;
  }

  createRow2(): FormGroup {
    return this.formBuilder.group({
      classifiCode:[''],
      recpRs: [''],
      recpPs: [''],
      recRs: [''],
      recPs: [''],
      ChargeClassifCode:[''],
      cRs:[''],
      cPs:[''],
      chRs:[''],
      chPs:[''],
    });
  }

  addRow2(): void {
    this.rows2.push(this.createRow2());
  }

  deleteRow2(index: number): void {
    this.rows2.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.KCf4.value;
    const KCf4Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(KCf4Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf4.value;
    const KCf4Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(KCf4Data);
    console.log(payload);
  }
}
