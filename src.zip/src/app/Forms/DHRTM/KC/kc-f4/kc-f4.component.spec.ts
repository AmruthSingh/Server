import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF4Component } from './kc-f4.component';

describe('KcF4Component', () => {
  let component: KcF4Component;
  let fixture: ComponentFixture<KcF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF4Component]
    });
    fixture = TestBed.createComponent(KcF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
