import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f6',
  templateUrl: './kc-f6.component.html',
  styleUrls: ['./kc-f6.component.css']
})
export class KcF6Component {
  KCf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf6 = this.formBuilder.group({
      regdNo:[''],
      date:[''],
      name:[''],
      address:[''],
      laterDate:[''],
      headSign:[''],
      titlesOnly:[''],
      titlesOnlyPer:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.KCf6.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      title:[''],
      author:[''],
      publisher:[''],
      year:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }


  SaveToDraft(){
    const formData = this.KCf6.value;
    const KCf6Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(KCf6Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf6.value;
    const KCf6Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(KCf6Data);
    console.log(payload);
  }
}
