import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF9Component } from './kc-f9.component';

describe('KcF9Component', () => {
  let component: KcF9Component;
  let fixture: ComponentFixture<KcF9Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF9Component]
    });
    fixture = TestBed.createComponent(KcF9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
