import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f9',
  templateUrl: './kc-f9.component.html',
  styleUrls: ['./kc-f9.component.css']
})
export class KcF9Component {
  KCf9: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf9 = this.formBuilder.group({
      regdNo:[''],
      date:[''],
      name:[''],
      addressOfVendor:[''],
      year:[''],
      refNo:[''],
      refDate:[''],
      letterNo:[''],
      letterDate:[''],
      supplyNo:[''],
      accessYear:[''],
      address:[''],
      headSign:[''],
    });
  }

  SaveToDraft(){
    const formData = this.KCf9.value;
    const KCf9Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(KCf9Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf9.value;
    const KCf9Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(KCf9Data);
    console.log(payload);
  }
}
