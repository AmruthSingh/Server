import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-kc-f8',
  templateUrl: './kc-f8.component.html',
  styleUrls: ['./kc-f8.component.css'],
})
export class KcF8Component {
  KCf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.KCf8 = this.formBuilder.group({
      demandNo: [''],
      date: [''],
      year: [''],
      totalRs: [''],
      totalRounded: [''],
      rupees: [''],
      usd: [''],
      ukp: [''],
      euro: [''],
      aus: [''],
      can: [''],
      head: [''],
      recommended: [''],
      chairman: [''],
      approved: [''],
      cfa: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }
  get rows(): FormArray {
    return this.KCf8.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      title: [''],
      publisher: [''],
      subsModule: [''],
      rate: [''],
      approxPrice: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.KCf8.value;
    const KCf8Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(KCf8Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.KCf8.value;
    const KCf8Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(KCf8Data);
    console.log(payload);
  }
}
