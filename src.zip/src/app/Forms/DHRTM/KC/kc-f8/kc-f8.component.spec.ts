import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KcF8Component } from './kc-f8.component';

describe('KcF8Component', () => {
  let component: KcF8Component;
  let fixture: ComponentFixture<KcF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [KcF8Component]
    });
    fixture = TestBed.createComponent(KcF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
