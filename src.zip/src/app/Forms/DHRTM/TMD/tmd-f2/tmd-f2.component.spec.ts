import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmdF2Component } from './tmd-f2.component';

describe('TmdF2Component', () => {
  let component: TmdF2Component;
  let fixture: ComponentFixture<TmdF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmdF2Component]
    });
    fixture = TestBed.createComponent(TmdF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
