import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TmdF1Component } from './tmd-f1.component';

describe('TmdF1Component', () => {
  let component: TmdF1Component;
  let fixture: ComponentFixture<TmdF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TmdF1Component]
    });
    fixture = TestBed.createComponent(TmdF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
