import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tmd-f1',
  templateUrl: './tmd-f1.component.html',
  styleUrls: ['./tmd-f1.component.css']
})
export class TmdF1Component {
  TMDf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.TMDf1 = this.formBuilder.group({
      // jobNo: ['', Validators.required],

    });
  }
  // submitForm() {
  //   const formData = this.TMDf1.value;
  //   this.http.post('http://localhost:3000/api/TMDf1table', formData).subscribe(
  //     response => {
  //       console.log('Data saved successfully', response);
  //     },
  //     error => {
  //       console.error('Error saving data:', error);
  //     }
  //   );
  // }
  SaveToDraft(){
    const formData = this.TMDf1.value;
    const TMDf1Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(TMDf1Data);
    console.log(payload);
  }
  submitForm() {
    const formData = this.TMDf1.value;
    const TMDf1Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(TMDf1Data);
    console.log(payload);
  }
}
