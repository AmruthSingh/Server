import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f4',
  templateUrl: './doat-f4.component.html',
  styleUrls: ['./doat-f4.component.css']
})
export class DoatF4Component {
  DOATf4: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf4 = this.formBuilder.group({
      year:[''],
      calibIncharge:[''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.DOATf4.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    slno: '',
    typeOfInstrument: '',
    idNo: '',
    range: '',
    accuracy: '',
    acceptanceCriteria:'',
    agency:'',
    calibDate:'',
    nextDueDate:'',
    frequency:'',
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.DOATf4.value;
    const DOATf4Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf4Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf4.value;
    const DOATf4Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf4Data);

    console.log(payload);
  }
}
