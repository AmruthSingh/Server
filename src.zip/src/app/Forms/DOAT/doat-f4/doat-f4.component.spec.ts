import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF4Component } from './doat-f4.component';

describe('DoatF4Component', () => {
  let component: DoatF4Component;
  let fixture: ComponentFixture<DoatF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF4Component]
    });
    fixture = TestBed.createComponent(DoatF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
