import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f8',
  templateUrl: './doat-f8.component.html',
  styleUrls: ['./doat-f8.component.css']
})
export class DoatF8Component {
  DOATf8: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf8 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.DOATf8.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    date:[''],
    time:[''],
    testNo:[''],
    testDetails:[''],
    machNo:[''],
    angleOfAttach:[''],
    measurement:[''],
    nozzle:[''],
    driverGas:[''],
    t:[''],
    te:[''],
    p1:[''],
    p4:[''],
    pitot:[''],
    remarks:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.DOATf8.value;
    const DOATf8Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf8Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf8.value;
    const DOATf8Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf8Data);

    console.log(payload);
  }
}
