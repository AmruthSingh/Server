import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF8Component } from './doat-f8.component';

describe('DoatF8Component', () => {
  let component: DoatF8Component;
  let fixture: ComponentFixture<DoatF8Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF8Component]
    });
    fixture = TestBed.createComponent(DoatF8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
