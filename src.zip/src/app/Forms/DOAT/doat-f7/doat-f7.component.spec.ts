import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF7Component } from './doat-f7.component';

describe('DoatF7Component', () => {
  let component: DoatF7Component;
  let fixture: ComponentFixture<DoatF7Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF7Component]
    });
    fixture = TestBed.createComponent(DoatF7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
