import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f7',
  templateUrl: './doat-f7.component.html',
  styleUrls: ['./doat-f7.component.css']
})
export class DoatF7Component {
  DOATf7: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf7 = this.formBuilder.group({
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.DOATf7.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    date: '',
    time: '',
    runNo: '',
    dataFileNo: '',
    project: '',
    pr:'',
    temp:'',
    nos:'',
    initial:'',
    final:'',
    model:[''],
  testVarients:[''],
  mNo:[''],
  po:[''],
  videoNo:[''],
  photoNo:[''],
  config:[''],
  remarksInitials:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.DOATf7.value;
    const DOATf7Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf7Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf7.value;
    const DOATf7Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf7Data);

    console.log(payload);
  }
}
