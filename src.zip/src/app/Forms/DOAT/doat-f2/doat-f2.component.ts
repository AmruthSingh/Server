import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f2',
  templateUrl: './doat-f2.component.html',
  styleUrls: ['./doat-f2.component.css'],
})
export class DoatF2Component {
  DOATf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf2 = this.formBuilder.group({
      customer: [''],
      configuration: [''],
      requisitionNo: [''],
      requisitionDate: [''],
      testMatrix: [''],
      facilityName: [''],
      modelNumber: [''],
      windTunnel: [''],
      balanceID: [''],
      calibrationReport: [''],
      transducerDetails: [''],
      transducerID: [''],
      transducerCalibration: [''],
      otherInstruments: [''],
      pdc: [''],
      remarks: [''],
      prepared: [''],
      reviewed: [''],
      incharge: [''],
      headAero: [''],
      inchargeDate: [''],
      headDate: [''],
    });
  }
  SaveToDraft(){
    const formData = this.DOATf2.value;
    const DOATf2Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf2.value;
    const DOATf2Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf2Data);

    console.log(payload);
  }
}
