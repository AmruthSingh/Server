import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f5',
  templateUrl: './doat-f5.component.html',
  styleUrls: ['./doat-f5.component.css']
})
export class DoatF5Component {
  DOATf5: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf5 = this.formBuilder.group({
      type:[''],
      range:[''],
      unit:[''],
      make:[''],
      model:[''],
      serialNo:[''],
      accuracy:[''],
      fso:[''],
      excitation:[''],
      CalibDate:[''],
      typecalibrator:[''],
      typeMultiMeter:[''],
      makecalibrator:[''],
      makeMultiMeter:[''],
      serialcalibrator:[''],
      serialMultiMeter:[''],
      calibAgencycalibrator:[''],
      calibAgencyMultiMeter:[''],
      certificatecalibrator:[''],
      certificateMultiMeter:[''],
      calibOncalibrator:[''],
      calibOnMultiMeter:[''],
      duecalibrator:[''],
      dueMultiMeter:[''],
      temperature:[''],
      humidity:[''],
      radio:[''],
      offset:[''],
      slope:[''],
      fit:[''],
      accuracyResult:[''],
      fitness:[''],
      fitUnfit:[''],
      validTill:[''],
      calibrationBy:[''],
      calibIncharge:[''],
      rows: this.formBuilder.array([this.createRow()])
    });
  }

  get rows(): FormArray {
    return this.DOATf5.get('rows') as FormArray;
  }

  createRow(): FormGroup {
   return this.formBuilder.group({
    appliedPressure:[''],
    readingUut:[''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft(){
    const formData = this.DOATf5.value;
    const DOATf5Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf5Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf5.value;
    const DOATf5Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf5Data);

    console.log(payload);
  }
}
