import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF5Component } from './doat-f5.component';

describe('DoatF5Component', () => {
  let component: DoatF5Component;
  let fixture: ComponentFixture<DoatF5Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF5Component]
    });
    fixture = TestBed.createComponent(DoatF5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
