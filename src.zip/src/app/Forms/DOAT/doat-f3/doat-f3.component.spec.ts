import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF3Component } from './doat-f3.component';

describe('DoatF3Component', () => {
  let component: DoatF3Component;
  let fixture: ComponentFixture<DoatF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF3Component]
    });
    fixture = TestBed.createComponent(DoatF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
