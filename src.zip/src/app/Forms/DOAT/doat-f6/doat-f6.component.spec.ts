import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF6Component } from './doat-f6.component';

describe('DoatF6Component', () => {
  let component: DoatF6Component;
  let fixture: ComponentFixture<DoatF6Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF6Component]
    });
    fixture = TestBed.createComponent(DoatF6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
