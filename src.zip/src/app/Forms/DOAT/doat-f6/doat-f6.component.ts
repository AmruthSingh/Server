import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl  } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f6',
  templateUrl: './doat-f6.component.html',
  styleUrls: ['./doat-f6.component.css']
})
export class DoatF6Component {
  DOATf6: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf6 = this.formBuilder.group({
      documentNo: [''],
      copyNo: [''],
      noOfPages: [''],
      title: [''],
      preparedBy: [''],
      reviewedBy: [''],
      approvedBy: [''],
      authorisedBy: [''],
      date: [''],
    });
  }
  SaveToDraft(){
    const formData = this.DOATf6.value;
    const DOATf6Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf6Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf6.value;
    const DOATf6Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf6Data);

    console.log(payload);
  }
}
