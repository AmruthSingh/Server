import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doat-f1',
  templateUrl: './doat-f1.component.html',
  styleUrls: ['./doat-f1.component.css'],
})
export class DoatF1Component {
  DOATf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOATf1 = this.formBuilder.group({
      customer: [''],
      configuration: [''],
      machNo: [''],
      attackRange: [''],
      rollOrientation: [''],
      pressure: [''],
      force: [''],
      flowVisual: [''],
      oilFlow: [''],
      estimatedValues: [''],
      pdc: [''],
      remarks: [''],
      sign: [''],
      manager: [''],
      approve: [''],
      signDoat: [''],
      requisitionNo: [''],
      headAtf: [''],
      headAtfRadio: [''],
      date: [''],
      testFacility: [''],
    });
  }
  SaveToDraft(){
    const formData = this.DOATf1.value;
    const DOATf1Data = {
      formData,
      status:'draft'
    };
    const payload = JSON.stringify(DOATf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOATf1.value;
    const DOATf1Data = {
      formData,
      status:'Submitted'
    };
    const payload = JSON.stringify(DOATf1Data);

    console.log(payload);
  }
}
