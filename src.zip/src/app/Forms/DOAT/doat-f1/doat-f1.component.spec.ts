import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoatF1Component } from './doat-f1.component';

describe('DoatF1Component', () => {
  let component: DoatF1Component;
  let fixture: ComponentFixture<DoatF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoatF1Component]
    });
    fixture = TestBed.createComponent(DoatF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
