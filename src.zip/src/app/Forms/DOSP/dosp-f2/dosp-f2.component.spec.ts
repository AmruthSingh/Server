import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DospF2Component } from './dosp-f2.component';

describe('DospF2Component', () => {
  let component: DospF2Component;
  let fixture: ComponentFixture<DospF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DospF2Component]
    });
    fixture = TestBed.createComponent(DospF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
