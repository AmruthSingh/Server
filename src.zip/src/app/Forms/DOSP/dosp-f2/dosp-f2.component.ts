import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dosp-f2',
  templateUrl: './dosp-f2.component.html',
  styleUrls: ['./dosp-f2.component.css'],
})
export class DospF2Component {
  DOSPf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOSPf2 = this.formBuilder.group({
      projSystem: [''],
      from: [''],
      to: [''],
      preparedBy: [''],
      reviewedBy: [''],
      appandAuthby: [''],
      date: [''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DOSPf2.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNO: [''],
      actDesc: [''],
      responsibility: [''],
      pdc: [''],
      ipInformation: [''],
      fRom: [''],
      output: [''],
      remarks: [''],
    });
  }

  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }

  SaveToDraft() {
    const formData = this.DOSPf2.value;
    const DOSPf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOSPf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOSPf2.value;
    const DOSPf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOSPf2Data);

    console.log(payload);
  }
}
