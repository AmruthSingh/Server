import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DospF3Component } from './dosp-f3.component';

describe('DospF3Component', () => {
  let component: DospF3Component;
  let fixture: ComponentFixture<DospF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DospF3Component]
    });
    fixture = TestBed.createComponent(DospF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
