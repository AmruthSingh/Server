import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dosp-f3',
  templateUrl: './dosp-f3.component.html',
  styleUrls: ['./dosp-f3.component.css']
})
export class DospF3Component {
  DOSPf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DOSPf3 = this.formBuilder.group({
      reportNo:[''],
      revisionNo:[''],
      nameOfreport:[''],
      preparedBy:[''],
      reviewedBy:[''],
      approvedBy:[''],
      issueAuthBy:[''],
      month:[''],
      year:[''],

    });
  }
  SaveToDraft() {
    const formData = this.DOSPf3.value;
    const DOSPf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DOSPf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DOSPf3.value;
    const DOSPf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DOSPf3Data);

    console.log(payload);
  }
}
