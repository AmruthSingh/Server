import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DwstF13Component } from './dwst-f13.component';

describe('DwstF13Component', () => {
  let component: DwstF13Component;
  let fixture: ComponentFixture<DwstF13Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DwstF13Component]
    });
    fixture = TestBed.createComponent(DwstF13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
