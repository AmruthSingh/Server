import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dwst-f13',
  templateUrl: './dwst-f13.component.html',
  styleUrls: ['./dwst-f13.component.css'],
})
export class DwstF13Component {
  DWSTf13: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DWSTf13 = this.formBuilder.group({
      taskNo: [''],
      system: [''],
      project: [''],
      systemManager: [''],
      date: [''],
      signature: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DWSTf13.value;
    const DWSTf13Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DWSTf13Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DWSTf13.value;
    const DWSTf13Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DWSTf13Data);

    console.log(payload);
  }
}
