import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrqaF1Component } from './drqa-f1.component';

describe('DrqaF1Component', () => {
  let component: DrqaF1Component;
  let fixture: ComponentFixture<DrqaF1Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DrqaF1Component]
    });
    fixture = TestBed.createComponent(DrqaF1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
