import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-drqa-f1',
  templateUrl: './drqa-f1.component.html',
  styleUrls: ['./drqa-f1.component.css'],
})
export class DrqaF1Component {
  DRQAf1: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DRQAf1 = this.formBuilder.group({
      user: [''],
      project: [''],
      designerDemand: [''],
      receivedFrom: [''],
      dateOfRecept: [''],
      nameOfDirectorate: [''],
      nameOfDiv: [''],
      nameOfWorkCenter: [''],
      system: [''],
      subSystem: [''],
      modeOfUse: [''],
      natureOfWork: [''],
      desAmendment: [''],
      dateOfApprov: [''],
      signOfInit: [''],
      name: [''],
      nameDesIni: [''],
      date: [''],
      pNO: [''],
      Sufficiency: [''],
      mutuallyAgred:[''],
      actualDateOf:[''],
      Reviewed:[''],
      ReviewedBy:[''],
      pdcWork:[''],
      dateSys:[''],
      signSysMan:[''],
      dateHead:[''],
      signHeadOf:[''],
      ReviewedByThe:[''],
      dateTech:[''],
      signOfTech:[''],
      actualDateOfCom:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DRQAf1.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo: [''],
      desOfInputs: [''],
      softCopy: [''],
      hardCopy: [''],
      version: [''],
      dateVer: [''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DRQAf1.value;
    const DRQAf1Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DRQAf1Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DRQAf1.value;
    const DRQAf1Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DRQAf1Data);

    console.log(payload);
  }
}
