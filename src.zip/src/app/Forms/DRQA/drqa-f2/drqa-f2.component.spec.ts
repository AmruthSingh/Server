import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrqaF2Component } from './drqa-f2.component';

describe('DrqaF2Component', () => {
  let component: DrqaF2Component;
  let fixture: ComponentFixture<DrqaF2Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DrqaF2Component]
    });
    fixture = TestBed.createComponent(DrqaF2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
