import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-drqa-f2',
  templateUrl: './drqa-f2.component.html',
  styleUrls: ['./drqa-f2.component.css']
})
export class DrqaF2Component {
  DRQAf2: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DRQAf2 = this.formBuilder.group({
      fimNo: [''],
      dated: [''],
      materialBeingSupplied: [''],
      supplyOrderNo: [''],
      descOfMat: [''],
      sourceOfMaterial: [''],
      materialManuf:[''],
      quantity: [''],
      slNos: [''],
      idNos: [''],
      meltNo: [''],
      heatNo:[''],
      batchNo: [''],
      testCertiNo: [''],
      materialClearedBy: [''],
      videLetterNo: [''],
      greenCardNo:[''],
      tests: [''],
      hardwareDesc: [''],
      drdlRep: [''],
      name:[''],
      desig:[''],
      demandOff:[''],
      projRep:[''],
      systemManager:[''],
      enclosures1: [''],
      enclosures2: [''],
      enclosures3: [''],
    });
  }
  SaveToDraft() {
    const formData = this.DRQAf2.value;
    const DRQAf2Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DRQAf2Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DRQAf2.value;
    const DRQAf2Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DRQAf2Data);

    console.log(payload);
  }
}
