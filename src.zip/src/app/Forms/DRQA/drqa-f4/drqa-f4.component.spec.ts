import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrqaF4Component } from './drqa-f4.component';

describe('DrqaF4Component', () => {
  let component: DrqaF4Component;
  let fixture: ComponentFixture<DrqaF4Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DrqaF4Component]
    });
    fixture = TestBed.createComponent(DrqaF4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
