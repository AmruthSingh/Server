import { Component } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-drqa-f3',
  templateUrl: './drqa-f3.component.html',
  styleUrls: ['./drqa-f3.component.css']
})
export class DrqaF3Component {
  DRQAf3: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient) {
    this.DRQAf3 = this.formBuilder.group({
      fabName:[''],
     nonConfNo:[''],
     date:[''],
     project:[''],
     purchaseNo:[''],
     purchaseDate:[''],
     assyNomen:[''],
     nomen:[''],
     drgNo:[''],
     revNo:[''],
     idNo:[''],
     inspNo:[''],
     firmQCSign:[''],
     firmQCDate:[''],
     qaAgencySign:[''],
     qaAgencyDate:[''],
     designSign:[''],
     designDate:[''],
     refNo:[''],
     refdate:[''],
      rows: this.formBuilder.array([this.createRow()]),
    });
  }

  get rows(): FormArray {
    return this.DRQAf3.get('rows') as FormArray;
  }

  createRow(): FormGroup {
    return this.formBuilder.group({
      slNo:[''],
      specifiedVal:[''],
      obsVal:[''],
      reason:[''],
      prevenAction:[''],
      analysis:[''],
      designerCom:[''],
      recomm:[''],
    });
  }
  addRow(): void {
    this.rows.push(this.createRow());
  }

  deleteRow(index: number): void {
    this.rows.removeAt(index);
  }
  SaveToDraft() {
    const formData = this.DRQAf3.value;
    const DRQAf3Data = {
      formData,
      status: 'draft',
    };
    const payload = JSON.stringify(DRQAf3Data);

    console.log(payload);
  }
  submitForm() {
    const formData = this.DRQAf3.value;
    const DRQAf3Data = {
      formData,
      status: 'Submitted',
    };
    const payload = JSON.stringify(DRQAf3Data);

    console.log(payload);
  }
}
