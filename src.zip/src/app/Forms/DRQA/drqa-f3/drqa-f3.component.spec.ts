import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrqaF3Component } from './drqa-f3.component';

describe('DrqaF3Component', () => {
  let component: DrqaF3Component;
  let fixture: ComponentFixture<DrqaF3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DrqaF3Component]
    });
    fixture = TestBed.createComponent(DrqaF3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
