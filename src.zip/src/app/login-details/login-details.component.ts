import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-login-details',
  templateUrl: './login-details.component.html',
  styleUrls: ['./login-details.component.css'],
})
export class LoginDetailsComponent {
  // user: any;

  // constructor(private http: HttpClient) { }

  // fetchUserProfile(): void {
  //   const token = localStorage.getItem('token');
  //   const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

  //   this.http.get('http://localhost:3000/login-details', { headers }).subscribe(
  //     (response: any) => {
  //       this.user = response.username;
  //     },
  //     (error) => {
  //       console.error('Error fetching user profile:', error);
  //     }
  //   );
  // }
  user: any;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchUserProfile();
  }

  fetchUserProfile(): void {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    this.http.get('http://localhost:3000/home', { headers }).subscribe(
      (response: any) => {
        this.user = response.user;
      },
      (error) => {
        console.error('Error fetching user profile:', error);
      }
    );
  }
}
