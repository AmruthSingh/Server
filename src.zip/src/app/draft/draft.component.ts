import { Component, OnInit } from '@angular/core';
import { DraftService } from '../draft.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-draft',
  templateUrl: './draft.component.html',
})
export class DraftComponent implements OnInit {
  drafts: { formName: string, savedDate: Date }[] = [];

  constructor(
    private draftService: DraftService,
    private router: Router
  ) {}

  ngOnInit() {
    this.drafts = this.getDraftsInfo();
  }

  private getDraftsInfo() {
    const draftsInfo = [];
    const draftNames = this.draftService.getDraftNames();

    for (const formName of draftNames) {
      draftsInfo.push({
        formName,
        savedDate: this.draftService.getDraft(formName)?.savedDate || null,
      });
    }
    return draftsInfo;
  }

  loadDraft(formName: string) {
    this.router.navigate(['../home/form/form/', formName]);
  }

  deleteDraft(formName: string) {
    this.draftService.deleteDraft(formName);
    this.drafts = this.getDraftsInfo();
  }
}

