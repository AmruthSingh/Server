import { Component, ViewChild, ViewContainerRef, HostListener, OnInit } from '@angular/core';
import {HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  activeMenuItem: string = '';
  username: string = '';
  setActiveMenuItem(item: string) {
    this.activeMenuItem = item;
  }
  logoutTimeout: any;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    this.fetchUserProfile();
    this.resetLogoutTimeout();
  }

  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  resetLogoutTimeout() {
    clearTimeout(this.logoutTimeout);
    this.logoutTimeout = setTimeout(() => this.logout(), 10*60*1000);
  }

  logout() {
    localStorage.removeItem("username");
    localStorage.removeItem("password");
    this.router.navigate(['/loginpage']);
  }
  fetchUserProfile(): void {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    this.http.get('http://localhost:3000/home', { headers }).subscribe(
      (response: any) => {
        this.username = response.user.username;
      },
      (error) => {
        console.error('Error fetching user profile:', error);
      }
    );
  }
}
