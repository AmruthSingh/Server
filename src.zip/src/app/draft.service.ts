import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DraftService {
  private drafts: { [formName: string]: any } = {};

  SaveToDraft(formName: string, formData: any) {
    // const now = new Date();
    // const drafts = { data: formData, savedDate: now };
    this.drafts[formName] = formData;
  }

  getDraft(formName: string) {
    return this.drafts[formName];
  }

  deleteDraft(formName: string) {
    delete this.drafts[formName];
  }

  getDraftNames() {
    return Object.keys(this.drafts);
  }
}






