import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
})
export class ModalComponent {

  @Output() modalFormSubmit = new EventEmitter<any>();

  modalForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.modalForm = this.fb.group({
      from: [''],
      to: [''],
    });
  }

  sendForm() {
    if (this.modalForm.valid) {
      this.modalFormSubmit.emit(this.modalForm.value);
    }
  }
}
