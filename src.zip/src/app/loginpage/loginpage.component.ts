import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent {
username!: string;
password!: string;
constructor(private http: HttpClient ,private router: Router) { }

login(): void {
  const body = { username: this.username, password: this.password };

  this.http.post('http://localhost:3000/loginpage', body).subscribe(

  (response:any) => {
      const token = response.token;

      localStorage.setItem('token', token);
      this.router.navigate(['/home']);
    },
    (error) => {
      alert('invalid username and password')
    }
  );
}
}


