import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
declare var $: any;
import { AppModule } from './app/app.module';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';


platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
